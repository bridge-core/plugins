Install the extension and then add the `textureList` and `loadJSON` compiler plugins to your build config.

```json
{
	"plugins": {
		"*": ["loadJSON", "textureList"]
	}
}
```
