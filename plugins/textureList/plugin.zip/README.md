Install the extension and then add the `textureList` compiler plugin to your build config.

```json
{
	"plugins": {
		"*": ["textureList", "comMojangRewrite"]
	}
}
```
