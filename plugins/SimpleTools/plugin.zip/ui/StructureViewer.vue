<template>
        <h1>Structure Viewer</h1>
</template>