<template>
<div style="overflow: scroll">
<v-html>
<h1>ADDONS DOCUMENTATION </br>Version: 1.19.10.20</h1>
This is documentation for a preview release of Minecraft. New features, components, and capabilities in this release are not final and might change without notice before the final release.<br/>Be sure to check the documentation once the release is out of preview if your add-on isn't working properly. Resource and Behavior Packs created for the preview are not guaranteed to work on the final release.<br/>
<h2><p id="Index">Index</p></h2>
<table border="1">
<tr> <th><a href="#BlockStates">BlockStates</a></th> </tr>
<tr> <th><a href="#Blocks">Blocks</a></th> </tr>
<tr> <th><a href="#Entities">Entities</a></th> </tr>
<tr> <th><a href="#Entity Damage Source">Entity Damage Source</a></th> </tr>
<tr> <th><a href="#Geometry">Geometry</a></th> </tr>
<tr> <td> <a href="#Blocks"> Blocks</a> </tr> </td>
<tr> <th><a href="#Items">Items</a></th> </tr>
<tr> <th><a href="#manifest.json">manifest.json</a></th> </tr>
</table>
<a href="#Index">Back to top</a>
<h1><p id="BlockStates">BlockStates</p></h1>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:4;">
<tr> <th style="border-style:solid; border-width:4;">Block State Name</th> <th style="border-style:solid; border-width:4;">Type</th> <th style="border-style:solid; border-width:4;">Valid Values</th> <th style="border-style:solid; border-width:4;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">active</td>
<td style="border-style:solid; border-width:4; padding:6px">Boolean</td>
<td style="border-style:solid; border-width:4; padding:6px">True, False</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines whether the block is active or not</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">age</td>
<td style="border-style:solid; border-width:4; padding:6px">Integer</td>
<td style="border-style:solid; border-width:4; padding:6px">0 - 15</td>
<td style="border-style:solid; border-width:4; padding:6px">Represents the age of the block</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">age_bit</td>
<td style="border-style:solid; border-width:4; padding:6px">Boolean</td>
<td style="border-style:solid; border-width:4; padding:6px">True, False</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines if saplings should grow</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">allow_underwater_bit</td>
<td style="border-style:solid; border-width:4; padding:6px">Boolean</td>
<td style="border-style:solid; border-width:4; padding:6px">True, False</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines if a TNT block works underwater</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">attached_bit</td>
<td style="border-style:solid; border-width:4; padding:6px">Boolean</td>
<td style="border-style:solid; border-width:4; padding:6px">True, False</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines if a tripwire is attached to another tripwire</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">attachment</td>
<td style="border-style:solid; border-width:4; padding:6px">String</td>
<td style="border-style:solid; border-width:4; padding:6px">standing, hanging, side, multiple</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines the type of attachment used by a bell or grindstone block</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">bamboo_leaf_size</td>
<td style="border-style:solid; border-width:4; padding:6px">String</td>
<td style="border-style:solid; border-width:4; padding:6px">no_leaves, small_leaves, large_leaves</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines the size of bamboo leaves</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">bamboo_stalk_thickness</td>
<td style="border-style:solid; border-width:4; padding:6px">String</td>
<td style="border-style:solid; border-width:4; padding:6px">thin, thick</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines the thinkness of a bamboo stalk</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">big_dripleaf_tilt</td>
<td style="border-style:solid; border-width:4; padding:6px">String</td>
<td style="border-style:solid; border-width:4; padding:6px">none, unstable, partial_tilt, full_tilt</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines the tilt state of big dripleaf block</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">bite_counter</td>
<td style="border-style:solid; border-width:4; padding:6px">Integer</td>
<td style="border-style:solid; border-width:4; padding:6px">0 - 6</td>
<td style="border-style:solid; border-width:4; padding:6px">Tracks how many bites of cake have been taken</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">brewing_stand_slot_a_bit</td>
<td style="border-style:solid; border-width:4; padding:6px">Boolean</td>
<td style="border-style:solid; border-width:4; padding:6px">True, False</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines if a bottle is shown in slot a of the brewing stand</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">brewing_stand_slot_b_bit</td>
<td style="border-style:solid; border-width:4; padding:6px">Boolean</td>
<td style="border-style:solid; border-width:4; padding:6px">True, False</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines if a bottle is shown in slot b of the brewing stand</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">brewing_stand_slot_c_bit</td>
<td style="border-style:solid; border-width:4; padding:6px">Boolean</td>
<td style="border-style:solid; border-width:4; padding:6px">True, False</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines if a bottle is shown in slot c of the brewing stand</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">button_pressed_bit</td>
<td style="border-style:solid; border-width:4; padding:6px">Boolean</td>
<td style="border-style:solid; border-width:4; padding:6px">True, False</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines if a button is in the pressed state or not</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">candles</td>
<td style="border-style:solid; border-width:4; padding:6px">Integer</td>
<td style="border-style:solid; border-width:4; padding:6px">0 - 3</td>
<td style="border-style:solid; border-width:4; padding:6px">Describes how many extra candles are in the same block space</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">cauldron_liquid</td>
<td style="border-style:solid; border-width:4; padding:6px">String</td>
<td style="border-style:solid; border-width:4; padding:6px">water, lava</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines the type of liquid in a cauldron</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">chemistry_table_type</td>
<td style="border-style:solid; border-width:4; padding:6px">String</td>
<td style="border-style:solid; border-width:4; padding:6px">compound_creator, material_reducer, element_constructor, lab_table</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines the type of the work benches that are behind the edu features toggle</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">chisel_type</td>
<td style="border-style:solid; border-width:4; padding:6px">String</td>
<td style="border-style:solid; border-width:4; padding:6px">default, chiseled, lines, smooth</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines the pattern of quartz and purpur blocks</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">cluster_count</td>
<td style="border-style:solid; border-width:4; padding:6px">Integer</td>
<td style="border-style:solid; border-width:4; padding:6px">0 - 3</td>
<td style="border-style:solid; border-width:4; padding:6px">Describes how many sea pickles are in a cluster</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">color</td>
<td style="border-style:solid; border-width:4; padding:6px">String</td>
<td style="border-style:solid; border-width:4; padding:6px">white, orange, magenta, light_blue, yellow, lime, pink, gray, silver, cyan, purple, blue, brown, green, red, black</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines the color of a block like wool</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">color_bit</td>
<td style="border-style:solid; border-width:4; padding:6px">Boolean</td>
<td style="border-style:solid; border-width:4; padding:6px">True, False</td>
<td style="border-style:solid; border-width:4; padding:6px">Sets if a torch is a colored torch block</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">conditional_bit</td>
<td style="border-style:solid; border-width:4; padding:6px">Boolean</td>
<td style="border-style:solid; border-width:4; padding:6px">True, False</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines if a command block is conditional or not</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">coral_color</td>
<td style="border-style:solid; border-width:4; padding:6px">String</td>
<td style="border-style:solid; border-width:4; padding:6px">blue, pink, purple, red, yellow, blue dead, pink dead, red dead, yellow dead</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines the color of a coral block</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">coral_direction</td>
<td style="border-style:solid; border-width:4; padding:6px">Integer</td>
<td style="border-style:solid; border-width:4; padding:6px">0 - 3</td>
<td style="border-style:solid; border-width:4; padding:6px">Describes the rotation of coral fans</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">coral_hang_type_bit</td>
<td style="border-style:solid; border-width:4; padding:6px">Boolean</td>
<td style="border-style:solid; border-width:4; padding:6px">True, False</td>
<td style="border-style:solid; border-width:4; padding:6px">Describes the type of hanging for coral fans</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">covered_bit</td>
<td style="border-style:solid; border-width:4; padding:6px">Boolean</td>
<td style="border-style:solid; border-width:4; padding:6px">True, False</td>
<td style="border-style:solid; border-width:4; padding:6px">Describes if a top snow block is covering another block</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">cracked_state</td>
<td style="border-style:solid; border-width:4; padding:6px">String</td>
<td style="border-style:solid; border-width:4; padding:6px">no_cracks, cracked, max_cracked</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines the cracked state of turtle eggs</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">damage</td>
<td style="border-style:solid; border-width:4; padding:6px">String</td>
<td style="border-style:solid; border-width:4; padding:6px">undamaged, slightly_damaged, very_damaged, broken</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines the state of damage of an Anvil</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">dead_bit</td>
<td style="border-style:solid; border-width:4; padding:6px">Boolean</td>
<td style="border-style:solid; border-width:4; padding:6px">True, False</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines if coral, coral fans, or sea pickles are dead</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">direction</td>
<td style="border-style:solid; border-width:4; padding:6px">Integer</td>
<td style="border-style:solid; border-width:4; padding:6px">0 - 3</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines the North, South, East, and West direction of some blocks. 0 = South, 1 = West, 2 = North 3 = East</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">dirt_type</td>
<td style="border-style:solid; border-width:4; padding:6px">String</td>
<td style="border-style:solid; border-width:4; padding:6px">normal, coarse</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines the dirt type of a block</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">disarmed_bit</td>
<td style="border-style:solid; border-width:4; padding:6px">Boolean</td>
<td style="border-style:solid; border-width:4; padding:6px">True, False</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines if a tripwire is disarmed or not.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">door_hinge_bit</td>
<td style="border-style:solid; border-width:4; padding:6px">Boolean</td>
<td style="border-style:solid; border-width:4; padding:6px">True, False</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines if door's hinge is mirrored or not</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">double_plant_type</td>
<td style="border-style:solid; border-width:4; padding:6px">String</td>
<td style="border-style:solid; border-width:4; padding:6px">sunflower, syringa, grass, fern, rose, paeonia</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines the type of a double plant block</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">drag_down</td>
<td style="border-style:solid; border-width:4; padding:6px">Boolean</td>
<td style="border-style:solid; border-width:4; padding:6px">True, False</td>
<td style="border-style:solid; border-width:4; padding:6px">Describes if bubble columns drag entities down or pushes them up</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">dripstone_thickness</td>
<td style="border-style:solid; border-width:4; padding:6px">String</td>
<td style="border-style:solid; border-width:4; padding:6px">tip, frustum, base, middle, merge</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines the type of a pointed dripstone block</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">end_portal_eye_bit</td>
<td style="border-style:solid; border-width:4; padding:6px">Boolean</td>
<td style="border-style:solid; border-width:4; padding:6px">True, False</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines if an end portal block has an Eye in it</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">explode_bit</td>
<td style="border-style:solid; border-width:4; padding:6px">Boolean</td>
<td style="border-style:solid; border-width:4; padding:6px">True, False</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines if a TNT block should start its explode sequence</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">facing_direction</td>
<td style="border-style:solid; border-width:4; padding:6px">Integer</td>
<td style="border-style:solid; border-width:4; padding:6px">0 - 5</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines the Up, Down, North, South, East, and West direction of some blocks. 0 = Down, 1 = Up, 2 = North, 3 = South, 4 = West, 5 = East</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">fill_level</td>
<td style="border-style:solid; border-width:4; padding:6px">Integer</td>
<td style="border-style:solid; border-width:4; padding:6px">0 - 6</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines fill level of a cauldron block</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">flower_type</td>
<td style="border-style:solid; border-width:4; padding:6px">String</td>
<td style="border-style:solid; border-width:4; padding:6px">poppy, orchid, allium, houstonia, tulip_red, tulip_orange, tulip_white, tulip_pink, oxeye, cornflower, lily_of_the_valley</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines the type of a flower block</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">ground_sign_direction</td>
<td style="border-style:solid; border-width:4; padding:6px">Integer</td>
<td style="border-style:solid; border-width:4; padding:6px">0 - 15</td>
<td style="border-style:solid; border-width:4; padding:6px">Describes the rotation of signs and standing banners</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">growth</td>
<td style="border-style:solid; border-width:4; padding:6px">Integer</td>
<td style="border-style:solid; border-width:4; padding:6px">0 - 7</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines the growth level of crops</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">hanging</td>
<td style="border-style:solid; border-width:4; padding:6px">Boolean</td>
<td style="border-style:solid; border-width:4; padding:6px">True, False</td>
<td style="border-style:solid; border-width:4; padding:6px">Describes if a lantern block is hanging or not</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">head_piece_bit</td>
<td style="border-style:solid; border-width:4; padding:6px">Boolean</td>
<td style="border-style:solid; border-width:4; padding:6px">True, False</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines if a block is the pillow side of a bed</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">height</td>
<td style="border-style:solid; border-width:4; padding:6px">Integer</td>
<td style="border-style:solid; border-width:4; padding:6px">0 - 7</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines the height of a top snow block</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">huge_mushroom_bits</td>
<td style="border-style:solid; border-width:4; padding:6px">Integer</td>
<td style="border-style:solid; border-width:4; padding:6px">0 - 15</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines which huge mushroom block to be displayed</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">in_wall_bit</td>
<td style="border-style:solid; border-width:4; padding:6px">Boolean</td>
<td style="border-style:solid; border-width:4; padding:6px">True, False</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines if a fence block is connected to a wall block</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">infiniburn_bit</td>
<td style="border-style:solid; border-width:4; padding:6px">Boolean</td>
<td style="border-style:solid; border-width:4; padding:6px">True, False</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines if a block should burn infinitely</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">item_frame_map_bit</td>
<td style="border-style:solid; border-width:4; padding:6px">Boolean</td>
<td style="border-style:solid; border-width:4; padding:6px">True, False</td>
<td style="border-style:solid; border-width:4; padding:6px">Describes if an item frame block has a map in it</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">item_frame_photo_bit</td>
<td style="border-style:solid; border-width:4; padding:6px">Boolean</td>
<td style="border-style:solid; border-width:4; padding:6px">True, False</td>
<td style="border-style:solid; border-width:4; padding:6px">Describes if an item frame block has a photo in it</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">liquid_depth</td>
<td style="border-style:solid; border-width:4; padding:6px">Integer</td>
<td style="border-style:solid; border-width:4; padding:6px">0 - 15</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines the level of liquid blocks</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">lit</td>
<td style="border-style:solid; border-width:4; padding:6px">Boolean</td>
<td style="border-style:solid; border-width:4; padding:6px">True, False</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines if a block is lit or not</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">moisturized_amount</td>
<td style="border-style:solid; border-width:4; padding:6px">Integer</td>
<td style="border-style:solid; border-width:4; padding:6px">0 - 7</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines the moisture level of crops</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">monster_egg_stone_type</td>
<td style="border-style:solid; border-width:4; padding:6px">String</td>
<td style="border-style:solid; border-width:4; padding:6px">stone, cobblestone, stone_brick, mossy_stone_brick, cracked_stone_brick, chiseled_stone_brick</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines the stone type of a monster egg block</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">new_leaf_type</td>
<td style="border-style:solid; border-width:4; padding:6px">String</td>
<td style="border-style:solid; border-width:4; padding:6px">acacia, dark_oak</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines the leaf type of some blocks</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">new_log_type</td>
<td style="border-style:solid; border-width:4; padding:6px">String</td>
<td style="border-style:solid; border-width:4; padding:6px">acacia, dark_oak</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines the wood type of some blocks</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">no_drop_bit</td>
<td style="border-style:solid; border-width:4; padding:6px">Boolean</td>
<td style="border-style:solid; border-width:4; padding:6px">True, False</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines if a skull block should drop loot</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">occupied_bit</td>
<td style="border-style:solid; border-width:4; padding:6px">Boolean</td>
<td style="border-style:solid; border-width:4; padding:6px">True, False</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines if a bed block is occupied</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">old_leaf_type</td>
<td style="border-style:solid; border-width:4; padding:6px">String</td>
<td style="border-style:solid; border-width:4; padding:6px">oak, spruce, birch, jungle</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines the leaf type of some blocks</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">old_log_type</td>
<td style="border-style:solid; border-width:4; padding:6px">String</td>
<td style="border-style:solid; border-width:4; padding:6px">oak, spruce, birch, jungle</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines the wood type of some blocks</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">open_bit</td>
<td style="border-style:solid; border-width:4; padding:6px">Boolean</td>
<td style="border-style:solid; border-width:4; padding:6px">True, False</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines if a door, gate, or trapdoor is open</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">output_lit_bit</td>
<td style="border-style:solid; border-width:4; padding:6px">Boolean</td>
<td style="border-style:solid; border-width:4; padding:6px">True, False</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines if a Comparator's output is lit</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">output_subtract_bit</td>
<td style="border-style:solid; border-width:4; padding:6px">Boolean</td>
<td style="border-style:solid; border-width:4; padding:6px">True, False</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines if a Comparator is set to subtract output</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">persistent_bit</td>
<td style="border-style:solid; border-width:4; padding:6px">Boolean</td>
<td style="border-style:solid; border-width:4; padding:6px">True, False</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines if a leaf block is persistent</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">portal_axis</td>
<td style="border-style:solid; border-width:4; padding:6px">String</td>
<td style="border-style:solid; border-width:4; padding:6px">unknown, x, z</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines the orientation of portal blocks</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">powered_bit</td>
<td style="border-style:solid; border-width:4; padding:6px">Boolean</td>
<td style="border-style:solid; border-width:4; padding:6px">True, False</td>
<td style="border-style:solid; border-width:4; padding:6px">Shows when an observer or tripwire sends a redstone signal</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">rail_data_bit</td>
<td style="border-style:solid; border-width:4; padding:6px">Boolean</td>
<td style="border-style:solid; border-width:4; padding:6px">True, False</td>
<td style="border-style:solid; border-width:4; padding:6px">Shows if a rail has a redstone signal</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">rail_direction</td>
<td style="border-style:solid; border-width:4; padding:6px">Integer</td>
<td style="border-style:solid; border-width:4; padding:6px">0 - 8</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines the orientation of a placed rail block</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">redstone_signal</td>
<td style="border-style:solid; border-width:4; padding:6px">Integer</td>
<td style="border-style:solid; border-width:4; padding:6px">0 - 15</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines the signal strength of a redstone signal</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">repeater_delay</td>
<td style="border-style:solid; border-width:4; padding:6px">Integer</td>
<td style="border-style:solid; border-width:4; padding:6px">0 - 3</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines the amount of delay of a repeater</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">sand_stone_type</td>
<td style="border-style:solid; border-width:4; padding:6px">String</td>
<td style="border-style:solid; border-width:4; padding:6px">default, heiroglyphs, cut, smooth</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines the pattern of a sandstone block</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">sand_type</td>
<td style="border-style:solid; border-width:4; padding:6px">String</td>
<td style="border-style:solid; border-width:4; padding:6px">normal, red</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines the sand type of a block</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">sapling_type</td>
<td style="border-style:solid; border-width:4; padding:6px">String</td>
<td style="border-style:solid; border-width:4; padding:6px">evergreen, birch, jungle, acacia, roofed_oak</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines the type of the sapling block</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">sea_grass_type</td>
<td style="border-style:solid; border-width:4; padding:6px">String</td>
<td style="border-style:solid; border-width:4; padding:6px">default, double_top, double_bot</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines the type of a seagrass block</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">sponge_type</td>
<td style="border-style:solid; border-width:4; padding:6px">String</td>
<td style="border-style:solid; border-width:4; padding:6px">dry, wet</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines the type of a sponge block</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">stability</td>
<td style="border-style:solid; border-width:4; padding:6px">Integer</td>
<td style="border-style:solid; border-width:4; padding:6px">0 - 5</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines the stability of a scaffolding block</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">stability_check</td>
<td style="border-style:solid; border-width:4; padding:6px">Boolean</td>
<td style="border-style:solid; border-width:4; padding:6px">True, False</td>
<td style="border-style:solid; border-width:4; padding:6px">Describes if a scaffolding block has been checked for stability</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">stone_brick_type</td>
<td style="border-style:solid; border-width:4; padding:6px">String</td>
<td style="border-style:solid; border-width:4; padding:6px">default, mossy, cracked, chiseled, smooth</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines the type of a stone brick block</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">stone_slab_type</td>
<td style="border-style:solid; border-width:4; padding:6px">String</td>
<td style="border-style:solid; border-width:4; padding:6px">smooth_stone, sandstone, wood, cobblestone, brick, stone_brick, quartz, nether_brick</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines the type of some stone slab blocks</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">stone_slab_type_2</td>
<td style="border-style:solid; border-width:4; padding:6px">String</td>
<td style="border-style:solid; border-width:4; padding:6px">red_sandstone, purpur, prismarine_rough, prismarine_dark, prismarine_brick, mossy_cobblestone, smooth_sandstone, red_nether_brick</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines the type of some stone slab blocks</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">stone_slab_type_3</td>
<td style="border-style:solid; border-width:4; padding:6px">String</td>
<td style="border-style:solid; border-width:4; padding:6px">end_stone_brick, smooth_red_sandstone, polishe_andesite, andesite, diorite, polished_diorite, granite, polished_granite</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines the type of some stone slab blocks</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">stone_slab_type_4</td>
<td style="border-style:solid; border-width:4; padding:6px">String</td>
<td style="border-style:solid; border-width:4; padding:6px">mossy_stone_brick, smooth_quartz, stone, cut_sandstone, cut_red_sandstone</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines the type of some stone slab blocks</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">stone_type</td>
<td style="border-style:solid; border-width:4; padding:6px">String</td>
<td style="border-style:solid; border-width:4; padding:6px">stone, granite, granite_smooth, diorite, diorite_smooth, andesite, andesite_smooth</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines the stone type of a block</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">stripped_bit</td>
<td style="border-style:solid; border-width:4; padding:6px">Boolean</td>
<td style="border-style:solid; border-width:4; padding:6px">True, False</td>
<td style="border-style:solid; border-width:4; padding:6px">Describes if a wood log has been stripped of bark</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">structure_block_type</td>
<td style="border-style:solid; border-width:4; padding:6px">String</td>
<td style="border-style:solid; border-width:4; padding:6px">data, save, load, corner, invalid, export</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines the state of a structure block</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">structure_void_type</td>
<td style="border-style:solid; border-width:4; padding:6px">String</td>
<td style="border-style:solid; border-width:4; padding:6px">void, air</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines which void mode to draw for structure blocks</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">suspended_bit</td>
<td style="border-style:solid; border-width:4; padding:6px">Boolean</td>
<td style="border-style:solid; border-width:4; padding:6px">True, False</td>
<td style="border-style:solid; border-width:4; padding:6px">Indicates if a tripwire block is suspended</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">tall_grass_type</td>
<td style="border-style:solid; border-width:4; padding:6px">String</td>
<td style="border-style:solid; border-width:4; padding:6px">default, tall, fern, snow</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines the type of a tall grass block</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">toggle_bit</td>
<td style="border-style:solid; border-width:4; padding:6px">Boolean</td>
<td style="border-style:solid; border-width:4; padding:6px">True, False</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines if a hopper block is active or not</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">top_slot_bit</td>
<td style="border-style:solid; border-width:4; padding:6px">Boolean</td>
<td style="border-style:solid; border-width:4; padding:6px">True, False</td>
<td style="border-style:solid; border-width:4; padding:6px">Shows if a slab is the top half of the block or not</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">torch_facing_direction</td>
<td style="border-style:solid; border-width:4; padding:6px">String</td>
<td style="border-style:solid; border-width:4; padding:6px">unknown, west, east, north, south, top</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines the block that a torch is attached to in relation to its position</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">triggered_bit</td>
<td style="border-style:solid; border-width:4; padding:6px">Boolean</td>
<td style="border-style:solid; border-width:4; padding:6px">True, False</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines if a dispenser is triggered</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">turtle_egg_count</td>
<td style="border-style:solid; border-width:4; padding:6px">String</td>
<td style="border-style:solid; border-width:4; padding:6px">one_egg, two_egg, three_egg, four_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines the amount of turtle eggs in an egg block</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">update_bit</td>
<td style="border-style:solid; border-width:4; padding:6px">Boolean</td>
<td style="border-style:solid; border-width:4; padding:6px">True, False</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines if a leaf block or flower block should be updated</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">upper_block_bit</td>
<td style="border-style:solid; border-width:4; padding:6px">Boolean</td>
<td style="border-style:solid; border-width:4; padding:6px">True, False</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines if a block is the upper half of an object like a door or a tall plant</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">upside_down_bit</td>
<td style="border-style:solid; border-width:4; padding:6px">Boolean</td>
<td style="border-style:solid; border-width:4; padding:6px">True, False</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines if a stair block or trapdoor block is upsidedown</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">vine_direction_bits</td>
<td style="border-style:solid; border-width:4; padding:6px">Integer</td>
<td style="border-style:solid; border-width:4; padding:6px">0 - 15</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines the facing direction for vines, works like the facing_direction blockstate</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">wall_block_type</td>
<td style="border-style:solid; border-width:4; padding:6px">String</td>
<td style="border-style:solid; border-width:4; padding:6px">cobblestone, mossy_cobblestone, granite, diorite, andesite, sandstone, brick, stone_brick, mossy_stone_brick, nether_brick, end_brick, prismarine, red_sandstone, red_nether_brick</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines the type of a stone used in a wall block</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">wall_connection_type_east</td>
<td style="border-style:solid; border-width:4; padding:6px">String</td>
<td style="border-style:solid; border-width:4; padding:6px">none, short, tall</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines what kind of connection a wall has to the east</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">wall_connection_type_north</td>
<td style="border-style:solid; border-width:4; padding:6px">String</td>
<td style="border-style:solid; border-width:4; padding:6px">none, short, tall</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines what kind of connection a wall has to the north</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">wall_connection_type_south</td>
<td style="border-style:solid; border-width:4; padding:6px">String</td>
<td style="border-style:solid; border-width:4; padding:6px">none, short, tall</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines what kind of connection a wall has to the south</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">wall_connection_type_west</td>
<td style="border-style:solid; border-width:4; padding:6px">String</td>
<td style="border-style:solid; border-width:4; padding:6px">none, short, tall</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines what kind of connection a wall has to the west</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">wall_post_bit</td>
<td style="border-style:solid; border-width:4; padding:6px">Boolean</td>
<td style="border-style:solid; border-width:4; padding:6px">True, False</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines if a wall should contain a post</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">weirdo_direction</td>
<td style="border-style:solid; border-width:4; padding:6px">Integer</td>
<td style="border-style:solid; border-width:4; padding:6px">0 - 3</td>
<td style="border-style:solid; border-width:4; padding:6px">Describes the rotation of stairs</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">wood_type</td>
<td style="border-style:solid; border-width:4; padding:6px">String</td>
<td style="border-style:solid; border-width:4; padding:6px">oak, spruce, birch, jungle, acacia, dark_oak</td>
<td style="border-style:solid; border-width:4; padding:6px">Determines the wood type of a block</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h1><p id="Blocks">Blocks</p></h1>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:4;">
<tr> <th style="border-style:solid; border-width:4;">Name</th> </tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:acacia_button</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:acacia_door</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:acacia_fence_gate</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:acacia_pressure_plate</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:acacia_stairs</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:acacia_standing_sign</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:acacia_trapdoor</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:acacia_wall_sign</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:activator_rail</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:air</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:allow</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:amethyst_block</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:amethyst_cluster</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:ancient_debris</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:andesite_stairs</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:anvil</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:azalea</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:azalea_leaves</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:azalea_leaves_flowered</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:bamboo</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:bamboo_sapling</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:barrel</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:barrier</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:basalt</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:beacon</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:bed</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:bedrock</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:bee_nest</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:beehive</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:beetroot</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:bell</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:big_dripleaf</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:birch_button</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:birch_door</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:birch_fence_gate</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:birch_pressure_plate</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:birch_stairs</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:birch_standing_sign</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:birch_trapdoor</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:birch_wall_sign</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:black_candle</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:black_candle_cake</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:black_glazed_terracotta</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:blackstone</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:blackstone_double_slab</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:blackstone_slab</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:blackstone_stairs</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:blackstone_wall</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:blast_furnace</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:blue_candle</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:blue_candle_cake</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:blue_glazed_terracotta</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:blue_ice</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:bone_block</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:bookshelf</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:border_block</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:brewing_stand</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:brick_block</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:brick_stairs</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:brown_candle</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:brown_candle_cake</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:brown_glazed_terracotta</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:brown_mushroom</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:brown_mushroom_block</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:bubble_column</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:budding_amethyst</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:cactus</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:cake</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:calcite</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:camera</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:campfire</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:candle</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:candle_cake</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:carpet</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:carrots</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:cartography_table</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:carved_pumpkin</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:cauldron</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:cave_vines</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:cave_vines_body_with_berries</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:cave_vines_head_with_berries</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:chain</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:chain_command_block</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:chemical_heat</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:chemistry_table</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:chest</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:chiseled_deepslate</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:chiseled_nether_bricks</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:chiseled_polished_blackstone</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:chorus_flower</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:chorus_plant</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:clay</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:client_request_placeholder_block</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:coal_block</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:coal_ore</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:cobbled_deepslate</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:cobbled_deepslate_double_slab</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:cobbled_deepslate_slab</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:cobbled_deepslate_stairs</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:cobbled_deepslate_wall</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:cobblestone</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:cobblestone_wall</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:cocoa</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:colored_torch_bp</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:colored_torch_rg</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:command_block</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:composter</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:concrete</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:concrete_powder</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:conduit</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:copper_block</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:copper_ore</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:coral</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:coral_block</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:coral_fan</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:coral_fan_dead</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:coral_fan_hang</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:coral_fan_hang2</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:coral_fan_hang3</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:cracked_deepslate_bricks</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:cracked_deepslate_tiles</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:cracked_nether_bricks</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:cracked_polished_blackstone_bricks</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:crafting_table</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:crimson_button</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:crimson_door</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:crimson_double_slab</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:crimson_fence</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:crimson_fence_gate</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:crimson_fungus</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:crimson_hyphae</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:crimson_nylium</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:crimson_planks</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:crimson_pressure_plate</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:crimson_roots</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:crimson_slab</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:crimson_stairs</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:crimson_standing_sign</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:crimson_stem</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:crimson_trapdoor</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:crimson_wall_sign</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:crying_obsidian</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:cut_copper</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:cut_copper_slab</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:cut_copper_stairs</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:cyan_candle</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:cyan_candle_cake</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:cyan_glazed_terracotta</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:dark_oak_button</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:dark_oak_door</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:dark_oak_fence_gate</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:dark_oak_pressure_plate</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:dark_oak_stairs</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:dark_oak_trapdoor</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:dark_prismarine_stairs</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:darkoak_standing_sign</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:darkoak_wall_sign</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:daylight_detector</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:daylight_detector_inverted</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:deadbush</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:deepslate</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:deepslate_brick_double_slab</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:deepslate_brick_slab</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:deepslate_brick_stairs</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:deepslate_brick_wall</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:deepslate_bricks</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:deepslate_coal_ore</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:deepslate_copper_ore</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:deepslate_diamond_ore</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:deepslate_emerald_ore</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:deepslate_gold_ore</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:deepslate_iron_ore</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:deepslate_lapis_ore</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:deepslate_redstone_ore</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:deepslate_tile_double_slab</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:deepslate_tile_slab</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:deepslate_tile_stairs</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:deepslate_tile_wall</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:deepslate_tiles</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:deny</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:detector_rail</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:diamond_block</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:diamond_ore</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:diorite_stairs</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:dirt</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:dirt_with_roots</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:dispenser</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:double_cut_copper_slab</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:double_plant</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:double_stone_block_slab</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:double_stone_block_slab2</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:double_stone_block_slab3</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:double_stone_block_slab4</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:double_wooden_slab</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:dragon_egg</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:dried_kelp_block</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:dripstone_block</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:dropper</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_0</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_1</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_10</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_100</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_101</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_102</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_103</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_104</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_105</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_106</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_107</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_108</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_109</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_11</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_110</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_111</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_112</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_113</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_114</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_115</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_116</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_117</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_118</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_12</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_13</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_14</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_15</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_16</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_17</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_18</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_19</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_2</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_20</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_21</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_22</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_23</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_24</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_25</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_26</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_27</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_28</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_29</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_3</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_30</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_31</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_32</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_33</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_34</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_35</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_36</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_37</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_38</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_39</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_4</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_40</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_41</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_42</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_43</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_44</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_45</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_46</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_47</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_48</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_49</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_5</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_50</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_51</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_52</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_53</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_54</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_55</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_56</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_57</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_58</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_59</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_6</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_60</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_61</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_62</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_63</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_64</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_65</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_66</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_67</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_68</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_69</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_7</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_70</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_71</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_72</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_73</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_74</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_75</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_76</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_77</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_78</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_79</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_8</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_80</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_81</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_82</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_83</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_84</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_85</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_86</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_87</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_88</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_89</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_9</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_90</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_91</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_92</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_93</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_94</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_95</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_96</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_97</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_98</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:element_99</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:emerald_block</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:emerald_ore</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:enchanting_table</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:end_brick_stairs</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:end_bricks</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:end_gateway</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:end_portal</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:end_portal_frame</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:end_rod</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:end_stone</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:ender_chest</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:exposed_copper</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:exposed_cut_copper</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:exposed_cut_copper_slab</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:exposed_cut_copper_stairs</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:exposed_double_cut_copper_slab</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:farmland</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:fence</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:fence_gate</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:fire</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:fletching_table</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:flower_pot</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:flowering_azalea</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:flowing_lava</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:flowing_water</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:frame</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:frog_spawn</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:frosted_ice</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:furnace</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:gilded_blackstone</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:glass</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:glass_pane</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:glow_frame</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:glow_lichen</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:glowingobsidian</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:glowstone</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:gold_block</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:gold_ore</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:golden_rail</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:granite_stairs</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:grass</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:grass_path</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:gravel</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:gray_candle</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:gray_candle_cake</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:gray_glazed_terracotta</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:green_candle</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:green_candle_cake</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:green_glazed_terracotta</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:grindstone</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:hanging_roots</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:hard_glass</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:hard_glass_pane</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:hard_stained_glass</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:hard_stained_glass_pane</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:hardened_clay</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:hay_block</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:heavy_weighted_pressure_plate</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:honey_block</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:honeycomb_block</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:hopper</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:ice</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:infested_deepslate</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:info_update</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:info_update2</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:invisible_bedrock</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:iron_bars</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:iron_block</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:iron_door</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:iron_ore</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:iron_trapdoor</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:jigsaw</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:jukebox</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:jungle_button</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:jungle_door</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:jungle_fence_gate</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:jungle_pressure_plate</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:jungle_stairs</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:jungle_standing_sign</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:jungle_trapdoor</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:jungle_wall_sign</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:kelp</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:ladder</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:lantern</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:lapis_block</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:lapis_ore</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:large_amethyst_bud</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:lava</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:lava_cauldron</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:leaves</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:leaves2</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:lectern</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:lever</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:light_block</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:light_blue_candle</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:light_blue_candle_cake</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:light_blue_glazed_terracotta</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:light_gray_candle</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:light_gray_candle_cake</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:light_weighted_pressure_plate</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:lightning_rod</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:lime_candle</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:lime_candle_cake</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:lime_glazed_terracotta</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:lit_blast_furnace</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:lit_deepslate_redstone_ore</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:lit_furnace</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:lit_pumpkin</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:lit_redstone_lamp</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:lit_redstone_ore</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:lit_smoker</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:lodestone</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:log</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:log2</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:loom</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:magenta_candle</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:magenta_candle_cake</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:magenta_glazed_terracotta</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:magma</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:mangrove_button</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:mangrove_door</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:mangrove_double_slab</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:mangrove_fence</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:mangrove_fence_gate</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:mangrove_leaves</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:mangrove_log</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:mangrove_planks</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:mangrove_pressure_plate</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:mangrove_propagule</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:mangrove_roots</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:mangrove_slab</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:mangrove_stairs</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:mangrove_standing_sign</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:mangrove_trapdoor</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:mangrove_wall_sign</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:mangrove_wood</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:medium_amethyst_bud</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:melon_block</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:melon_stem</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:mob_spawner</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:monster_egg</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:moss_block</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:moss_carpet</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:mossy_cobblestone</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:mossy_cobblestone_stairs</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:mossy_stone_brick_stairs</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:moving_block</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:mud</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:mud_brick_double_slab</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:mud_brick_slab</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:mud_brick_stairs</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:mud_brick_wall</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:mud_bricks</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:muddy_mangrove_roots</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:mycelium</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:nether_brick</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:nether_brick_fence</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:nether_brick_stairs</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:nether_gold_ore</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:nether_sprouts</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:nether_wart</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:nether_wart_block</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:netherite_block</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:netherrack</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:netherreactor</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:normal_stone_stairs</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:noteblock</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:oak_stairs</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:observer</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:obsidian</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:ochre_froglight</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:orange_candle</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:orange_candle_cake</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:orange_glazed_terracotta</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:oxidized_copper</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:oxidized_cut_copper</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:oxidized_cut_copper_slab</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:oxidized_cut_copper_stairs</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:oxidized_double_cut_copper_slab</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:packed_ice</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:packed_mud</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:pearlescent_froglight</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:pink_candle</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:pink_candle_cake</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:pink_glazed_terracotta</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:piston</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:piston_arm_collision</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:planks</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:podzol</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:pointed_dripstone</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:polished_andesite_stairs</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:polished_basalt</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:polished_blackstone</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:polished_blackstone_brick_double_slab</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:polished_blackstone_brick_slab</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:polished_blackstone_brick_stairs</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:polished_blackstone_brick_wall</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:polished_blackstone_bricks</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:polished_blackstone_button</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:polished_blackstone_double_slab</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:polished_blackstone_pressure_plate</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:polished_blackstone_slab</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:polished_blackstone_stairs</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:polished_blackstone_wall</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:polished_deepslate</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:polished_deepslate_double_slab</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:polished_deepslate_slab</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:polished_deepslate_stairs</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:polished_deepslate_wall</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:polished_diorite_stairs</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:polished_granite_stairs</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:portal</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:potatoes</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:powder_snow</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:powered_comparator</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:powered_repeater</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:prismarine</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:prismarine_bricks_stairs</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:prismarine_stairs</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:pumpkin</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:pumpkin_stem</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:purple_candle</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:purple_candle_cake</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:purple_glazed_terracotta</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:purpur_block</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:purpur_stairs</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:quartz_block</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:quartz_bricks</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:quartz_ore</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:quartz_stairs</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:rail</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:raw_copper_block</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:raw_gold_block</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:raw_iron_block</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:red_candle</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:red_candle_cake</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:red_flower</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:red_glazed_terracotta</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:red_mushroom</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:red_mushroom_block</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:red_nether_brick</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:red_nether_brick_stairs</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:red_sandstone</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:red_sandstone_stairs</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:redstone_block</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:redstone_lamp</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:redstone_ore</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:redstone_torch</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:redstone_wire</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:reeds</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:reinforced_deepslate</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:repeating_command_block</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:reserved6</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:respawn_anchor</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:sand</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:sandstone</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:sandstone_stairs</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:sapling</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:scaffolding</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:sculk</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:sculk_catalyst</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:sculk_sensor</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:sculk_shrieker</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:sculk_vein</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:sea_lantern</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:sea_pickle</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:seagrass</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:shroomlight</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:shulker_box</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:silver_glazed_terracotta</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:skull</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:slime</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:small_amethyst_bud</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:small_dripleaf_block</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:smithing_table</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:smoker</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:smooth_basalt</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:smooth_quartz_stairs</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:smooth_red_sandstone_stairs</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:smooth_sandstone_stairs</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:smooth_stone</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:snow</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:snow_layer</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:soul_campfire</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:soul_fire</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:soul_lantern</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:soul_sand</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:soul_soil</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:soul_torch</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:sponge</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:spore_blossom</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:spruce_button</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:spruce_door</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:spruce_fence_gate</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:spruce_pressure_plate</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:spruce_stairs</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:spruce_standing_sign</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:spruce_trapdoor</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:spruce_wall_sign</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:stained_glass</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:stained_glass_pane</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:stained_hardened_clay</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:standing_banner</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:standing_sign</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:sticky_piston</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:sticky_piston_arm_collision</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:stone</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:stone_block_slab</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:stone_block_slab2</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:stone_block_slab3</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:stone_block_slab4</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:stone_brick_stairs</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:stone_button</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:stone_pressure_plate</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:stone_stairs</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:stonebrick</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:stonecutter</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:stonecutter_block</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:stripped_acacia_log</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:stripped_birch_log</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:stripped_crimson_hyphae</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:stripped_crimson_stem</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:stripped_dark_oak_log</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:stripped_jungle_log</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:stripped_mangrove_log</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:stripped_mangrove_wood</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:stripped_oak_log</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:stripped_spruce_log</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:stripped_warped_hyphae</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:stripped_warped_stem</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:structure_block</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:structure_void</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:sweet_berry_bush</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:tallgrass</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:target</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:tinted_glass</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:tnt</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:torch</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:trapdoor</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:trapped_chest</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:trip_wire</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:tripwire_hook</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:tuff</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:turtle_egg</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:twisting_vines</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:underwater_torch</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:undyed_shulker_box</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:unknown</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:unlit_redstone_torch</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:unpowered_comparator</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:unpowered_repeater</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:verdant_froglight</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:vine</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:wall_banner</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:wall_sign</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:warped_button</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:warped_door</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:warped_double_slab</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:warped_fence</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:warped_fence_gate</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:warped_fungus</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:warped_hyphae</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:warped_nylium</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:warped_planks</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:warped_pressure_plate</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:warped_roots</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:warped_slab</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:warped_stairs</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:warped_standing_sign</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:warped_stem</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:warped_trapdoor</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:warped_wall_sign</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:warped_wart_block</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:water</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:waterlily</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:waxed_copper</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:waxed_cut_copper</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:waxed_cut_copper_slab</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:waxed_cut_copper_stairs</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:waxed_double_cut_copper_slab</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:waxed_exposed_copper</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:waxed_exposed_cut_copper</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:waxed_exposed_cut_copper_slab</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:waxed_exposed_cut_copper_stairs</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:waxed_exposed_double_cut_copper_slab</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:waxed_oxidized_copper</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:waxed_oxidized_cut_copper</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:waxed_oxidized_cut_copper_slab</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:waxed_oxidized_cut_copper_stairs</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:waxed_oxidized_double_cut_copper_slab</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:waxed_weathered_copper</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:waxed_weathered_cut_copper</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:waxed_weathered_cut_copper_slab</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:waxed_weathered_cut_copper_stairs</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:waxed_weathered_double_cut_copper_slab</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:weathered_copper</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:weathered_cut_copper</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:weathered_cut_copper_slab</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:weathered_cut_copper_stairs</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:weathered_double_cut_copper_slab</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:web</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:weeping_vines</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:wheat</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:white_candle</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:white_candle_cake</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:white_glazed_terracotta</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:wither_rose</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:wood</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:wooden_button</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:wooden_door</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:wooden_pressure_plate</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:wooden_slab</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:wool</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:yellow_candle</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:yellow_candle_cake</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:yellow_flower</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecraft:yellow_glazed_terracotta</td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h1><p id="Entities">Entities</p></h1>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:4;">
<tr> <th style="border-style:solid; border-width:4;">Identifier</th> <th style="border-style:solid; border-width:4;">Full ID</th> <th style="border-style:solid; border-width:4;">Short ID</th> </tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">agent</td>
<td style="border-style:solid; border-width:4; padding:6px">312</td>
<td style="border-style:solid; border-width:4; padding:6px">56</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">allay</td>
<td style="border-style:solid; border-width:4; padding:6px">390</td>
<td style="border-style:solid; border-width:4; padding:6px">134</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">area_effect_cloud</td>
<td style="border-style:solid; border-width:4; padding:6px">95</td>
<td style="border-style:solid; border-width:4; padding:6px">95</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">armor_stand</td>
<td style="border-style:solid; border-width:4; padding:6px">317</td>
<td style="border-style:solid; border-width:4; padding:6px">61</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">arrow</td>
<td style="border-style:solid; border-width:4; padding:6px">12582992</td>
<td style="border-style:solid; border-width:4; padding:6px">80</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">axolotl</td>
<td style="border-style:solid; border-width:4; padding:6px">4994</td>
<td style="border-style:solid; border-width:4; padding:6px">130</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">balloon</td>
<td style="border-style:solid; border-width:4; padding:6px">107</td>
<td style="border-style:solid; border-width:4; padding:6px">107</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">bat</td>
<td style="border-style:solid; border-width:4; padding:6px">33043</td>
<td style="border-style:solid; border-width:4; padding:6px">19</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">bee</td>
<td style="border-style:solid; border-width:4; padding:6px">378</td>
<td style="border-style:solid; border-width:4; padding:6px">122</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">blaze</td>
<td style="border-style:solid; border-width:4; padding:6px">2859</td>
<td style="border-style:solid; border-width:4; padding:6px">43</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">boat</td>
<td style="border-style:solid; border-width:4; padding:6px">90</td>
<td style="border-style:solid; border-width:4; padding:6px">90</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">cat</td>
<td style="border-style:solid; border-width:4; padding:6px">21323</td>
<td style="border-style:solid; border-width:4; padding:6px">75</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">cave_spider</td>
<td style="border-style:solid; border-width:4; padding:6px">265000</td>
<td style="border-style:solid; border-width:4; padding:6px">40</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">chalkboard</td>
<td style="border-style:solid; border-width:4; padding:6px">78</td>
<td style="border-style:solid; border-width:4; padding:6px">78</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">chest_boat</td>
<td style="border-style:solid; border-width:4; padding:6px">218</td>
<td style="border-style:solid; border-width:4; padding:6px">218</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">chest_minecart</td>
<td style="border-style:solid; border-width:4; padding:6px">524386</td>
<td style="border-style:solid; border-width:4; padding:6px">98</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">chicken</td>
<td style="border-style:solid; border-width:4; padding:6px">4874</td>
<td style="border-style:solid; border-width:4; padding:6px">10</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">cod</td>
<td style="border-style:solid; border-width:4; padding:6px">9072</td>
<td style="border-style:solid; border-width:4; padding:6px">112</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">command_block_minecart</td>
<td style="border-style:solid; border-width:4; padding:6px">524388</td>
<td style="border-style:solid; border-width:4; padding:6px">100</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">cow</td>
<td style="border-style:solid; border-width:4; padding:6px">4875</td>
<td style="border-style:solid; border-width:4; padding:6px">11</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">creeper</td>
<td style="border-style:solid; border-width:4; padding:6px">2849</td>
<td style="border-style:solid; border-width:4; padding:6px">33</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">dolphin</td>
<td style="border-style:solid; border-width:4; padding:6px">8991</td>
<td style="border-style:solid; border-width:4; padding:6px">31</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">donkey</td>
<td style="border-style:solid; border-width:4; padding:6px">2118424</td>
<td style="border-style:solid; border-width:4; padding:6px">24</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">dragon_fireball</td>
<td style="border-style:solid; border-width:4; padding:6px">4194383</td>
<td style="border-style:solid; border-width:4; padding:6px">79</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">drowned</td>
<td style="border-style:solid; border-width:4; padding:6px">199534</td>
<td style="border-style:solid; border-width:4; padding:6px">110</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">egg</td>
<td style="border-style:solid; border-width:4; padding:6px">4194386</td>
<td style="border-style:solid; border-width:4; padding:6px">82</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">elder_guardian</td>
<td style="border-style:solid; border-width:4; padding:6px">2866</td>
<td style="border-style:solid; border-width:4; padding:6px">50</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">elder_guardian_ghost</td>
<td style="border-style:solid; border-width:4; padding:6px">2936</td>
<td style="border-style:solid; border-width:4; padding:6px">120</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">ender_crystal</td>
<td style="border-style:solid; border-width:4; padding:6px">71</td>
<td style="border-style:solid; border-width:4; padding:6px">71</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">ender_dragon</td>
<td style="border-style:solid; border-width:4; padding:6px">2869</td>
<td style="border-style:solid; border-width:4; padding:6px">53</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">ender_pearl</td>
<td style="border-style:solid; border-width:4; padding:6px">4194391</td>
<td style="border-style:solid; border-width:4; padding:6px">87</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">enderman</td>
<td style="border-style:solid; border-width:4; padding:6px">2854</td>
<td style="border-style:solid; border-width:4; padding:6px">38</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">endermite</td>
<td style="border-style:solid; border-width:4; padding:6px">265015</td>
<td style="border-style:solid; border-width:4; padding:6px">55</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">evocation_fang</td>
<td style="border-style:solid; border-width:4; padding:6px">4194407</td>
<td style="border-style:solid; border-width:4; padding:6px">103</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">evocation_illager</td>
<td style="border-style:solid; border-width:4; padding:6px">2920</td>
<td style="border-style:solid; border-width:4; padding:6px">104</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">eye_of_ender_signal</td>
<td style="border-style:solid; border-width:4; padding:6px">70</td>
<td style="border-style:solid; border-width:4; padding:6px">70</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">falling_block</td>
<td style="border-style:solid; border-width:4; padding:6px">66</td>
<td style="border-style:solid; border-width:4; padding:6px">66</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">fireball</td>
<td style="border-style:solid; border-width:4; padding:6px">4194389</td>
<td style="border-style:solid; border-width:4; padding:6px">85</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">fireworks_rocket</td>
<td style="border-style:solid; border-width:4; padding:6px">72</td>
<td style="border-style:solid; border-width:4; padding:6px">72</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">fishing_hook</td>
<td style="border-style:solid; border-width:4; padding:6px">77</td>
<td style="border-style:solid; border-width:4; padding:6px">77</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">fox</td>
<td style="border-style:solid; border-width:4; padding:6px">4985</td>
<td style="border-style:solid; border-width:4; padding:6px">121</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">frog</td>
<td style="border-style:solid; border-width:4; padding:6px">4996</td>
<td style="border-style:solid; border-width:4; padding:6px">132</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">ghast</td>
<td style="border-style:solid; border-width:4; padding:6px">2857</td>
<td style="border-style:solid; border-width:4; padding:6px">41</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">glow_squid</td>
<td style="border-style:solid; border-width:4; padding:6px">9089</td>
<td style="border-style:solid; border-width:4; padding:6px">129</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">goat</td>
<td style="border-style:solid; border-width:4; padding:6px">4992</td>
<td style="border-style:solid; border-width:4; padding:6px">128</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">guardian</td>
<td style="border-style:solid; border-width:4; padding:6px">2865</td>
<td style="border-style:solid; border-width:4; padding:6px">49</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">hoglin</td>
<td style="border-style:solid; border-width:4; padding:6px">4988</td>
<td style="border-style:solid; border-width:4; padding:6px">124</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">hopper_minecart</td>
<td style="border-style:solid; border-width:4; padding:6px">524384</td>
<td style="border-style:solid; border-width:4; padding:6px">96</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">horse</td>
<td style="border-style:solid; border-width:4; padding:6px">2118423</td>
<td style="border-style:solid; border-width:4; padding:6px">23</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">husk</td>
<td style="border-style:solid; border-width:4; padding:6px">199471</td>
<td style="border-style:solid; border-width:4; padding:6px">47</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">ice_bomb</td>
<td style="border-style:solid; border-width:4; padding:6px">4194410</td>
<td style="border-style:solid; border-width:4; padding:6px">106</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">iron_golem</td>
<td style="border-style:solid; border-width:4; padding:6px">788</td>
<td style="border-style:solid; border-width:4; padding:6px">20</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">item</td>
<td style="border-style:solid; border-width:4; padding:6px">64</td>
<td style="border-style:solid; border-width:4; padding:6px">64</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">leash_knot</td>
<td style="border-style:solid; border-width:4; padding:6px">88</td>
<td style="border-style:solid; border-width:4; padding:6px">88</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">lightning_bolt</td>
<td style="border-style:solid; border-width:4; padding:6px">93</td>
<td style="border-style:solid; border-width:4; padding:6px">93</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">lingering_potion</td>
<td style="border-style:solid; border-width:4; padding:6px">4194405</td>
<td style="border-style:solid; border-width:4; padding:6px">101</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">llama</td>
<td style="border-style:solid; border-width:4; padding:6px">4893</td>
<td style="border-style:solid; border-width:4; padding:6px">29</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">llama_spit</td>
<td style="border-style:solid; border-width:4; padding:6px">4194406</td>
<td style="border-style:solid; border-width:4; padding:6px">102</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">magma_cube</td>
<td style="border-style:solid; border-width:4; padding:6px">2858</td>
<td style="border-style:solid; border-width:4; padding:6px">42</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecart</td>
<td style="border-style:solid; border-width:4; padding:6px">524372</td>
<td style="border-style:solid; border-width:4; padding:6px">84</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">mooshroom</td>
<td style="border-style:solid; border-width:4; padding:6px">4880</td>
<td style="border-style:solid; border-width:4; padding:6px">16</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">moving_block</td>
<td style="border-style:solid; border-width:4; padding:6px">67</td>
<td style="border-style:solid; border-width:4; padding:6px">67</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">mule</td>
<td style="border-style:solid; border-width:4; padding:6px">2118425</td>
<td style="border-style:solid; border-width:4; padding:6px">25</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">npc</td>
<td style="border-style:solid; border-width:4; padding:6px">307</td>
<td style="border-style:solid; border-width:4; padding:6px">51</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">ocelot</td>
<td style="border-style:solid; border-width:4; padding:6px">21270</td>
<td style="border-style:solid; border-width:4; padding:6px">22</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">painting</td>
<td style="border-style:solid; border-width:4; padding:6px">83</td>
<td style="border-style:solid; border-width:4; padding:6px">83</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">panda</td>
<td style="border-style:solid; border-width:4; padding:6px">4977</td>
<td style="border-style:solid; border-width:4; padding:6px">113</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">parrot</td>
<td style="border-style:solid; border-width:4; padding:6px">21278</td>
<td style="border-style:solid; border-width:4; padding:6px">30</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">phantom</td>
<td style="border-style:solid; border-width:4; padding:6px">68410</td>
<td style="border-style:solid; border-width:4; padding:6px">58</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">pig</td>
<td style="border-style:solid; border-width:4; padding:6px">4876</td>
<td style="border-style:solid; border-width:4; padding:6px">12</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">piglin</td>
<td style="border-style:solid; border-width:4; padding:6px">379</td>
<td style="border-style:solid; border-width:4; padding:6px">123</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">piglin_brute</td>
<td style="border-style:solid; border-width:4; padding:6px">383</td>
<td style="border-style:solid; border-width:4; padding:6px">127</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">pillager</td>
<td style="border-style:solid; border-width:4; padding:6px">2930</td>
<td style="border-style:solid; border-width:4; padding:6px">114</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">player</td>
<td style="border-style:solid; border-width:4; padding:6px">319</td>
<td style="border-style:solid; border-width:4; padding:6px">63</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">polar_bear</td>
<td style="border-style:solid; border-width:4; padding:6px">4892</td>
<td style="border-style:solid; border-width:4; padding:6px">28</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">pufferfish</td>
<td style="border-style:solid; border-width:4; padding:6px">9068</td>
<td style="border-style:solid; border-width:4; padding:6px">108</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">rabbit</td>
<td style="border-style:solid; border-width:4; padding:6px">4882</td>
<td style="border-style:solid; border-width:4; padding:6px">18</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">ravager</td>
<td style="border-style:solid; border-width:4; padding:6px">2875</td>
<td style="border-style:solid; border-width:4; padding:6px">59</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">salmon</td>
<td style="border-style:solid; border-width:4; padding:6px">9069</td>
<td style="border-style:solid; border-width:4; padding:6px">109</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">sheep</td>
<td style="border-style:solid; border-width:4; padding:6px">4877</td>
<td style="border-style:solid; border-width:4; padding:6px">13</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">shield</td>
<td style="border-style:solid; border-width:4; padding:6px">117</td>
<td style="border-style:solid; border-width:4; padding:6px">117</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">shulker</td>
<td style="border-style:solid; border-width:4; padding:6px">2870</td>
<td style="border-style:solid; border-width:4; padding:6px">54</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">shulker_bullet</td>
<td style="border-style:solid; border-width:4; padding:6px">4194380</td>
<td style="border-style:solid; border-width:4; padding:6px">76</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">silverfish</td>
<td style="border-style:solid; border-width:4; padding:6px">264999</td>
<td style="border-style:solid; border-width:4; padding:6px">39</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">skeleton</td>
<td style="border-style:solid; border-width:4; padding:6px">1116962</td>
<td style="border-style:solid; border-width:4; padding:6px">34</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">skeleton_horse</td>
<td style="border-style:solid; border-width:4; padding:6px">2186010</td>
<td style="border-style:solid; border-width:4; padding:6px">26</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">slime</td>
<td style="border-style:solid; border-width:4; padding:6px">2853</td>
<td style="border-style:solid; border-width:4; padding:6px">37</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">small_fireball</td>
<td style="border-style:solid; border-width:4; padding:6px">4194398</td>
<td style="border-style:solid; border-width:4; padding:6px">94</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">snow_golem</td>
<td style="border-style:solid; border-width:4; padding:6px">789</td>
<td style="border-style:solid; border-width:4; padding:6px">21</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">snowball</td>
<td style="border-style:solid; border-width:4; padding:6px">4194385</td>
<td style="border-style:solid; border-width:4; padding:6px">81</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">spider</td>
<td style="border-style:solid; border-width:4; padding:6px">264995</td>
<td style="border-style:solid; border-width:4; padding:6px">35</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">splash_potion</td>
<td style="border-style:solid; border-width:4; padding:6px">4194390</td>
<td style="border-style:solid; border-width:4; padding:6px">86</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">squid</td>
<td style="border-style:solid; border-width:4; padding:6px">8977</td>
<td style="border-style:solid; border-width:4; padding:6px">17</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">stray</td>
<td style="border-style:solid; border-width:4; padding:6px">1116974</td>
<td style="border-style:solid; border-width:4; padding:6px">46</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">strider</td>
<td style="border-style:solid; border-width:4; padding:6px">4989</td>
<td style="border-style:solid; border-width:4; padding:6px">125</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">tadpole</td>
<td style="border-style:solid; border-width:4; padding:6px">9093</td>
<td style="border-style:solid; border-width:4; padding:6px">133</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">thrown_trident</td>
<td style="border-style:solid; border-width:4; padding:6px">12582985</td>
<td style="border-style:solid; border-width:4; padding:6px">73</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">tnt</td>
<td style="border-style:solid; border-width:4; padding:6px">65</td>
<td style="border-style:solid; border-width:4; padding:6px">65</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">tnt_minecart</td>
<td style="border-style:solid; border-width:4; padding:6px">524385</td>
<td style="border-style:solid; border-width:4; padding:6px">97</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">trader_llama</td>
<td style="border-style:solid; border-width:4; padding:6px">5021</td>
<td style="border-style:solid; border-width:4; padding:6px">157</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">tripod_camera</td>
<td style="border-style:solid; border-width:4; padding:6px">318</td>
<td style="border-style:solid; border-width:4; padding:6px">62</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">tropicalfish</td>
<td style="border-style:solid; border-width:4; padding:6px">9071</td>
<td style="border-style:solid; border-width:4; padding:6px">111</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">turtle</td>
<td style="border-style:solid; border-width:4; padding:6px">4938</td>
<td style="border-style:solid; border-width:4; padding:6px">74</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">vex</td>
<td style="border-style:solid; border-width:4; padding:6px">2921</td>
<td style="border-style:solid; border-width:4; padding:6px">105</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">villager</td>
<td style="border-style:solid; border-width:4; padding:6px">16777999</td>
<td style="border-style:solid; border-width:4; padding:6px">15</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">villager_v2</td>
<td style="border-style:solid; border-width:4; padding:6px">16778099</td>
<td style="border-style:solid; border-width:4; padding:6px">115</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">vindicator</td>
<td style="border-style:solid; border-width:4; padding:6px">2873</td>
<td style="border-style:solid; border-width:4; padding:6px">57</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">wandering_trader</td>
<td style="border-style:solid; border-width:4; padding:6px">886</td>
<td style="border-style:solid; border-width:4; padding:6px">118</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">warden</td>
<td style="border-style:solid; border-width:4; padding:6px">2947</td>
<td style="border-style:solid; border-width:4; padding:6px">131</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">witch</td>
<td style="border-style:solid; border-width:4; padding:6px">2861</td>
<td style="border-style:solid; border-width:4; padding:6px">45</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">wither</td>
<td style="border-style:solid; border-width:4; padding:6px">68404</td>
<td style="border-style:solid; border-width:4; padding:6px">52</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">wither_skeleton</td>
<td style="border-style:solid; border-width:4; padding:6px">1116976</td>
<td style="border-style:solid; border-width:4; padding:6px">48</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">wither_skull</td>
<td style="border-style:solid; border-width:4; padding:6px">4194393</td>
<td style="border-style:solid; border-width:4; padding:6px">89</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">wither_skull_dangerous</td>
<td style="border-style:solid; border-width:4; padding:6px">4194395</td>
<td style="border-style:solid; border-width:4; padding:6px">91</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">wolf</td>
<td style="border-style:solid; border-width:4; padding:6px">21262</td>
<td style="border-style:solid; border-width:4; padding:6px">14</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">xp_bottle</td>
<td style="border-style:solid; border-width:4; padding:6px">4194372</td>
<td style="border-style:solid; border-width:4; padding:6px">68</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">xp_orb</td>
<td style="border-style:solid; border-width:4; padding:6px">69</td>
<td style="border-style:solid; border-width:4; padding:6px">69</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">zoglin</td>
<td style="border-style:solid; border-width:4; padding:6px">68478</td>
<td style="border-style:solid; border-width:4; padding:6px">126</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">zombie</td>
<td style="border-style:solid; border-width:4; padding:6px">199456</td>
<td style="border-style:solid; border-width:4; padding:6px">32</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">zombie_horse</td>
<td style="border-style:solid; border-width:4; padding:6px">2186011</td>
<td style="border-style:solid; border-width:4; padding:6px">27</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">zombie_pigman</td>
<td style="border-style:solid; border-width:4; padding:6px">68388</td>
<td style="border-style:solid; border-width:4; padding:6px">36</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">zombie_villager</td>
<td style="border-style:solid; border-width:4; padding:6px">199468</td>
<td style="border-style:solid; border-width:4; padding:6px">44</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">zombie_villager_v2</td>
<td style="border-style:solid; border-width:4; padding:6px">199540</td>
<td style="border-style:solid; border-width:4; padding:6px">116</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h1><p id="Entity Damage Source">Entity Damage Source</p></h1>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:4;">
<tr> <th style="border-style:solid; border-width:4;">Damage Source</th> <th style="border-style:solid; border-width:4;">ID</th> </tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">all</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">anvil</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">block_explosion</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">charging</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">contact</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">drowning</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">entity_attack</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">entity_explosion</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">fall</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">falling_block</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">fire</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">fire_tick</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">fireworks</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">fly_into_wall</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">freezing</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">lava</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">lightning</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">magic</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">magma</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">none</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">override</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">piston</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">projectile</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">stalactite</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">stalagmite</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">starve</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">suffocation</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">suicide</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">temperature</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">thorns</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">void</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">wither</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h1><p id="Geometry">Geometry</p></h1>

<h1><p id="Blocks">Blocks</p></h1>

<h2></h2>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:3;">
<tr> <th style="border-style:solid; border-width:3;">Name</th> <th style="border-style:solid; border-width:3;">Type</th> <th style="border-style:solid; border-width:3;">Default Value</th> <th style="border-style:solid; border-width:3;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">elements</td>
<td style="border-style:solid; border-width:3; padding:7px">List</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">List of elements that make up the geometry of this block</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">boxes</td>
<td style="border-style:solid; border-width:2; padding:8px">List</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">List of cubes that make up the geometry of this element</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Default Value</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">faces</td>
<td style="border-style:solid; border-width:1; padding:9px">List</td>
<td style="border-style:solid; border-width:1; padding:9px"></td>
<td style="border-style:solid; border-width:1; padding:9px">List of the 6 faces of the box. If specified, there MUST be 6 faces (front, back, left side, right side, top, bottom)</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Default Value</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:10px">material</td>
<td style="border-style:solid; border-width:1; padding:10px">String</td>
<td style="border-style:solid; border-width:1; padding:10px"></td>
<td style="border-style:solid; border-width:1; padding:10px">The material of this face if different from the box's</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:10px">rotation</td>
<td style="border-style:solid; border-width:1; padding:10px">Decimal</td>
<td style="border-style:solid; border-width:1; padding:10px">0.0</td>
<td style="border-style:solid; border-width:1; padding:10px">UV Rotation of this face. Only acceptable values are 0, 90 and 270 degrees. This allows reusing a texture and just rotating it for different faces</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:10px">uv</td>
<td style="border-style:solid; border-width:1; padding:10px">Vector [a, b, c, d]</td>
<td style="border-style:solid; border-width:1; padding:10px">[ 0.0, 0.0, 1.0, 1.0 ]</td>
<td style="border-style:solid; border-width:1; padding:10px">Texture coordinates of this face, given as min x, min y, max x, max y withg values between 0.0 and 1.0</br></td>
</tr>
</table>
</td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">material</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px"></td>
<td style="border-style:solid; border-width:1; padding:9px">The material of this box if different from the element's</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">origin</td>
<td style="border-style:solid; border-width:1; padding:9px">Vector [a, b, c]</td>
<td style="border-style:solid; border-width:1; padding:9px">[ 0.0, 0.0, 0.0 ]</td>
<td style="border-style:solid; border-width:1; padding:9px">The position of the center of the box relative to the geometry</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">size</td>
<td style="border-style:solid; border-width:1; padding:9px">Vector [a, b, c]</td>
<td style="border-style:solid; border-width:1; padding:9px">[ 0, 0, 0 ]</td>
<td style="border-style:solid; border-width:1; padding:9px">Scale of the box in the x, y and z coordinates. A typical block is of scale 1, 1, 1</br></td>
</tr>
</table>
</td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">material</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">The material of this element if different from the block's</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">name</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">Name of the element</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">parent</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">Name of the parent element of this element. Pivot and box positions are made relative to the parent element's pivot</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">pivot</td>
<td style="border-style:solid; border-width:2; padding:8px">Vector [a, b, c]</td>
<td style="border-style:solid; border-width:2; padding:8px">[ 0.0, 0.0, 0.0 ]</td>
<td style="border-style:solid; border-width:2; padding:8px">Position in model space of the pivot point of the element. This is used as the "center" position of the element, as well as the point around which to rotate</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">rotation</td>
<td style="border-style:solid; border-width:2; padding:8px">Vector [a, b, c]</td>
<td style="border-style:solid; border-width:2; padding:8px">[ 0.0, 0.0, 0.0 ]</td>
<td style="border-style:solid; border-width:2; padding:8px">The rotation of this element about its pivot</br></td>
</tr>
</table>
</td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">format_version</td>
<td style="border-style:solid; border-width:3; padding:7px">String</td>
<td style="border-style:solid; border-width:3; padding:7px">0.0.0.0</td>
<td style="border-style:solid; border-width:3; padding:7px">Version of the block geometry being used. This is used to determine if backwards compatibility is needed</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">materials</td>
<td style="border-style:solid; border-width:3; padding:7px">List</td>
<td style="border-style:solid; border-width:3; padding:7px">#0</td>
<td style="border-style:solid; border-width:3; padding:7px">List of materials used by this model</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">parent</td>
<td style="border-style:solid; border-width:3; padding:7px">String</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Parent model of this model</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<br><br>

<h1><p id="Items">Items</p></h1>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:4;">
<tr> <th style="border-style:solid; border-width:4;">Name</th> <th style="border-style:solid; border-width:4;">ID</th> <th style="border-style:solid; border-width:4;">Aux Values</th> </tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">acacia_boat</td>
<td style="border-style:solid; border-width:4; padding:6px">379</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">acacia_button</td>
<td style="border-style:solid; border-width:4; padding:6px">-140</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">acacia_chest_boat</td>
<td style="border-style:solid; border-width:4; padding:6px">644</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">acacia_door</td>
<td style="border-style:solid; border-width:4; padding:6px">557</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">acacia_fence_gate</td>
<td style="border-style:solid; border-width:4; padding:6px">187</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">acacia_pressure_plate</td>
<td style="border-style:solid; border-width:4; padding:6px">-150</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">acacia_sign</td>
<td style="border-style:solid; border-width:4; padding:6px">580</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">acacia_stairs</td>
<td style="border-style:solid; border-width:4; padding:6px">163</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">acacia_standing_sign</td>
<td style="border-style:solid; border-width:4; padding:6px">-190</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">acacia_trapdoor</td>
<td style="border-style:solid; border-width:4; padding:6px">-145</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">acacia_wall_sign</td>
<td style="border-style:solid; border-width:4; padding:6px">-191</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">activator_rail</td>
<td style="border-style:solid; border-width:4; padding:6px">126</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">agent_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">488</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">air</td>
<td style="border-style:solid; border-width:4; padding:6px">-158</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">allay_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">633</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">allow</td>
<td style="border-style:solid; border-width:4; padding:6px">210</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">amethyst_block</td>
<td style="border-style:solid; border-width:4; padding:6px">-327</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">amethyst_cluster</td>
<td style="border-style:solid; border-width:4; padding:6px">-329</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">amethyst_shard</td>
<td style="border-style:solid; border-width:4; padding:6px">626</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">ancient_debris</td>
<td style="border-style:solid; border-width:4; padding:6px">-271</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">andesite_stairs</td>
<td style="border-style:solid; border-width:4; padding:6px">-171</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">anvil</td>
<td style="border-style:solid; border-width:4; padding:6px">145</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">apple</td>
<td style="border-style:solid; border-width:4; padding:6px">257</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">armor_stand</td>
<td style="border-style:solid; border-width:4; padding:6px">553</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">arrow</td>
<td style="border-style:solid; border-width:4; padding:6px">301</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">axolotl_bucket</td>
<td style="border-style:solid; border-width:4; padding:6px">369</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">axolotl_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">501</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">azalea</td>
<td style="border-style:solid; border-width:4; padding:6px">-337</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">azalea_leaves</td>
<td style="border-style:solid; border-width:4; padding:6px">-324</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">azalea_leaves_flowered</td>
<td style="border-style:solid; border-width:4; padding:6px">-325</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">baked_potato</td>
<td style="border-style:solid; border-width:4; padding:6px">281</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">balloon</td>
<td style="border-style:solid; border-width:4; padding:6px">600</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">bamboo</td>
<td style="border-style:solid; border-width:4; padding:6px">-163</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">bamboo_sapling</td>
<td style="border-style:solid; border-width:4; padding:6px">-164</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">banner</td>
<td style="border-style:solid; border-width:4; padding:6px">568</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">banner_pattern</td>
<td style="border-style:solid; border-width:4; padding:6px">653</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">barrel</td>
<td style="border-style:solid; border-width:4; padding:6px">-203</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">barrier</td>
<td style="border-style:solid; border-width:4; padding:6px">-161</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">basalt</td>
<td style="border-style:solid; border-width:4; padding:6px">-234</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">bat_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">453</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">beacon</td>
<td style="border-style:solid; border-width:4; padding:6px">138</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">bed</td>
<td style="border-style:solid; border-width:4; padding:6px">418</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">bedrock</td>
<td style="border-style:solid; border-width:4; padding:6px">7</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">bee_nest</td>
<td style="border-style:solid; border-width:4; padding:6px">-218</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">bee_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">495</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">beef</td>
<td style="border-style:solid; border-width:4; padding:6px">273</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">beehive</td>
<td style="border-style:solid; border-width:4; padding:6px">-219</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">beetroot</td>
<td style="border-style:solid; border-width:4; padding:6px">285</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">beetroot_seeds</td>
<td style="border-style:solid; border-width:4; padding:6px">295</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">beetroot_soup</td>
<td style="border-style:solid; border-width:4; padding:6px">286</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">bell</td>
<td style="border-style:solid; border-width:4; padding:6px">-206</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">big_dripleaf</td>
<td style="border-style:solid; border-width:4; padding:6px">-323</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">birch_boat</td>
<td style="border-style:solid; border-width:4; padding:6px">376</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">birch_button</td>
<td style="border-style:solid; border-width:4; padding:6px">-141</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">birch_chest_boat</td>
<td style="border-style:solid; border-width:4; padding:6px">641</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">birch_door</td>
<td style="border-style:solid; border-width:4; padding:6px">555</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">birch_fence_gate</td>
<td style="border-style:solid; border-width:4; padding:6px">184</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">birch_pressure_plate</td>
<td style="border-style:solid; border-width:4; padding:6px">-151</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">birch_sign</td>
<td style="border-style:solid; border-width:4; padding:6px">578</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">birch_stairs</td>
<td style="border-style:solid; border-width:4; padding:6px">135</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">birch_standing_sign</td>
<td style="border-style:solid; border-width:4; padding:6px">-186</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">birch_trapdoor</td>
<td style="border-style:solid; border-width:4; padding:6px">-146</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">birch_wall_sign</td>
<td style="border-style:solid; border-width:4; padding:6px">-187</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">black_candle</td>
<td style="border-style:solid; border-width:4; padding:6px">-428</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">black_candle_cake</td>
<td style="border-style:solid; border-width:4; padding:6px">-445</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">black_dye</td>
<td style="border-style:solid; border-width:4; padding:6px">395</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">black_glazed_terracotta</td>
<td style="border-style:solid; border-width:4; padding:6px">235</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">blackstone</td>
<td style="border-style:solid; border-width:4; padding:6px">-273</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">blackstone_double_slab</td>
<td style="border-style:solid; border-width:4; padding:6px">-283</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">blackstone_slab</td>
<td style="border-style:solid; border-width:4; padding:6px">-282</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">blackstone_stairs</td>
<td style="border-style:solid; border-width:4; padding:6px">-276</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">blackstone_wall</td>
<td style="border-style:solid; border-width:4; padding:6px">-277</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">blast_furnace</td>
<td style="border-style:solid; border-width:4; padding:6px">-196</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">blaze_powder</td>
<td style="border-style:solid; border-width:4; padding:6px">429</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">blaze_rod</td>
<td style="border-style:solid; border-width:4; padding:6px">423</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">blaze_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">456</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">bleach</td>
<td style="border-style:solid; border-width:4; padding:6px">598</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">blue_candle</td>
<td style="border-style:solid; border-width:4; padding:6px">-424</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">blue_candle_cake</td>
<td style="border-style:solid; border-width:4; padding:6px">-441</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">blue_dye</td>
<td style="border-style:solid; border-width:4; padding:6px">399</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">blue_glazed_terracotta</td>
<td style="border-style:solid; border-width:4; padding:6px">231</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">blue_ice</td>
<td style="border-style:solid; border-width:4; padding:6px">-11</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">boat</td>
<td style="border-style:solid; border-width:4; padding:6px">651</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">bone</td>
<td style="border-style:solid; border-width:4; padding:6px">415</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">bone_block</td>
<td style="border-style:solid; border-width:4; padding:6px">216</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">bone_meal</td>
<td style="border-style:solid; border-width:4; padding:6px">411</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">book</td>
<td style="border-style:solid; border-width:4; padding:6px">387</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">bookshelf</td>
<td style="border-style:solid; border-width:4; padding:6px">47</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">border_block</td>
<td style="border-style:solid; border-width:4; padding:6px">212</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">bordure_indented_banner_pattern</td>
<td style="border-style:solid; border-width:4; padding:6px">587</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">bow</td>
<td style="border-style:solid; border-width:4; padding:6px">300</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">bowl</td>
<td style="border-style:solid; border-width:4; padding:6px">321</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">bread</td>
<td style="border-style:solid; border-width:4; padding:6px">261</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">brewing_stand</td>
<td style="border-style:solid; border-width:4; padding:6px">431</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">brick</td>
<td style="border-style:solid; border-width:4; padding:6px">383</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">brick_block</td>
<td style="border-style:solid; border-width:4; padding:6px">45</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">brick_stairs</td>
<td style="border-style:solid; border-width:4; padding:6px">108</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">brown_candle</td>
<td style="border-style:solid; border-width:4; padding:6px">-425</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">brown_candle_cake</td>
<td style="border-style:solid; border-width:4; padding:6px">-442</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">brown_dye</td>
<td style="border-style:solid; border-width:4; padding:6px">398</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">brown_glazed_terracotta</td>
<td style="border-style:solid; border-width:4; padding:6px">232</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">brown_mushroom</td>
<td style="border-style:solid; border-width:4; padding:6px">39</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">brown_mushroom_block</td>
<td style="border-style:solid; border-width:4; padding:6px">99</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">bubble_column</td>
<td style="border-style:solid; border-width:4; padding:6px">-160</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">bucket</td>
<td style="border-style:solid; border-width:4; padding:6px">360</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">budding_amethyst</td>
<td style="border-style:solid; border-width:4; padding:6px">-328</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">cactus</td>
<td style="border-style:solid; border-width:4; padding:6px">81</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">cake</td>
<td style="border-style:solid; border-width:4; padding:6px">417</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">calcite</td>
<td style="border-style:solid; border-width:4; padding:6px">-326</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">camera</td>
<td style="border-style:solid; border-width:4; padding:6px">595</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">campfire</td>
<td style="border-style:solid; border-width:4; padding:6px">590</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">candle</td>
<td style="border-style:solid; border-width:4; padding:6px">-412</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">candle_cake</td>
<td style="border-style:solid; border-width:4; padding:6px">-429</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">carpet</td>
<td style="border-style:solid; border-width:4; padding:6px">171</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">carrot</td>
<td style="border-style:solid; border-width:4; padding:6px">279</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">carrot_on_a_stick</td>
<td style="border-style:solid; border-width:4; padding:6px">518</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">carrots</td>
<td style="border-style:solid; border-width:4; padding:6px">141</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">cartography_table</td>
<td style="border-style:solid; border-width:4; padding:6px">-200</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">carved_pumpkin</td>
<td style="border-style:solid; border-width:4; padding:6px">-155</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">cat_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">489</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">cauldron</td>
<td style="border-style:solid; border-width:4; padding:6px">432</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">cave_spider_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">457</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">cave_vines</td>
<td style="border-style:solid; border-width:4; padding:6px">-322</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">cave_vines_body_with_berries</td>
<td style="border-style:solid; border-width:4; padding:6px">-375</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">cave_vines_head_with_berries</td>
<td style="border-style:solid; border-width:4; padding:6px">-376</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">chain</td>
<td style="border-style:solid; border-width:4; padding:6px">621</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">chain_command_block</td>
<td style="border-style:solid; border-width:4; padding:6px">189</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">chainmail_boots</td>
<td style="border-style:solid; border-width:4; padding:6px">342</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">chainmail_chestplate</td>
<td style="border-style:solid; border-width:4; padding:6px">340</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">chainmail_helmet</td>
<td style="border-style:solid; border-width:4; padding:6px">339</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">chainmail_leggings</td>
<td style="border-style:solid; border-width:4; padding:6px">341</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">charcoal</td>
<td style="border-style:solid; border-width:4; padding:6px">303</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">chemical_heat</td>
<td style="border-style:solid; border-width:4; padding:6px">192</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">chemistry_table</td>
<td style="border-style:solid; border-width:4; padding:6px">238</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">chest</td>
<td style="border-style:solid; border-width:4; padding:6px">54</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">chest_boat</td>
<td style="border-style:solid; border-width:4; padding:6px">647</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">chest_minecart</td>
<td style="border-style:solid; border-width:4; padding:6px">389</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">chicken</td>
<td style="border-style:solid; border-width:4; padding:6px">275</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">chicken_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">435</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">chiseled_deepslate</td>
<td style="border-style:solid; border-width:4; padding:6px">-395</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">chiseled_nether_bricks</td>
<td style="border-style:solid; border-width:4; padding:6px">-302</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">chiseled_polished_blackstone</td>
<td style="border-style:solid; border-width:4; padding:6px">-279</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">chorus_flower</td>
<td style="border-style:solid; border-width:4; padding:6px">200</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">chorus_fruit</td>
<td style="border-style:solid; border-width:4; padding:6px">559</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">chorus_plant</td>
<td style="border-style:solid; border-width:4; padding:6px">240</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">clay</td>
<td style="border-style:solid; border-width:4; padding:6px">82</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">clay_ball</td>
<td style="border-style:solid; border-width:4; padding:6px">384</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">client_request_placeholder_block</td>
<td style="border-style:solid; border-width:4; padding:6px">-465</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">clock</td>
<td style="border-style:solid; border-width:4; padding:6px">393</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">coal</td>
<td style="border-style:solid; border-width:4; padding:6px">302</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">coal_block</td>
<td style="border-style:solid; border-width:4; padding:6px">173</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">coal_ore</td>
<td style="border-style:solid; border-width:4; padding:6px">16</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">cobbled_deepslate</td>
<td style="border-style:solid; border-width:4; padding:6px">-379</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">cobbled_deepslate_double_slab</td>
<td style="border-style:solid; border-width:4; padding:6px">-396</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">cobbled_deepslate_slab</td>
<td style="border-style:solid; border-width:4; padding:6px">-380</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">cobbled_deepslate_stairs</td>
<td style="border-style:solid; border-width:4; padding:6px">-381</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">cobbled_deepslate_wall</td>
<td style="border-style:solid; border-width:4; padding:6px">-382</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">cobblestone</td>
<td style="border-style:solid; border-width:4; padding:6px">4</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">cobblestone_wall</td>
<td style="border-style:solid; border-width:4; padding:6px">139</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">cocoa</td>
<td style="border-style:solid; border-width:4; padding:6px">127</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">cocoa_beans</td>
<td style="border-style:solid; border-width:4; padding:6px">412</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">cod</td>
<td style="border-style:solid; border-width:4; padding:6px">264</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">cod_bucket</td>
<td style="border-style:solid; border-width:4; padding:6px">364</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">cod_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">481</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">colored_torch_bp</td>
<td style="border-style:solid; border-width:4; padding:6px">204</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">colored_torch_rg</td>
<td style="border-style:solid; border-width:4; padding:6px">202</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">command_block</td>
<td style="border-style:solid; border-width:4; padding:6px">137</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">command_block_minecart</td>
<td style="border-style:solid; border-width:4; padding:6px">564</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">comparator</td>
<td style="border-style:solid; border-width:4; padding:6px">523</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">compass</td>
<td style="border-style:solid; border-width:4; padding:6px">391</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">composter</td>
<td style="border-style:solid; border-width:4; padding:6px">-213</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">compound</td>
<td style="border-style:solid; border-width:4; padding:6px">596</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">concrete</td>
<td style="border-style:solid; border-width:4; padding:6px">236</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">concrete_powder</td>
<td style="border-style:solid; border-width:4; padding:6px">237</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">conduit</td>
<td style="border-style:solid; border-width:4; padding:6px">-157</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">cooked_beef</td>
<td style="border-style:solid; border-width:4; padding:6px">274</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">cooked_chicken</td>
<td style="border-style:solid; border-width:4; padding:6px">276</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">cooked_cod</td>
<td style="border-style:solid; border-width:4; padding:6px">268</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">cooked_mutton</td>
<td style="border-style:solid; border-width:4; padding:6px">552</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">cooked_porkchop</td>
<td style="border-style:solid; border-width:4; padding:6px">263</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">cooked_rabbit</td>
<td style="border-style:solid; border-width:4; padding:6px">289</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">cooked_salmon</td>
<td style="border-style:solid; border-width:4; padding:6px">269</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">cookie</td>
<td style="border-style:solid; border-width:4; padding:6px">271</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">copper_block</td>
<td style="border-style:solid; border-width:4; padding:6px">-340</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">copper_ingot</td>
<td style="border-style:solid; border-width:4; padding:6px">505</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">copper_ore</td>
<td style="border-style:solid; border-width:4; padding:6px">-311</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">coral</td>
<td style="border-style:solid; border-width:4; padding:6px">-131</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">coral_block</td>
<td style="border-style:solid; border-width:4; padding:6px">-132</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">coral_fan</td>
<td style="border-style:solid; border-width:4; padding:6px">-133</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">coral_fan_dead</td>
<td style="border-style:solid; border-width:4; padding:6px">-134</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">coral_fan_hang</td>
<td style="border-style:solid; border-width:4; padding:6px">-135</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">coral_fan_hang2</td>
<td style="border-style:solid; border-width:4; padding:6px">-136</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">coral_fan_hang3</td>
<td style="border-style:solid; border-width:4; padding:6px">-137</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">cow_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">436</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">cracked_deepslate_bricks</td>
<td style="border-style:solid; border-width:4; padding:6px">-410</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">cracked_deepslate_tiles</td>
<td style="border-style:solid; border-width:4; padding:6px">-409</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">cracked_nether_bricks</td>
<td style="border-style:solid; border-width:4; padding:6px">-303</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">cracked_polished_blackstone_bricks</td>
<td style="border-style:solid; border-width:4; padding:6px">-280</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">crafting_table</td>
<td style="border-style:solid; border-width:4; padding:6px">58</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">creeper_banner_pattern</td>
<td style="border-style:solid; border-width:4; padding:6px">583</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">creeper_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">441</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">crimson_button</td>
<td style="border-style:solid; border-width:4; padding:6px">-260</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">crimson_door</td>
<td style="border-style:solid; border-width:4; padding:6px">618</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">crimson_double_slab</td>
<td style="border-style:solid; border-width:4; padding:6px">-266</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">crimson_fence</td>
<td style="border-style:solid; border-width:4; padding:6px">-256</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">crimson_fence_gate</td>
<td style="border-style:solid; border-width:4; padding:6px">-258</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">crimson_fungus</td>
<td style="border-style:solid; border-width:4; padding:6px">-228</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">crimson_hyphae</td>
<td style="border-style:solid; border-width:4; padding:6px">-299</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">crimson_nylium</td>
<td style="border-style:solid; border-width:4; padding:6px">-232</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">crimson_planks</td>
<td style="border-style:solid; border-width:4; padding:6px">-242</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">crimson_pressure_plate</td>
<td style="border-style:solid; border-width:4; padding:6px">-262</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">crimson_roots</td>
<td style="border-style:solid; border-width:4; padding:6px">-223</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">crimson_sign</td>
<td style="border-style:solid; border-width:4; padding:6px">616</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">crimson_slab</td>
<td style="border-style:solid; border-width:4; padding:6px">-264</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">crimson_stairs</td>
<td style="border-style:solid; border-width:4; padding:6px">-254</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">crimson_standing_sign</td>
<td style="border-style:solid; border-width:4; padding:6px">-250</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">crimson_stem</td>
<td style="border-style:solid; border-width:4; padding:6px">-225</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">crimson_trapdoor</td>
<td style="border-style:solid; border-width:4; padding:6px">-246</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">crimson_wall_sign</td>
<td style="border-style:solid; border-width:4; padding:6px">-252</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">crossbow</td>
<td style="border-style:solid; border-width:4; padding:6px">576</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">crying_obsidian</td>
<td style="border-style:solid; border-width:4; padding:6px">-289</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">cut_copper</td>
<td style="border-style:solid; border-width:4; padding:6px">-347</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">cut_copper_slab</td>
<td style="border-style:solid; border-width:4; padding:6px">-361</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">cut_copper_stairs</td>
<td style="border-style:solid; border-width:4; padding:6px">-354</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">cyan_candle</td>
<td style="border-style:solid; border-width:4; padding:6px">-422</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">cyan_candle_cake</td>
<td style="border-style:solid; border-width:4; padding:6px">-439</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">cyan_dye</td>
<td style="border-style:solid; border-width:4; padding:6px">401</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">cyan_glazed_terracotta</td>
<td style="border-style:solid; border-width:4; padding:6px">229</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">dark_oak_boat</td>
<td style="border-style:solid; border-width:4; padding:6px">380</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">dark_oak_button</td>
<td style="border-style:solid; border-width:4; padding:6px">-142</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">dark_oak_chest_boat</td>
<td style="border-style:solid; border-width:4; padding:6px">645</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">dark_oak_door</td>
<td style="border-style:solid; border-width:4; padding:6px">558</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">dark_oak_fence_gate</td>
<td style="border-style:solid; border-width:4; padding:6px">186</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">dark_oak_pressure_plate</td>
<td style="border-style:solid; border-width:4; padding:6px">-152</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">dark_oak_sign</td>
<td style="border-style:solid; border-width:4; padding:6px">581</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">dark_oak_stairs</td>
<td style="border-style:solid; border-width:4; padding:6px">164</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">dark_oak_trapdoor</td>
<td style="border-style:solid; border-width:4; padding:6px">-147</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">dark_prismarine_stairs</td>
<td style="border-style:solid; border-width:4; padding:6px">-3</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">darkoak_standing_sign</td>
<td style="border-style:solid; border-width:4; padding:6px">-192</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">darkoak_wall_sign</td>
<td style="border-style:solid; border-width:4; padding:6px">-193</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">daylight_detector</td>
<td style="border-style:solid; border-width:4; padding:6px">151</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">daylight_detector_inverted</td>
<td style="border-style:solid; border-width:4; padding:6px">178</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">deadbush</td>
<td style="border-style:solid; border-width:4; padding:6px">32</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">debug_stick</td>
<td style="border-style:solid; border-width:4; padding:6px">592</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">deepslate</td>
<td style="border-style:solid; border-width:4; padding:6px">-378</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">deepslate_brick_double_slab</td>
<td style="border-style:solid; border-width:4; padding:6px">-399</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">deepslate_brick_slab</td>
<td style="border-style:solid; border-width:4; padding:6px">-392</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">deepslate_brick_stairs</td>
<td style="border-style:solid; border-width:4; padding:6px">-393</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">deepslate_brick_wall</td>
<td style="border-style:solid; border-width:4; padding:6px">-394</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">deepslate_bricks</td>
<td style="border-style:solid; border-width:4; padding:6px">-391</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">deepslate_coal_ore</td>
<td style="border-style:solid; border-width:4; padding:6px">-406</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">deepslate_copper_ore</td>
<td style="border-style:solid; border-width:4; padding:6px">-408</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">deepslate_diamond_ore</td>
<td style="border-style:solid; border-width:4; padding:6px">-405</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">deepslate_emerald_ore</td>
<td style="border-style:solid; border-width:4; padding:6px">-407</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">deepslate_gold_ore</td>
<td style="border-style:solid; border-width:4; padding:6px">-402</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">deepslate_iron_ore</td>
<td style="border-style:solid; border-width:4; padding:6px">-401</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">deepslate_lapis_ore</td>
<td style="border-style:solid; border-width:4; padding:6px">-400</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">deepslate_redstone_ore</td>
<td style="border-style:solid; border-width:4; padding:6px">-403</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">deepslate_tile_double_slab</td>
<td style="border-style:solid; border-width:4; padding:6px">-398</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">deepslate_tile_slab</td>
<td style="border-style:solid; border-width:4; padding:6px">-388</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">deepslate_tile_stairs</td>
<td style="border-style:solid; border-width:4; padding:6px">-389</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">deepslate_tile_wall</td>
<td style="border-style:solid; border-width:4; padding:6px">-390</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">deepslate_tiles</td>
<td style="border-style:solid; border-width:4; padding:6px">-387</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">deny</td>
<td style="border-style:solid; border-width:4; padding:6px">211</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">detector_rail</td>
<td style="border-style:solid; border-width:4; padding:6px">28</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">diamond</td>
<td style="border-style:solid; border-width:4; padding:6px">304</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">diamond_axe</td>
<td style="border-style:solid; border-width:4; padding:6px">319</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">diamond_block</td>
<td style="border-style:solid; border-width:4; padding:6px">57</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">diamond_boots</td>
<td style="border-style:solid; border-width:4; padding:6px">350</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">diamond_chestplate</td>
<td style="border-style:solid; border-width:4; padding:6px">348</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">diamond_helmet</td>
<td style="border-style:solid; border-width:4; padding:6px">347</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">diamond_hoe</td>
<td style="border-style:solid; border-width:4; padding:6px">332</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">diamond_horse_armor</td>
<td style="border-style:solid; border-width:4; padding:6px">534</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">diamond_leggings</td>
<td style="border-style:solid; border-width:4; padding:6px">349</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">diamond_ore</td>
<td style="border-style:solid; border-width:4; padding:6px">56</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">diamond_pickaxe</td>
<td style="border-style:solid; border-width:4; padding:6px">318</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">diamond_shovel</td>
<td style="border-style:solid; border-width:4; padding:6px">317</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">diamond_sword</td>
<td style="border-style:solid; border-width:4; padding:6px">316</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">diorite_stairs</td>
<td style="border-style:solid; border-width:4; padding:6px">-170</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">dirt</td>
<td style="border-style:solid; border-width:4; padding:6px">3</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">dirt_with_roots</td>
<td style="border-style:solid; border-width:4; padding:6px">-318</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">disc_fragment_5</td>
<td style="border-style:solid; border-width:4; padding:6px">639</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">dispenser</td>
<td style="border-style:solid; border-width:4; padding:6px">23</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">dolphin_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">485</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">donkey_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">465</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">double_cut_copper_slab</td>
<td style="border-style:solid; border-width:4; padding:6px">-368</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">double_plant</td>
<td style="border-style:solid; border-width:4; padding:6px">175</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">double_stone_block_slab</td>
<td style="border-style:solid; border-width:4; padding:6px">43</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">double_stone_block_slab2</td>
<td style="border-style:solid; border-width:4; padding:6px">181</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">double_stone_block_slab3</td>
<td style="border-style:solid; border-width:4; padding:6px">-167</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">double_stone_block_slab4</td>
<td style="border-style:solid; border-width:4; padding:6px">-168</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">double_wooden_slab</td>
<td style="border-style:solid; border-width:4; padding:6px">157</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">dragon_breath</td>
<td style="border-style:solid; border-width:4; padding:6px">561</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">dragon_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">122</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">dried_kelp</td>
<td style="border-style:solid; border-width:4; padding:6px">270</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">dried_kelp_block</td>
<td style="border-style:solid; border-width:4; padding:6px">-139</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">dripstone_block</td>
<td style="border-style:solid; border-width:4; padding:6px">-317</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">dropper</td>
<td style="border-style:solid; border-width:4; padding:6px">125</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">drowned_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">484</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">dye</td>
<td style="border-style:solid; border-width:4; padding:6px">652</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">echo_shard</td>
<td style="border-style:solid; border-width:4; padding:6px">649</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">egg</td>
<td style="border-style:solid; border-width:4; padding:6px">390</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">elder_guardian_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">471</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_0</td>
<td style="border-style:solid; border-width:4; padding:6px">36</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_1</td>
<td style="border-style:solid; border-width:4; padding:6px">-12</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_10</td>
<td style="border-style:solid; border-width:4; padding:6px">-21</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_100</td>
<td style="border-style:solid; border-width:4; padding:6px">-111</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_101</td>
<td style="border-style:solid; border-width:4; padding:6px">-112</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_102</td>
<td style="border-style:solid; border-width:4; padding:6px">-113</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_103</td>
<td style="border-style:solid; border-width:4; padding:6px">-114</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_104</td>
<td style="border-style:solid; border-width:4; padding:6px">-115</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_105</td>
<td style="border-style:solid; border-width:4; padding:6px">-116</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_106</td>
<td style="border-style:solid; border-width:4; padding:6px">-117</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_107</td>
<td style="border-style:solid; border-width:4; padding:6px">-118</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_108</td>
<td style="border-style:solid; border-width:4; padding:6px">-119</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_109</td>
<td style="border-style:solid; border-width:4; padding:6px">-120</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_11</td>
<td style="border-style:solid; border-width:4; padding:6px">-22</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_110</td>
<td style="border-style:solid; border-width:4; padding:6px">-121</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_111</td>
<td style="border-style:solid; border-width:4; padding:6px">-122</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_112</td>
<td style="border-style:solid; border-width:4; padding:6px">-123</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_113</td>
<td style="border-style:solid; border-width:4; padding:6px">-124</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_114</td>
<td style="border-style:solid; border-width:4; padding:6px">-125</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_115</td>
<td style="border-style:solid; border-width:4; padding:6px">-126</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_116</td>
<td style="border-style:solid; border-width:4; padding:6px">-127</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_117</td>
<td style="border-style:solid; border-width:4; padding:6px">-128</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_118</td>
<td style="border-style:solid; border-width:4; padding:6px">-129</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_12</td>
<td style="border-style:solid; border-width:4; padding:6px">-23</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_13</td>
<td style="border-style:solid; border-width:4; padding:6px">-24</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_14</td>
<td style="border-style:solid; border-width:4; padding:6px">-25</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_15</td>
<td style="border-style:solid; border-width:4; padding:6px">-26</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_16</td>
<td style="border-style:solid; border-width:4; padding:6px">-27</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_17</td>
<td style="border-style:solid; border-width:4; padding:6px">-28</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_18</td>
<td style="border-style:solid; border-width:4; padding:6px">-29</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_19</td>
<td style="border-style:solid; border-width:4; padding:6px">-30</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_2</td>
<td style="border-style:solid; border-width:4; padding:6px">-13</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_20</td>
<td style="border-style:solid; border-width:4; padding:6px">-31</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_21</td>
<td style="border-style:solid; border-width:4; padding:6px">-32</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_22</td>
<td style="border-style:solid; border-width:4; padding:6px">-33</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_23</td>
<td style="border-style:solid; border-width:4; padding:6px">-34</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_24</td>
<td style="border-style:solid; border-width:4; padding:6px">-35</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_25</td>
<td style="border-style:solid; border-width:4; padding:6px">-36</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_26</td>
<td style="border-style:solid; border-width:4; padding:6px">-37</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_27</td>
<td style="border-style:solid; border-width:4; padding:6px">-38</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_28</td>
<td style="border-style:solid; border-width:4; padding:6px">-39</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_29</td>
<td style="border-style:solid; border-width:4; padding:6px">-40</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_3</td>
<td style="border-style:solid; border-width:4; padding:6px">-14</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_30</td>
<td style="border-style:solid; border-width:4; padding:6px">-41</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_31</td>
<td style="border-style:solid; border-width:4; padding:6px">-42</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_32</td>
<td style="border-style:solid; border-width:4; padding:6px">-43</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_33</td>
<td style="border-style:solid; border-width:4; padding:6px">-44</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_34</td>
<td style="border-style:solid; border-width:4; padding:6px">-45</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_35</td>
<td style="border-style:solid; border-width:4; padding:6px">-46</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_36</td>
<td style="border-style:solid; border-width:4; padding:6px">-47</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_37</td>
<td style="border-style:solid; border-width:4; padding:6px">-48</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_38</td>
<td style="border-style:solid; border-width:4; padding:6px">-49</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_39</td>
<td style="border-style:solid; border-width:4; padding:6px">-50</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_4</td>
<td style="border-style:solid; border-width:4; padding:6px">-15</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_40</td>
<td style="border-style:solid; border-width:4; padding:6px">-51</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_41</td>
<td style="border-style:solid; border-width:4; padding:6px">-52</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_42</td>
<td style="border-style:solid; border-width:4; padding:6px">-53</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_43</td>
<td style="border-style:solid; border-width:4; padding:6px">-54</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_44</td>
<td style="border-style:solid; border-width:4; padding:6px">-55</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_45</td>
<td style="border-style:solid; border-width:4; padding:6px">-56</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_46</td>
<td style="border-style:solid; border-width:4; padding:6px">-57</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_47</td>
<td style="border-style:solid; border-width:4; padding:6px">-58</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_48</td>
<td style="border-style:solid; border-width:4; padding:6px">-59</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_49</td>
<td style="border-style:solid; border-width:4; padding:6px">-60</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_5</td>
<td style="border-style:solid; border-width:4; padding:6px">-16</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_50</td>
<td style="border-style:solid; border-width:4; padding:6px">-61</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_51</td>
<td style="border-style:solid; border-width:4; padding:6px">-62</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_52</td>
<td style="border-style:solid; border-width:4; padding:6px">-63</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_53</td>
<td style="border-style:solid; border-width:4; padding:6px">-64</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_54</td>
<td style="border-style:solid; border-width:4; padding:6px">-65</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_55</td>
<td style="border-style:solid; border-width:4; padding:6px">-66</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_56</td>
<td style="border-style:solid; border-width:4; padding:6px">-67</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_57</td>
<td style="border-style:solid; border-width:4; padding:6px">-68</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_58</td>
<td style="border-style:solid; border-width:4; padding:6px">-69</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_59</td>
<td style="border-style:solid; border-width:4; padding:6px">-70</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_6</td>
<td style="border-style:solid; border-width:4; padding:6px">-17</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_60</td>
<td style="border-style:solid; border-width:4; padding:6px">-71</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_61</td>
<td style="border-style:solid; border-width:4; padding:6px">-72</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_62</td>
<td style="border-style:solid; border-width:4; padding:6px">-73</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_63</td>
<td style="border-style:solid; border-width:4; padding:6px">-74</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_64</td>
<td style="border-style:solid; border-width:4; padding:6px">-75</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_65</td>
<td style="border-style:solid; border-width:4; padding:6px">-76</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_66</td>
<td style="border-style:solid; border-width:4; padding:6px">-77</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_67</td>
<td style="border-style:solid; border-width:4; padding:6px">-78</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_68</td>
<td style="border-style:solid; border-width:4; padding:6px">-79</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_69</td>
<td style="border-style:solid; border-width:4; padding:6px">-80</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_7</td>
<td style="border-style:solid; border-width:4; padding:6px">-18</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_70</td>
<td style="border-style:solid; border-width:4; padding:6px">-81</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_71</td>
<td style="border-style:solid; border-width:4; padding:6px">-82</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_72</td>
<td style="border-style:solid; border-width:4; padding:6px">-83</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_73</td>
<td style="border-style:solid; border-width:4; padding:6px">-84</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_74</td>
<td style="border-style:solid; border-width:4; padding:6px">-85</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_75</td>
<td style="border-style:solid; border-width:4; padding:6px">-86</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_76</td>
<td style="border-style:solid; border-width:4; padding:6px">-87</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_77</td>
<td style="border-style:solid; border-width:4; padding:6px">-88</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_78</td>
<td style="border-style:solid; border-width:4; padding:6px">-89</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_79</td>
<td style="border-style:solid; border-width:4; padding:6px">-90</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_8</td>
<td style="border-style:solid; border-width:4; padding:6px">-19</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_80</td>
<td style="border-style:solid; border-width:4; padding:6px">-91</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_81</td>
<td style="border-style:solid; border-width:4; padding:6px">-92</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_82</td>
<td style="border-style:solid; border-width:4; padding:6px">-93</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_83</td>
<td style="border-style:solid; border-width:4; padding:6px">-94</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_84</td>
<td style="border-style:solid; border-width:4; padding:6px">-95</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_85</td>
<td style="border-style:solid; border-width:4; padding:6px">-96</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_86</td>
<td style="border-style:solid; border-width:4; padding:6px">-97</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_87</td>
<td style="border-style:solid; border-width:4; padding:6px">-98</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_88</td>
<td style="border-style:solid; border-width:4; padding:6px">-99</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_89</td>
<td style="border-style:solid; border-width:4; padding:6px">-100</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_9</td>
<td style="border-style:solid; border-width:4; padding:6px">-20</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_90</td>
<td style="border-style:solid; border-width:4; padding:6px">-101</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_91</td>
<td style="border-style:solid; border-width:4; padding:6px">-102</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_92</td>
<td style="border-style:solid; border-width:4; padding:6px">-103</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_93</td>
<td style="border-style:solid; border-width:4; padding:6px">-104</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_94</td>
<td style="border-style:solid; border-width:4; padding:6px">-105</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_95</td>
<td style="border-style:solid; border-width:4; padding:6px">-106</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_96</td>
<td style="border-style:solid; border-width:4; padding:6px">-107</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_97</td>
<td style="border-style:solid; border-width:4; padding:6px">-108</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_98</td>
<td style="border-style:solid; border-width:4; padding:6px">-109</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">element_99</td>
<td style="border-style:solid; border-width:4; padding:6px">-110</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">elytra</td>
<td style="border-style:solid; border-width:4; padding:6px">565</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">emerald</td>
<td style="border-style:solid; border-width:4; padding:6px">513</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">emerald_block</td>
<td style="border-style:solid; border-width:4; padding:6px">133</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">emerald_ore</td>
<td style="border-style:solid; border-width:4; padding:6px">129</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">empty_map</td>
<td style="border-style:solid; border-width:4; padding:6px">516</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">enchanted_book</td>
<td style="border-style:solid; border-width:4; padding:6px">522</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">enchanted_golden_apple</td>
<td style="border-style:solid; border-width:4; padding:6px">259</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">enchanting_table</td>
<td style="border-style:solid; border-width:4; padding:6px">116</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">end_brick_stairs</td>
<td style="border-style:solid; border-width:4; padding:6px">-178</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">end_bricks</td>
<td style="border-style:solid; border-width:4; padding:6px">206</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">end_crystal</td>
<td style="border-style:solid; border-width:4; padding:6px">655</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">end_gateway</td>
<td style="border-style:solid; border-width:4; padding:6px">209</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">end_portal</td>
<td style="border-style:solid; border-width:4; padding:6px">119</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">end_portal_frame</td>
<td style="border-style:solid; border-width:4; padding:6px">120</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">end_rod</td>
<td style="border-style:solid; border-width:4; padding:6px">208</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">end_stone</td>
<td style="border-style:solid; border-width:4; padding:6px">121</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">ender_chest</td>
<td style="border-style:solid; border-width:4; padding:6px">130</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">ender_eye</td>
<td style="border-style:solid; border-width:4; padding:6px">433</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">ender_pearl</td>
<td style="border-style:solid; border-width:4; padding:6px">422</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">enderman_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">442</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">endermite_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">460</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">evoker_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">476</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">experience_bottle</td>
<td style="border-style:solid; border-width:4; padding:6px">509</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">exposed_copper</td>
<td style="border-style:solid; border-width:4; padding:6px">-341</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">exposed_cut_copper</td>
<td style="border-style:solid; border-width:4; padding:6px">-348</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">exposed_cut_copper_slab</td>
<td style="border-style:solid; border-width:4; padding:6px">-362</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">exposed_cut_copper_stairs</td>
<td style="border-style:solid; border-width:4; padding:6px">-355</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">exposed_double_cut_copper_slab</td>
<td style="border-style:solid; border-width:4; padding:6px">-369</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">farmland</td>
<td style="border-style:solid; border-width:4; padding:6px">60</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">feather</td>
<td style="border-style:solid; border-width:4; padding:6px">327</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">fence</td>
<td style="border-style:solid; border-width:4; padding:6px">85</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">fence_gate</td>
<td style="border-style:solid; border-width:4; padding:6px">107</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">fermented_spider_eye</td>
<td style="border-style:solid; border-width:4; padding:6px">428</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">field_masoned_banner_pattern</td>
<td style="border-style:solid; border-width:4; padding:6px">586</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">filled_map</td>
<td style="border-style:solid; border-width:4; padding:6px">420</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">fire</td>
<td style="border-style:solid; border-width:4; padding:6px">51</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">fire_charge</td>
<td style="border-style:solid; border-width:4; padding:6px">510</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">firework_rocket</td>
<td style="border-style:solid; border-width:4; padding:6px">520</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">firework_star</td>
<td style="border-style:solid; border-width:4; padding:6px">521</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">fishing_rod</td>
<td style="border-style:solid; border-width:4; padding:6px">392</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">fletching_table</td>
<td style="border-style:solid; border-width:4; padding:6px">-201</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">flint</td>
<td style="border-style:solid; border-width:4; padding:6px">356</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">flint_and_steel</td>
<td style="border-style:solid; border-width:4; padding:6px">299</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">flower_banner_pattern</td>
<td style="border-style:solid; border-width:4; padding:6px">582</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">flower_pot</td>
<td style="border-style:solid; border-width:4; padding:6px">515</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">flowering_azalea</td>
<td style="border-style:solid; border-width:4; padding:6px">-338</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">flowing_lava</td>
<td style="border-style:solid; border-width:4; padding:6px">10</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">flowing_water</td>
<td style="border-style:solid; border-width:4; padding:6px">8</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">fox_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">491</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">frame</td>
<td style="border-style:solid; border-width:4; padding:6px">514</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">frog_spawn</td>
<td style="border-style:solid; border-width:4; padding:6px">-468</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">frog_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">630</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">frosted_ice</td>
<td style="border-style:solid; border-width:4; padding:6px">207</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">furnace</td>
<td style="border-style:solid; border-width:4; padding:6px">61</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">ghast_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">454</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">ghast_tear</td>
<td style="border-style:solid; border-width:4; padding:6px">424</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">gilded_blackstone</td>
<td style="border-style:solid; border-width:4; padding:6px">-281</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">glass</td>
<td style="border-style:solid; border-width:4; padding:6px">20</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">glass_bottle</td>
<td style="border-style:solid; border-width:4; padding:6px">427</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">glass_pane</td>
<td style="border-style:solid; border-width:4; padding:6px">102</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">glistering_melon_slice</td>
<td style="border-style:solid; border-width:4; padding:6px">434</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">globe_banner_pattern</td>
<td style="border-style:solid; border-width:4; padding:6px">589</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">glow_frame</td>
<td style="border-style:solid; border-width:4; padding:6px">625</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">glow_ink_sac</td>
<td style="border-style:solid; border-width:4; padding:6px">504</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">glow_lichen</td>
<td style="border-style:solid; border-width:4; padding:6px">-411</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">glow_squid_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">503</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">glow_stick</td>
<td style="border-style:solid; border-width:4; padding:6px">603</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">glowingobsidian</td>
<td style="border-style:solid; border-width:4; padding:6px">246</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">glowstone</td>
<td style="border-style:solid; border-width:4; padding:6px">89</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">glowstone_dust</td>
<td style="border-style:solid; border-width:4; padding:6px">394</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">goat_horn</td>
<td style="border-style:solid; border-width:4; padding:6px">629</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">goat_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">502</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">gold_block</td>
<td style="border-style:solid; border-width:4; padding:6px">41</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">gold_ingot</td>
<td style="border-style:solid; border-width:4; padding:6px">306</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">gold_nugget</td>
<td style="border-style:solid; border-width:4; padding:6px">425</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">gold_ore</td>
<td style="border-style:solid; border-width:4; padding:6px">14</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">golden_apple</td>
<td style="border-style:solid; border-width:4; padding:6px">258</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">golden_axe</td>
<td style="border-style:solid; border-width:4; padding:6px">325</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">golden_boots</td>
<td style="border-style:solid; border-width:4; padding:6px">354</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">golden_carrot</td>
<td style="border-style:solid; border-width:4; padding:6px">283</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">golden_chestplate</td>
<td style="border-style:solid; border-width:4; padding:6px">352</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">golden_helmet</td>
<td style="border-style:solid; border-width:4; padding:6px">351</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">golden_hoe</td>
<td style="border-style:solid; border-width:4; padding:6px">333</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">golden_horse_armor</td>
<td style="border-style:solid; border-width:4; padding:6px">533</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">golden_leggings</td>
<td style="border-style:solid; border-width:4; padding:6px">353</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">golden_pickaxe</td>
<td style="border-style:solid; border-width:4; padding:6px">324</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">golden_rail</td>
<td style="border-style:solid; border-width:4; padding:6px">27</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">golden_shovel</td>
<td style="border-style:solid; border-width:4; padding:6px">323</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">golden_sword</td>
<td style="border-style:solid; border-width:4; padding:6px">322</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">granite_stairs</td>
<td style="border-style:solid; border-width:4; padding:6px">-169</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">grass</td>
<td style="border-style:solid; border-width:4; padding:6px">2</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">grass_path</td>
<td style="border-style:solid; border-width:4; padding:6px">198</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">gravel</td>
<td style="border-style:solid; border-width:4; padding:6px">13</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">gray_candle</td>
<td style="border-style:solid; border-width:4; padding:6px">-420</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">gray_candle_cake</td>
<td style="border-style:solid; border-width:4; padding:6px">-437</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">gray_dye</td>
<td style="border-style:solid; border-width:4; padding:6px">403</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">gray_glazed_terracotta</td>
<td style="border-style:solid; border-width:4; padding:6px">227</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">green_candle</td>
<td style="border-style:solid; border-width:4; padding:6px">-426</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">green_candle_cake</td>
<td style="border-style:solid; border-width:4; padding:6px">-443</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">green_dye</td>
<td style="border-style:solid; border-width:4; padding:6px">397</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">green_glazed_terracotta</td>
<td style="border-style:solid; border-width:4; padding:6px">233</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">grindstone</td>
<td style="border-style:solid; border-width:4; padding:6px">-195</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">guardian_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">461</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">gunpowder</td>
<td style="border-style:solid; border-width:4; padding:6px">328</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">hanging_roots</td>
<td style="border-style:solid; border-width:4; padding:6px">-319</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">hard_glass</td>
<td style="border-style:solid; border-width:4; padding:6px">253</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">hard_glass_pane</td>
<td style="border-style:solid; border-width:4; padding:6px">190</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">hard_stained_glass</td>
<td style="border-style:solid; border-width:4; padding:6px">254</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">hard_stained_glass_pane</td>
<td style="border-style:solid; border-width:4; padding:6px">191</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">hardened_clay</td>
<td style="border-style:solid; border-width:4; padding:6px">172</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">hay_block</td>
<td style="border-style:solid; border-width:4; padding:6px">170</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">heart_of_the_sea</td>
<td style="border-style:solid; border-width:4; padding:6px">572</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">heavy_weighted_pressure_plate</td>
<td style="border-style:solid; border-width:4; padding:6px">148</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">hoglin_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">497</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">honey_block</td>
<td style="border-style:solid; border-width:4; padding:6px">-220</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">honey_bottle</td>
<td style="border-style:solid; border-width:4; padding:6px">594</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">honeycomb</td>
<td style="border-style:solid; border-width:4; padding:6px">593</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">honeycomb_block</td>
<td style="border-style:solid; border-width:4; padding:6px">-221</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">hopper</td>
<td style="border-style:solid; border-width:4; padding:6px">528</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">hopper_minecart</td>
<td style="border-style:solid; border-width:4; padding:6px">527</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">horse_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">458</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">husk_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">463</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">ice</td>
<td style="border-style:solid; border-width:4; padding:6px">79</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">ice_bomb</td>
<td style="border-style:solid; border-width:4; padding:6px">597</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">infested_deepslate</td>
<td style="border-style:solid; border-width:4; padding:6px">-454</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">info_update</td>
<td style="border-style:solid; border-width:4; padding:6px">248</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">info_update2</td>
<td style="border-style:solid; border-width:4; padding:6px">249</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">ink_sac</td>
<td style="border-style:solid; border-width:4; padding:6px">413</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">invisible_bedrock</td>
<td style="border-style:solid; border-width:4; padding:6px">95</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">iron_axe</td>
<td style="border-style:solid; border-width:4; padding:6px">298</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">iron_bars</td>
<td style="border-style:solid; border-width:4; padding:6px">101</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">iron_block</td>
<td style="border-style:solid; border-width:4; padding:6px">42</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">iron_boots</td>
<td style="border-style:solid; border-width:4; padding:6px">346</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">iron_chestplate</td>
<td style="border-style:solid; border-width:4; padding:6px">344</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">iron_door</td>
<td style="border-style:solid; border-width:4; padding:6px">372</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">iron_helmet</td>
<td style="border-style:solid; border-width:4; padding:6px">343</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">iron_hoe</td>
<td style="border-style:solid; border-width:4; padding:6px">331</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">iron_horse_armor</td>
<td style="border-style:solid; border-width:4; padding:6px">532</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">iron_ingot</td>
<td style="border-style:solid; border-width:4; padding:6px">305</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">iron_leggings</td>
<td style="border-style:solid; border-width:4; padding:6px">345</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">iron_nugget</td>
<td style="border-style:solid; border-width:4; padding:6px">570</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">iron_ore</td>
<td style="border-style:solid; border-width:4; padding:6px">15</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">iron_pickaxe</td>
<td style="border-style:solid; border-width:4; padding:6px">297</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">iron_shovel</td>
<td style="border-style:solid; border-width:4; padding:6px">296</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">iron_sword</td>
<td style="border-style:solid; border-width:4; padding:6px">307</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">iron_trapdoor</td>
<td style="border-style:solid; border-width:4; padding:6px">167</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">item.acacia_door</td>
<td style="border-style:solid; border-width:4; padding:6px">196</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">item.bed</td>
<td style="border-style:solid; border-width:4; padding:6px">26</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">item.beetroot</td>
<td style="border-style:solid; border-width:4; padding:6px">244</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">item.birch_door</td>
<td style="border-style:solid; border-width:4; padding:6px">194</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">item.brewing_stand</td>
<td style="border-style:solid; border-width:4; padding:6px">117</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">item.cake</td>
<td style="border-style:solid; border-width:4; padding:6px">92</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">item.camera</td>
<td style="border-style:solid; border-width:4; padding:6px">242</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">item.campfire</td>
<td style="border-style:solid; border-width:4; padding:6px">-209</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">item.cauldron</td>
<td style="border-style:solid; border-width:4; padding:6px">118</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">item.chain</td>
<td style="border-style:solid; border-width:4; padding:6px">-286</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">item.crimson_door</td>
<td style="border-style:solid; border-width:4; padding:6px">-244</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">item.dark_oak_door</td>
<td style="border-style:solid; border-width:4; padding:6px">197</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">item.flower_pot</td>
<td style="border-style:solid; border-width:4; padding:6px">140</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">item.frame</td>
<td style="border-style:solid; border-width:4; padding:6px">199</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">item.glow_frame</td>
<td style="border-style:solid; border-width:4; padding:6px">-339</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">item.hopper</td>
<td style="border-style:solid; border-width:4; padding:6px">154</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">item.iron_door</td>
<td style="border-style:solid; border-width:4; padding:6px">71</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">item.jungle_door</td>
<td style="border-style:solid; border-width:4; padding:6px">195</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">item.kelp</td>
<td style="border-style:solid; border-width:4; padding:6px">-138</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">item.mangrove_door</td>
<td style="border-style:solid; border-width:4; padding:6px">-493</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">item.nether_sprouts</td>
<td style="border-style:solid; border-width:4; padding:6px">-238</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">item.nether_wart</td>
<td style="border-style:solid; border-width:4; padding:6px">115</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">item.reeds</td>
<td style="border-style:solid; border-width:4; padding:6px">83</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">item.skull</td>
<td style="border-style:solid; border-width:4; padding:6px">144</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">item.soul_campfire</td>
<td style="border-style:solid; border-width:4; padding:6px">-290</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">item.spruce_door</td>
<td style="border-style:solid; border-width:4; padding:6px">193</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">item.warped_door</td>
<td style="border-style:solid; border-width:4; padding:6px">-245</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">item.wheat</td>
<td style="border-style:solid; border-width:4; padding:6px">59</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">item.wooden_door</td>
<td style="border-style:solid; border-width:4; padding:6px">64</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">jigsaw</td>
<td style="border-style:solid; border-width:4; padding:6px">-211</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">jukebox</td>
<td style="border-style:solid; border-width:4; padding:6px">84</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">jungle_boat</td>
<td style="border-style:solid; border-width:4; padding:6px">377</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">jungle_button</td>
<td style="border-style:solid; border-width:4; padding:6px">-143</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">jungle_chest_boat</td>
<td style="border-style:solid; border-width:4; padding:6px">642</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">jungle_door</td>
<td style="border-style:solid; border-width:4; padding:6px">556</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">jungle_fence_gate</td>
<td style="border-style:solid; border-width:4; padding:6px">185</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">jungle_pressure_plate</td>
<td style="border-style:solid; border-width:4; padding:6px">-153</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">jungle_sign</td>
<td style="border-style:solid; border-width:4; padding:6px">579</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">jungle_stairs</td>
<td style="border-style:solid; border-width:4; padding:6px">136</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">jungle_standing_sign</td>
<td style="border-style:solid; border-width:4; padding:6px">-188</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">jungle_trapdoor</td>
<td style="border-style:solid; border-width:4; padding:6px">-148</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">jungle_wall_sign</td>
<td style="border-style:solid; border-width:4; padding:6px">-189</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">kelp</td>
<td style="border-style:solid; border-width:4; padding:6px">382</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">ladder</td>
<td style="border-style:solid; border-width:4; padding:6px">65</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">lantern</td>
<td style="border-style:solid; border-width:4; padding:6px">-208</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">lapis_block</td>
<td style="border-style:solid; border-width:4; padding:6px">22</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">lapis_lazuli</td>
<td style="border-style:solid; border-width:4; padding:6px">414</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">lapis_ore</td>
<td style="border-style:solid; border-width:4; padding:6px">21</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">large_amethyst_bud</td>
<td style="border-style:solid; border-width:4; padding:6px">-330</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">lava</td>
<td style="border-style:solid; border-width:4; padding:6px">11</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">lava_bucket</td>
<td style="border-style:solid; border-width:4; padding:6px">363</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">lava_cauldron</td>
<td style="border-style:solid; border-width:4; padding:6px">-210</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">lead</td>
<td style="border-style:solid; border-width:4; padding:6px">548</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">leather</td>
<td style="border-style:solid; border-width:4; padding:6px">381</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">leather_boots</td>
<td style="border-style:solid; border-width:4; padding:6px">338</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">leather_chestplate</td>
<td style="border-style:solid; border-width:4; padding:6px">336</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">leather_helmet</td>
<td style="border-style:solid; border-width:4; padding:6px">335</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">leather_horse_armor</td>
<td style="border-style:solid; border-width:4; padding:6px">531</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">leather_leggings</td>
<td style="border-style:solid; border-width:4; padding:6px">337</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">leaves</td>
<td style="border-style:solid; border-width:4; padding:6px">18</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">leaves2</td>
<td style="border-style:solid; border-width:4; padding:6px">161</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">lectern</td>
<td style="border-style:solid; border-width:4; padding:6px">-194</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">lever</td>
<td style="border-style:solid; border-width:4; padding:6px">69</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">light_block</td>
<td style="border-style:solid; border-width:4; padding:6px">-215</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">light_blue_candle</td>
<td style="border-style:solid; border-width:4; padding:6px">-416</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">light_blue_candle_cake</td>
<td style="border-style:solid; border-width:4; padding:6px">-433</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">light_blue_dye</td>
<td style="border-style:solid; border-width:4; padding:6px">407</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">light_blue_glazed_terracotta</td>
<td style="border-style:solid; border-width:4; padding:6px">223</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">light_gray_candle</td>
<td style="border-style:solid; border-width:4; padding:6px">-421</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">light_gray_candle_cake</td>
<td style="border-style:solid; border-width:4; padding:6px">-438</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">light_gray_dye</td>
<td style="border-style:solid; border-width:4; padding:6px">402</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">light_weighted_pressure_plate</td>
<td style="border-style:solid; border-width:4; padding:6px">147</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">lightning_rod</td>
<td style="border-style:solid; border-width:4; padding:6px">-312</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">lime_candle</td>
<td style="border-style:solid; border-width:4; padding:6px">-418</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">lime_candle_cake</td>
<td style="border-style:solid; border-width:4; padding:6px">-435</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">lime_dye</td>
<td style="border-style:solid; border-width:4; padding:6px">405</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">lime_glazed_terracotta</td>
<td style="border-style:solid; border-width:4; padding:6px">225</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">lingering_potion</td>
<td style="border-style:solid; border-width:4; padding:6px">563</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">lit_blast_furnace</td>
<td style="border-style:solid; border-width:4; padding:6px">-214</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">lit_deepslate_redstone_ore</td>
<td style="border-style:solid; border-width:4; padding:6px">-404</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">lit_furnace</td>
<td style="border-style:solid; border-width:4; padding:6px">62</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">lit_pumpkin</td>
<td style="border-style:solid; border-width:4; padding:6px">91</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">lit_redstone_lamp</td>
<td style="border-style:solid; border-width:4; padding:6px">124</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">lit_redstone_ore</td>
<td style="border-style:solid; border-width:4; padding:6px">74</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">lit_smoker</td>
<td style="border-style:solid; border-width:4; padding:6px">-199</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">llama_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">473</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">lodestone</td>
<td style="border-style:solid; border-width:4; padding:6px">-222</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">lodestone_compass</td>
<td style="border-style:solid; border-width:4; padding:6px">604</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">log</td>
<td style="border-style:solid; border-width:4; padding:6px">17</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">log2</td>
<td style="border-style:solid; border-width:4; padding:6px">162</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">loom</td>
<td style="border-style:solid; border-width:4; padding:6px">-204</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">magenta_candle</td>
<td style="border-style:solid; border-width:4; padding:6px">-415</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">magenta_candle_cake</td>
<td style="border-style:solid; border-width:4; padding:6px">-432</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">magenta_dye</td>
<td style="border-style:solid; border-width:4; padding:6px">408</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">magenta_glazed_terracotta</td>
<td style="border-style:solid; border-width:4; padding:6px">222</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">magma</td>
<td style="border-style:solid; border-width:4; padding:6px">213</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">magma_cream</td>
<td style="border-style:solid; border-width:4; padding:6px">430</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">magma_cube_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">455</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">mangrove_boat</td>
<td style="border-style:solid; border-width:4; padding:6px">637</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">mangrove_button</td>
<td style="border-style:solid; border-width:4; padding:6px">-487</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">mangrove_chest_boat</td>
<td style="border-style:solid; border-width:4; padding:6px">646</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">mangrove_door</td>
<td style="border-style:solid; border-width:4; padding:6px">635</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">mangrove_double_slab</td>
<td style="border-style:solid; border-width:4; padding:6px">-499</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">mangrove_fence</td>
<td style="border-style:solid; border-width:4; padding:6px">-491</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">mangrove_fence_gate</td>
<td style="border-style:solid; border-width:4; padding:6px">-492</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">mangrove_leaves</td>
<td style="border-style:solid; border-width:4; padding:6px">-472</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">mangrove_log</td>
<td style="border-style:solid; border-width:4; padding:6px">-484</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">mangrove_planks</td>
<td style="border-style:solid; border-width:4; padding:6px">-486</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">mangrove_pressure_plate</td>
<td style="border-style:solid; border-width:4; padding:6px">-490</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">mangrove_propagule</td>
<td style="border-style:solid; border-width:4; padding:6px">-474</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">mangrove_roots</td>
<td style="border-style:solid; border-width:4; padding:6px">-482</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">mangrove_sign</td>
<td style="border-style:solid; border-width:4; padding:6px">636</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">mangrove_slab</td>
<td style="border-style:solid; border-width:4; padding:6px">-489</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">mangrove_stairs</td>
<td style="border-style:solid; border-width:4; padding:6px">-488</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">mangrove_standing_sign</td>
<td style="border-style:solid; border-width:4; padding:6px">-494</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">mangrove_trapdoor</td>
<td style="border-style:solid; border-width:4; padding:6px">-496</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">mangrove_wall_sign</td>
<td style="border-style:solid; border-width:4; padding:6px">-495</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">mangrove_wood</td>
<td style="border-style:solid; border-width:4; padding:6px">-497</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">medicine</td>
<td style="border-style:solid; border-width:4; padding:6px">601</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">medium_amethyst_bud</td>
<td style="border-style:solid; border-width:4; padding:6px">-331</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">melon_block</td>
<td style="border-style:solid; border-width:4; padding:6px">103</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">melon_seeds</td>
<td style="border-style:solid; border-width:4; padding:6px">293</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">melon_slice</td>
<td style="border-style:solid; border-width:4; padding:6px">272</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">melon_stem</td>
<td style="border-style:solid; border-width:4; padding:6px">105</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">milk_bucket</td>
<td style="border-style:solid; border-width:4; padding:6px">361</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">minecart</td>
<td style="border-style:solid; border-width:4; padding:6px">370</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">mob_spawner</td>
<td style="border-style:solid; border-width:4; padding:6px">52</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">mojang_banner_pattern</td>
<td style="border-style:solid; border-width:4; padding:6px">585</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">monster_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">97</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">mooshroom_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">440</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">moss_block</td>
<td style="border-style:solid; border-width:4; padding:6px">-320</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">moss_carpet</td>
<td style="border-style:solid; border-width:4; padding:6px">-335</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">mossy_cobblestone</td>
<td style="border-style:solid; border-width:4; padding:6px">48</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">mossy_cobblestone_stairs</td>
<td style="border-style:solid; border-width:4; padding:6px">-179</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">mossy_stone_brick_stairs</td>
<td style="border-style:solid; border-width:4; padding:6px">-175</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">moving_block</td>
<td style="border-style:solid; border-width:4; padding:6px">250</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">mud</td>
<td style="border-style:solid; border-width:4; padding:6px">-473</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">mud_brick_double_slab</td>
<td style="border-style:solid; border-width:4; padding:6px">-479</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">mud_brick_slab</td>
<td style="border-style:solid; border-width:4; padding:6px">-478</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">mud_brick_stairs</td>
<td style="border-style:solid; border-width:4; padding:6px">-480</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">mud_brick_wall</td>
<td style="border-style:solid; border-width:4; padding:6px">-481</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">mud_bricks</td>
<td style="border-style:solid; border-width:4; padding:6px">-475</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">muddy_mangrove_roots</td>
<td style="border-style:solid; border-width:4; padding:6px">-483</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">mule_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">466</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">mushroom_stew</td>
<td style="border-style:solid; border-width:4; padding:6px">260</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">music_disc_11</td>
<td style="border-style:solid; border-width:4; padding:6px">545</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">music_disc_13</td>
<td style="border-style:solid; border-width:4; padding:6px">535</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">music_disc_5</td>
<td style="border-style:solid; border-width:4; padding:6px">638</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">music_disc_blocks</td>
<td style="border-style:solid; border-width:4; padding:6px">537</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">music_disc_cat</td>
<td style="border-style:solid; border-width:4; padding:6px">536</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">music_disc_chirp</td>
<td style="border-style:solid; border-width:4; padding:6px">538</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">music_disc_far</td>
<td style="border-style:solid; border-width:4; padding:6px">539</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">music_disc_mall</td>
<td style="border-style:solid; border-width:4; padding:6px">540</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">music_disc_mellohi</td>
<td style="border-style:solid; border-width:4; padding:6px">541</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">music_disc_otherside</td>
<td style="border-style:solid; border-width:4; padding:6px">628</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">music_disc_pigstep</td>
<td style="border-style:solid; border-width:4; padding:6px">622</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">music_disc_stal</td>
<td style="border-style:solid; border-width:4; padding:6px">542</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">music_disc_strad</td>
<td style="border-style:solid; border-width:4; padding:6px">543</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">music_disc_wait</td>
<td style="border-style:solid; border-width:4; padding:6px">546</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">music_disc_ward</td>
<td style="border-style:solid; border-width:4; padding:6px">544</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">mutton</td>
<td style="border-style:solid; border-width:4; padding:6px">551</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">mycelium</td>
<td style="border-style:solid; border-width:4; padding:6px">110</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">name_tag</td>
<td style="border-style:solid; border-width:4; padding:6px">549</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">nautilus_shell</td>
<td style="border-style:solid; border-width:4; padding:6px">571</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">nether_brick</td>
<td style="border-style:solid; border-width:4; padding:6px">112</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">nether_brick_fence</td>
<td style="border-style:solid; border-width:4; padding:6px">113</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">nether_brick_stairs</td>
<td style="border-style:solid; border-width:4; padding:6px">114</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">nether_gold_ore</td>
<td style="border-style:solid; border-width:4; padding:6px">-288</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">nether_sprouts</td>
<td style="border-style:solid; border-width:4; padding:6px">623</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">nether_star</td>
<td style="border-style:solid; border-width:4; padding:6px">519</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">nether_wart</td>
<td style="border-style:solid; border-width:4; padding:6px">294</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">nether_wart_block</td>
<td style="border-style:solid; border-width:4; padding:6px">214</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">netherbrick</td>
<td style="border-style:solid; border-width:4; padding:6px">524</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">netherite_axe</td>
<td style="border-style:solid; border-width:4; padding:6px">609</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">netherite_block</td>
<td style="border-style:solid; border-width:4; padding:6px">-270</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">netherite_boots</td>
<td style="border-style:solid; border-width:4; padding:6px">614</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">netherite_chestplate</td>
<td style="border-style:solid; border-width:4; padding:6px">612</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">netherite_helmet</td>
<td style="border-style:solid; border-width:4; padding:6px">611</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">netherite_hoe</td>
<td style="border-style:solid; border-width:4; padding:6px">610</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">netherite_ingot</td>
<td style="border-style:solid; border-width:4; padding:6px">605</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">netherite_leggings</td>
<td style="border-style:solid; border-width:4; padding:6px">613</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">netherite_pickaxe</td>
<td style="border-style:solid; border-width:4; padding:6px">608</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">netherite_scrap</td>
<td style="border-style:solid; border-width:4; padding:6px">615</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">netherite_shovel</td>
<td style="border-style:solid; border-width:4; padding:6px">607</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">netherite_sword</td>
<td style="border-style:solid; border-width:4; padding:6px">606</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">netherrack</td>
<td style="border-style:solid; border-width:4; padding:6px">87</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">netherreactor</td>
<td style="border-style:solid; border-width:4; padding:6px">247</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">normal_stone_stairs</td>
<td style="border-style:solid; border-width:4; padding:6px">-180</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">noteblock</td>
<td style="border-style:solid; border-width:4; padding:6px">25</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">npc_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">470</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">oak_boat</td>
<td style="border-style:solid; border-width:4; padding:6px">375</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">oak_chest_boat</td>
<td style="border-style:solid; border-width:4; padding:6px">640</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">oak_sign</td>
<td style="border-style:solid; border-width:4; padding:6px">358</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">oak_stairs</td>
<td style="border-style:solid; border-width:4; padding:6px">53</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">observer</td>
<td style="border-style:solid; border-width:4; padding:6px">251</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">obsidian</td>
<td style="border-style:solid; border-width:4; padding:6px">49</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">ocelot_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">451</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">ochre_froglight</td>
<td style="border-style:solid; border-width:4; padding:6px">-471</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">orange_candle</td>
<td style="border-style:solid; border-width:4; padding:6px">-414</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">orange_candle_cake</td>
<td style="border-style:solid; border-width:4; padding:6px">-431</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">orange_dye</td>
<td style="border-style:solid; border-width:4; padding:6px">409</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">orange_glazed_terracotta</td>
<td style="border-style:solid; border-width:4; padding:6px">221</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">oxidized_copper</td>
<td style="border-style:solid; border-width:4; padding:6px">-343</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">oxidized_cut_copper</td>
<td style="border-style:solid; border-width:4; padding:6px">-350</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">oxidized_cut_copper_slab</td>
<td style="border-style:solid; border-width:4; padding:6px">-364</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">oxidized_cut_copper_stairs</td>
<td style="border-style:solid; border-width:4; padding:6px">-357</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">oxidized_double_cut_copper_slab</td>
<td style="border-style:solid; border-width:4; padding:6px">-371</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">packed_ice</td>
<td style="border-style:solid; border-width:4; padding:6px">174</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">packed_mud</td>
<td style="border-style:solid; border-width:4; padding:6px">-477</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">painting</td>
<td style="border-style:solid; border-width:4; padding:6px">357</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">panda_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">490</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">paper</td>
<td style="border-style:solid; border-width:4; padding:6px">386</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">parrot_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">479</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">pearlescent_froglight</td>
<td style="border-style:solid; border-width:4; padding:6px">-469</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">phantom_membrane</td>
<td style="border-style:solid; border-width:4; padding:6px">575</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">phantom_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">487</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">pig_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">437</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">piglin_banner_pattern</td>
<td style="border-style:solid; border-width:4; padding:6px">588</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">piglin_brute_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">500</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">piglin_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">498</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">pillager_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">492</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">pink_candle</td>
<td style="border-style:solid; border-width:4; padding:6px">-419</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">pink_candle_cake</td>
<td style="border-style:solid; border-width:4; padding:6px">-436</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">pink_dye</td>
<td style="border-style:solid; border-width:4; padding:6px">404</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">pink_glazed_terracotta</td>
<td style="border-style:solid; border-width:4; padding:6px">226</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">piston</td>
<td style="border-style:solid; border-width:4; padding:6px">33</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">piston_arm_collision</td>
<td style="border-style:solid; border-width:4; padding:6px">34</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">planks</td>
<td style="border-style:solid; border-width:4; padding:6px">5</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">podzol</td>
<td style="border-style:solid; border-width:4; padding:6px">243</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">pointed_dripstone</td>
<td style="border-style:solid; border-width:4; padding:6px">-308</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">poisonous_potato</td>
<td style="border-style:solid; border-width:4; padding:6px">282</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">polar_bear_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">472</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">polished_andesite_stairs</td>
<td style="border-style:solid; border-width:4; padding:6px">-174</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">polished_basalt</td>
<td style="border-style:solid; border-width:4; padding:6px">-235</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">polished_blackstone</td>
<td style="border-style:solid; border-width:4; padding:6px">-291</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">polished_blackstone_brick_double_slab</td>
<td style="border-style:solid; border-width:4; padding:6px">-285</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">polished_blackstone_brick_slab</td>
<td style="border-style:solid; border-width:4; padding:6px">-284</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">polished_blackstone_brick_stairs</td>
<td style="border-style:solid; border-width:4; padding:6px">-275</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">polished_blackstone_brick_wall</td>
<td style="border-style:solid; border-width:4; padding:6px">-278</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">polished_blackstone_bricks</td>
<td style="border-style:solid; border-width:4; padding:6px">-274</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">polished_blackstone_button</td>
<td style="border-style:solid; border-width:4; padding:6px">-296</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">polished_blackstone_double_slab</td>
<td style="border-style:solid; border-width:4; padding:6px">-294</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">polished_blackstone_pressure_plate</td>
<td style="border-style:solid; border-width:4; padding:6px">-295</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">polished_blackstone_slab</td>
<td style="border-style:solid; border-width:4; padding:6px">-293</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">polished_blackstone_stairs</td>
<td style="border-style:solid; border-width:4; padding:6px">-292</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">polished_blackstone_wall</td>
<td style="border-style:solid; border-width:4; padding:6px">-297</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">polished_deepslate</td>
<td style="border-style:solid; border-width:4; padding:6px">-383</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">polished_deepslate_double_slab</td>
<td style="border-style:solid; border-width:4; padding:6px">-397</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">polished_deepslate_slab</td>
<td style="border-style:solid; border-width:4; padding:6px">-384</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">polished_deepslate_stairs</td>
<td style="border-style:solid; border-width:4; padding:6px">-385</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">polished_deepslate_wall</td>
<td style="border-style:solid; border-width:4; padding:6px">-386</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">polished_diorite_stairs</td>
<td style="border-style:solid; border-width:4; padding:6px">-173</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">polished_granite_stairs</td>
<td style="border-style:solid; border-width:4; padding:6px">-172</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">popped_chorus_fruit</td>
<td style="border-style:solid; border-width:4; padding:6px">560</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">porkchop</td>
<td style="border-style:solid; border-width:4; padding:6px">262</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">portal</td>
<td style="border-style:solid; border-width:4; padding:6px">90</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">potato</td>
<td style="border-style:solid; border-width:4; padding:6px">280</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">potatoes</td>
<td style="border-style:solid; border-width:4; padding:6px">142</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">potion</td>
<td style="border-style:solid; border-width:4; padding:6px">426</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">powder_snow</td>
<td style="border-style:solid; border-width:4; padding:6px">-306</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">powder_snow_bucket</td>
<td style="border-style:solid; border-width:4; padding:6px">368</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">powered_comparator</td>
<td style="border-style:solid; border-width:4; padding:6px">150</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">powered_repeater</td>
<td style="border-style:solid; border-width:4; padding:6px">94</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">prismarine</td>
<td style="border-style:solid; border-width:4; padding:6px">168</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">prismarine_bricks_stairs</td>
<td style="border-style:solid; border-width:4; padding:6px">-4</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">prismarine_crystals</td>
<td style="border-style:solid; border-width:4; padding:6px">550</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">prismarine_shard</td>
<td style="border-style:solid; border-width:4; padding:6px">566</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">prismarine_stairs</td>
<td style="border-style:solid; border-width:4; padding:6px">-2</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">pufferfish</td>
<td style="border-style:solid; border-width:4; padding:6px">267</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">pufferfish_bucket</td>
<td style="border-style:solid; border-width:4; padding:6px">367</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">pufferfish_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">482</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">pumpkin</td>
<td style="border-style:solid; border-width:4; padding:6px">86</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">pumpkin_pie</td>
<td style="border-style:solid; border-width:4; padding:6px">284</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">pumpkin_seeds</td>
<td style="border-style:solid; border-width:4; padding:6px">292</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">pumpkin_stem</td>
<td style="border-style:solid; border-width:4; padding:6px">104</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">purple_candle</td>
<td style="border-style:solid; border-width:4; padding:6px">-423</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">purple_candle_cake</td>
<td style="border-style:solid; border-width:4; padding:6px">-440</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">purple_dye</td>
<td style="border-style:solid; border-width:4; padding:6px">400</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">purple_glazed_terracotta</td>
<td style="border-style:solid; border-width:4; padding:6px">219</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">purpur_block</td>
<td style="border-style:solid; border-width:4; padding:6px">201</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">purpur_stairs</td>
<td style="border-style:solid; border-width:4; padding:6px">203</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">quartz</td>
<td style="border-style:solid; border-width:4; padding:6px">525</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">quartz_block</td>
<td style="border-style:solid; border-width:4; padding:6px">155</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">quartz_bricks</td>
<td style="border-style:solid; border-width:4; padding:6px">-304</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">quartz_ore</td>
<td style="border-style:solid; border-width:4; padding:6px">153</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">quartz_stairs</td>
<td style="border-style:solid; border-width:4; padding:6px">156</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">rabbit</td>
<td style="border-style:solid; border-width:4; padding:6px">288</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">rabbit_foot</td>
<td style="border-style:solid; border-width:4; padding:6px">529</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">rabbit_hide</td>
<td style="border-style:solid; border-width:4; padding:6px">530</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">rabbit_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">459</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">rabbit_stew</td>
<td style="border-style:solid; border-width:4; padding:6px">290</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">rail</td>
<td style="border-style:solid; border-width:4; padding:6px">66</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">rapid_fertilizer</td>
<td style="border-style:solid; border-width:4; padding:6px">599</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">ravager_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">494</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">raw_copper</td>
<td style="border-style:solid; border-width:4; padding:6px">508</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">raw_copper_block</td>
<td style="border-style:solid; border-width:4; padding:6px">-452</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">raw_gold</td>
<td style="border-style:solid; border-width:4; padding:6px">507</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">raw_gold_block</td>
<td style="border-style:solid; border-width:4; padding:6px">-453</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">raw_iron</td>
<td style="border-style:solid; border-width:4; padding:6px">506</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">raw_iron_block</td>
<td style="border-style:solid; border-width:4; padding:6px">-451</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">recovery_compass</td>
<td style="border-style:solid; border-width:4; padding:6px">648</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">red_candle</td>
<td style="border-style:solid; border-width:4; padding:6px">-427</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">red_candle_cake</td>
<td style="border-style:solid; border-width:4; padding:6px">-444</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">red_dye</td>
<td style="border-style:solid; border-width:4; padding:6px">396</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">red_flower</td>
<td style="border-style:solid; border-width:4; padding:6px">38</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">red_glazed_terracotta</td>
<td style="border-style:solid; border-width:4; padding:6px">234</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">red_mushroom</td>
<td style="border-style:solid; border-width:4; padding:6px">40</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">red_mushroom_block</td>
<td style="border-style:solid; border-width:4; padding:6px">100</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">red_nether_brick</td>
<td style="border-style:solid; border-width:4; padding:6px">215</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">red_nether_brick_stairs</td>
<td style="border-style:solid; border-width:4; padding:6px">-184</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">red_sandstone</td>
<td style="border-style:solid; border-width:4; padding:6px">179</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">red_sandstone_stairs</td>
<td style="border-style:solid; border-width:4; padding:6px">180</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">redstone</td>
<td style="border-style:solid; border-width:4; padding:6px">373</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">redstone_block</td>
<td style="border-style:solid; border-width:4; padding:6px">152</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">redstone_lamp</td>
<td style="border-style:solid; border-width:4; padding:6px">123</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">redstone_ore</td>
<td style="border-style:solid; border-width:4; padding:6px">73</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">redstone_torch</td>
<td style="border-style:solid; border-width:4; padding:6px">76</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">redstone_wire</td>
<td style="border-style:solid; border-width:4; padding:6px">55</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">reinforced_deepslate</td>
<td style="border-style:solid; border-width:4; padding:6px">-466</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">repeater</td>
<td style="border-style:solid; border-width:4; padding:6px">419</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">repeating_command_block</td>
<td style="border-style:solid; border-width:4; padding:6px">188</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">reserved6</td>
<td style="border-style:solid; border-width:4; padding:6px">255</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">respawn_anchor</td>
<td style="border-style:solid; border-width:4; padding:6px">-272</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">rotten_flesh</td>
<td style="border-style:solid; border-width:4; padding:6px">277</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">saddle</td>
<td style="border-style:solid; border-width:4; padding:6px">371</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">salmon</td>
<td style="border-style:solid; border-width:4; padding:6px">265</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">salmon_bucket</td>
<td style="border-style:solid; border-width:4; padding:6px">365</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">salmon_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">483</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">sand</td>
<td style="border-style:solid; border-width:4; padding:6px">12</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">sandstone</td>
<td style="border-style:solid; border-width:4; padding:6px">24</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">sandstone_stairs</td>
<td style="border-style:solid; border-width:4; padding:6px">128</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">sapling</td>
<td style="border-style:solid; border-width:4; padding:6px">6</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">scaffolding</td>
<td style="border-style:solid; border-width:4; padding:6px">-165</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">sculk</td>
<td style="border-style:solid; border-width:4; padding:6px">-458</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">sculk_catalyst</td>
<td style="border-style:solid; border-width:4; padding:6px">-460</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">sculk_sensor</td>
<td style="border-style:solid; border-width:4; padding:6px">-307</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">sculk_shrieker</td>
<td style="border-style:solid; border-width:4; padding:6px">-461</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">sculk_vein</td>
<td style="border-style:solid; border-width:4; padding:6px">-459</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">scute</td>
<td style="border-style:solid; border-width:4; padding:6px">573</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">sea_lantern</td>
<td style="border-style:solid; border-width:4; padding:6px">169</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">sea_pickle</td>
<td style="border-style:solid; border-width:4; padding:6px">-156</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">seagrass</td>
<td style="border-style:solid; border-width:4; padding:6px">-130</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">shears</td>
<td style="border-style:solid; border-width:4; padding:6px">421</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">sheep_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">438</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">shield</td>
<td style="border-style:solid; border-width:4; padding:6px">355</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">shroomlight</td>
<td style="border-style:solid; border-width:4; padding:6px">-230</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">shulker_box</td>
<td style="border-style:solid; border-width:4; padding:6px">218</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">shulker_shell</td>
<td style="border-style:solid; border-width:4; padding:6px">567</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">shulker_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">469</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">silver_glazed_terracotta</td>
<td style="border-style:solid; border-width:4; padding:6px">228</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">silverfish_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">443</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">skeleton_horse_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">467</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">skeleton_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">444</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">skull</td>
<td style="border-style:solid; border-width:4; padding:6px">517</td>
<td style="border-style:solid; border-width:4; padding:6px">0 = Skeleton</br></br>1 = Wither</br></br>2 = Zombie</br></br>3 = Steve</br></br>4 = Creeper</br></br>5 = Dragon</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">skull_banner_pattern</td>
<td style="border-style:solid; border-width:4; padding:6px">584</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">slime</td>
<td style="border-style:solid; border-width:4; padding:6px">165</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">slime_ball</td>
<td style="border-style:solid; border-width:4; padding:6px">388</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">slime_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">445</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">small_amethyst_bud</td>
<td style="border-style:solid; border-width:4; padding:6px">-332</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">small_dripleaf_block</td>
<td style="border-style:solid; border-width:4; padding:6px">-336</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">smithing_table</td>
<td style="border-style:solid; border-width:4; padding:6px">-202</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">smoker</td>
<td style="border-style:solid; border-width:4; padding:6px">-198</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">smooth_basalt</td>
<td style="border-style:solid; border-width:4; padding:6px">-377</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">smooth_quartz_stairs</td>
<td style="border-style:solid; border-width:4; padding:6px">-185</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">smooth_red_sandstone_stairs</td>
<td style="border-style:solid; border-width:4; padding:6px">-176</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">smooth_sandstone_stairs</td>
<td style="border-style:solid; border-width:4; padding:6px">-177</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">smooth_stone</td>
<td style="border-style:solid; border-width:4; padding:6px">-183</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">snow</td>
<td style="border-style:solid; border-width:4; padding:6px">80</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">snow_layer</td>
<td style="border-style:solid; border-width:4; padding:6px">78</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">snowball</td>
<td style="border-style:solid; border-width:4; padding:6px">374</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">soul_campfire</td>
<td style="border-style:solid; border-width:4; padding:6px">624</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">soul_fire</td>
<td style="border-style:solid; border-width:4; padding:6px">-237</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">soul_lantern</td>
<td style="border-style:solid; border-width:4; padding:6px">-269</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">soul_sand</td>
<td style="border-style:solid; border-width:4; padding:6px">88</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">soul_soil</td>
<td style="border-style:solid; border-width:4; padding:6px">-236</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">soul_torch</td>
<td style="border-style:solid; border-width:4; padding:6px">-268</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">sparkler</td>
<td style="border-style:solid; border-width:4; padding:6px">602</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">654</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">spider_eye</td>
<td style="border-style:solid; border-width:4; padding:6px">278</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">spider_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">446</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">splash_potion</td>
<td style="border-style:solid; border-width:4; padding:6px">562</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">sponge</td>
<td style="border-style:solid; border-width:4; padding:6px">19</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">spore_blossom</td>
<td style="border-style:solid; border-width:4; padding:6px">-321</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">spruce_boat</td>
<td style="border-style:solid; border-width:4; padding:6px">378</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">spruce_button</td>
<td style="border-style:solid; border-width:4; padding:6px">-144</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">spruce_chest_boat</td>
<td style="border-style:solid; border-width:4; padding:6px">643</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">spruce_door</td>
<td style="border-style:solid; border-width:4; padding:6px">554</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">spruce_fence_gate</td>
<td style="border-style:solid; border-width:4; padding:6px">183</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">spruce_pressure_plate</td>
<td style="border-style:solid; border-width:4; padding:6px">-154</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">spruce_sign</td>
<td style="border-style:solid; border-width:4; padding:6px">577</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">spruce_stairs</td>
<td style="border-style:solid; border-width:4; padding:6px">134</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">spruce_standing_sign</td>
<td style="border-style:solid; border-width:4; padding:6px">-181</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">spruce_trapdoor</td>
<td style="border-style:solid; border-width:4; padding:6px">-149</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">spruce_wall_sign</td>
<td style="border-style:solid; border-width:4; padding:6px">-182</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">spyglass</td>
<td style="border-style:solid; border-width:4; padding:6px">627</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">squid_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">450</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">stained_glass</td>
<td style="border-style:solid; border-width:4; padding:6px">241</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">stained_glass_pane</td>
<td style="border-style:solid; border-width:4; padding:6px">160</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">stained_hardened_clay</td>
<td style="border-style:solid; border-width:4; padding:6px">159</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">standing_banner</td>
<td style="border-style:solid; border-width:4; padding:6px">176</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">standing_sign</td>
<td style="border-style:solid; border-width:4; padding:6px">63</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">stick</td>
<td style="border-style:solid; border-width:4; padding:6px">320</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">sticky_piston</td>
<td style="border-style:solid; border-width:4; padding:6px">29</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">sticky_piston_arm_collision</td>
<td style="border-style:solid; border-width:4; padding:6px">-217</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">stone</td>
<td style="border-style:solid; border-width:4; padding:6px">1</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">stone_axe</td>
<td style="border-style:solid; border-width:4; padding:6px">315</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">stone_block_slab</td>
<td style="border-style:solid; border-width:4; padding:6px">44</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">stone_block_slab2</td>
<td style="border-style:solid; border-width:4; padding:6px">182</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">stone_block_slab3</td>
<td style="border-style:solid; border-width:4; padding:6px">-162</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">stone_block_slab4</td>
<td style="border-style:solid; border-width:4; padding:6px">-166</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">stone_brick_stairs</td>
<td style="border-style:solid; border-width:4; padding:6px">109</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">stone_button</td>
<td style="border-style:solid; border-width:4; padding:6px">77</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">stone_hoe</td>
<td style="border-style:solid; border-width:4; padding:6px">330</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">stone_pickaxe</td>
<td style="border-style:solid; border-width:4; padding:6px">314</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">stone_pressure_plate</td>
<td style="border-style:solid; border-width:4; padding:6px">70</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">stone_shovel</td>
<td style="border-style:solid; border-width:4; padding:6px">313</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">stone_stairs</td>
<td style="border-style:solid; border-width:4; padding:6px">67</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">stone_sword</td>
<td style="border-style:solid; border-width:4; padding:6px">312</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">stonebrick</td>
<td style="border-style:solid; border-width:4; padding:6px">98</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">stonecutter</td>
<td style="border-style:solid; border-width:4; padding:6px">245</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">stonecutter_block</td>
<td style="border-style:solid; border-width:4; padding:6px">-197</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">stray_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">462</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">strider_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">496</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">string</td>
<td style="border-style:solid; border-width:4; padding:6px">326</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">stripped_acacia_log</td>
<td style="border-style:solid; border-width:4; padding:6px">-8</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">stripped_birch_log</td>
<td style="border-style:solid; border-width:4; padding:6px">-6</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">stripped_crimson_hyphae</td>
<td style="border-style:solid; border-width:4; padding:6px">-300</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">stripped_crimson_stem</td>
<td style="border-style:solid; border-width:4; padding:6px">-240</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">stripped_dark_oak_log</td>
<td style="border-style:solid; border-width:4; padding:6px">-9</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">stripped_jungle_log</td>
<td style="border-style:solid; border-width:4; padding:6px">-7</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">stripped_mangrove_log</td>
<td style="border-style:solid; border-width:4; padding:6px">-485</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">stripped_mangrove_wood</td>
<td style="border-style:solid; border-width:4; padding:6px">-498</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">stripped_oak_log</td>
<td style="border-style:solid; border-width:4; padding:6px">-10</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">stripped_spruce_log</td>
<td style="border-style:solid; border-width:4; padding:6px">-5</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">stripped_warped_hyphae</td>
<td style="border-style:solid; border-width:4; padding:6px">-301</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">stripped_warped_stem</td>
<td style="border-style:solid; border-width:4; padding:6px">-241</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">structure_block</td>
<td style="border-style:solid; border-width:4; padding:6px">252</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">structure_void</td>
<td style="border-style:solid; border-width:4; padding:6px">217</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">sugar</td>
<td style="border-style:solid; border-width:4; padding:6px">416</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">sugar_cane</td>
<td style="border-style:solid; border-width:4; padding:6px">385</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">suspicious_stew</td>
<td style="border-style:solid; border-width:4; padding:6px">591</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">sweet_berries</td>
<td style="border-style:solid; border-width:4; padding:6px">287</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">sweet_berry_bush</td>
<td style="border-style:solid; border-width:4; padding:6px">-207</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">tadpole_bucket</td>
<td style="border-style:solid; border-width:4; padding:6px">632</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">tadpole_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">631</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">tallgrass</td>
<td style="border-style:solid; border-width:4; padding:6px">31</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">target</td>
<td style="border-style:solid; border-width:4; padding:6px">-239</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">tinted_glass</td>
<td style="border-style:solid; border-width:4; padding:6px">-334</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">tnt</td>
<td style="border-style:solid; border-width:4; padding:6px">46</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">tnt_minecart</td>
<td style="border-style:solid; border-width:4; padding:6px">526</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">torch</td>
<td style="border-style:solid; border-width:4; padding:6px">50</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">totem_of_undying</td>
<td style="border-style:solid; border-width:4; padding:6px">569</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">trader_llama_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">474</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">trapdoor</td>
<td style="border-style:solid; border-width:4; padding:6px">96</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">trapped_chest</td>
<td style="border-style:solid; border-width:4; padding:6px">146</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">trident</td>
<td style="border-style:solid; border-width:4; padding:6px">547</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">trip_wire</td>
<td style="border-style:solid; border-width:4; padding:6px">132</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">tripwire_hook</td>
<td style="border-style:solid; border-width:4; padding:6px">131</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">tropical_fish</td>
<td style="border-style:solid; border-width:4; padding:6px">266</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">tropical_fish_bucket</td>
<td style="border-style:solid; border-width:4; padding:6px">366</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">tropical_fish_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">480</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">tuff</td>
<td style="border-style:solid; border-width:4; padding:6px">-333</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">turtle_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">-159</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">turtle_helmet</td>
<td style="border-style:solid; border-width:4; padding:6px">574</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">turtle_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">486</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">twisting_vines</td>
<td style="border-style:solid; border-width:4; padding:6px">-287</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">underwater_torch</td>
<td style="border-style:solid; border-width:4; padding:6px">239</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">undyed_shulker_box</td>
<td style="border-style:solid; border-width:4; padding:6px">205</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">unknown</td>
<td style="border-style:solid; border-width:4; padding:6px">-305</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">unlit_redstone_torch</td>
<td style="border-style:solid; border-width:4; padding:6px">75</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">unpowered_comparator</td>
<td style="border-style:solid; border-width:4; padding:6px">149</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">unpowered_repeater</td>
<td style="border-style:solid; border-width:4; padding:6px">93</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">verdant_froglight</td>
<td style="border-style:solid; border-width:4; padding:6px">-470</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">vex_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">477</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">villager_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">449</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">vindicator_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">475</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">vine</td>
<td style="border-style:solid; border-width:4; padding:6px">106</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">wall_banner</td>
<td style="border-style:solid; border-width:4; padding:6px">177</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">wall_sign</td>
<td style="border-style:solid; border-width:4; padding:6px">68</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">wandering_trader_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">493</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">warden_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">634</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">warped_button</td>
<td style="border-style:solid; border-width:4; padding:6px">-261</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">warped_door</td>
<td style="border-style:solid; border-width:4; padding:6px">619</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">warped_double_slab</td>
<td style="border-style:solid; border-width:4; padding:6px">-267</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">warped_fence</td>
<td style="border-style:solid; border-width:4; padding:6px">-257</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">warped_fence_gate</td>
<td style="border-style:solid; border-width:4; padding:6px">-259</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">warped_fungus</td>
<td style="border-style:solid; border-width:4; padding:6px">-229</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">warped_fungus_on_a_stick</td>
<td style="border-style:solid; border-width:4; padding:6px">620</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">warped_hyphae</td>
<td style="border-style:solid; border-width:4; padding:6px">-298</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">warped_nylium</td>
<td style="border-style:solid; border-width:4; padding:6px">-233</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">warped_planks</td>
<td style="border-style:solid; border-width:4; padding:6px">-243</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">warped_pressure_plate</td>
<td style="border-style:solid; border-width:4; padding:6px">-263</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">warped_roots</td>
<td style="border-style:solid; border-width:4; padding:6px">-224</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">warped_sign</td>
<td style="border-style:solid; border-width:4; padding:6px">617</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">warped_slab</td>
<td style="border-style:solid; border-width:4; padding:6px">-265</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">warped_stairs</td>
<td style="border-style:solid; border-width:4; padding:6px">-255</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">warped_standing_sign</td>
<td style="border-style:solid; border-width:4; padding:6px">-251</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">warped_stem</td>
<td style="border-style:solid; border-width:4; padding:6px">-226</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">warped_trapdoor</td>
<td style="border-style:solid; border-width:4; padding:6px">-247</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">warped_wall_sign</td>
<td style="border-style:solid; border-width:4; padding:6px">-253</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">warped_wart_block</td>
<td style="border-style:solid; border-width:4; padding:6px">-227</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">water</td>
<td style="border-style:solid; border-width:4; padding:6px">9</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">water_bucket</td>
<td style="border-style:solid; border-width:4; padding:6px">362</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">waterlily</td>
<td style="border-style:solid; border-width:4; padding:6px">111</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">waxed_copper</td>
<td style="border-style:solid; border-width:4; padding:6px">-344</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">waxed_cut_copper</td>
<td style="border-style:solid; border-width:4; padding:6px">-351</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">waxed_cut_copper_slab</td>
<td style="border-style:solid; border-width:4; padding:6px">-365</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">waxed_cut_copper_stairs</td>
<td style="border-style:solid; border-width:4; padding:6px">-358</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">waxed_double_cut_copper_slab</td>
<td style="border-style:solid; border-width:4; padding:6px">-372</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">waxed_exposed_copper</td>
<td style="border-style:solid; border-width:4; padding:6px">-345</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">waxed_exposed_cut_copper</td>
<td style="border-style:solid; border-width:4; padding:6px">-352</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">waxed_exposed_cut_copper_slab</td>
<td style="border-style:solid; border-width:4; padding:6px">-366</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">waxed_exposed_cut_copper_stairs</td>
<td style="border-style:solid; border-width:4; padding:6px">-359</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">waxed_exposed_double_cut_copper_slab</td>
<td style="border-style:solid; border-width:4; padding:6px">-373</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">waxed_oxidized_copper</td>
<td style="border-style:solid; border-width:4; padding:6px">-446</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">waxed_oxidized_cut_copper</td>
<td style="border-style:solid; border-width:4; padding:6px">-447</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">waxed_oxidized_cut_copper_slab</td>
<td style="border-style:solid; border-width:4; padding:6px">-449</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">waxed_oxidized_cut_copper_stairs</td>
<td style="border-style:solid; border-width:4; padding:6px">-448</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">waxed_oxidized_double_cut_copper_slab</td>
<td style="border-style:solid; border-width:4; padding:6px">-450</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">waxed_weathered_copper</td>
<td style="border-style:solid; border-width:4; padding:6px">-346</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">waxed_weathered_cut_copper</td>
<td style="border-style:solid; border-width:4; padding:6px">-353</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">waxed_weathered_cut_copper_slab</td>
<td style="border-style:solid; border-width:4; padding:6px">-367</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">waxed_weathered_cut_copper_stairs</td>
<td style="border-style:solid; border-width:4; padding:6px">-360</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">waxed_weathered_double_cut_copper_slab</td>
<td style="border-style:solid; border-width:4; padding:6px">-374</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">weathered_copper</td>
<td style="border-style:solid; border-width:4; padding:6px">-342</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">weathered_cut_copper</td>
<td style="border-style:solid; border-width:4; padding:6px">-349</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">weathered_cut_copper_slab</td>
<td style="border-style:solid; border-width:4; padding:6px">-363</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">weathered_cut_copper_stairs</td>
<td style="border-style:solid; border-width:4; padding:6px">-356</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">weathered_double_cut_copper_slab</td>
<td style="border-style:solid; border-width:4; padding:6px">-370</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">web</td>
<td style="border-style:solid; border-width:4; padding:6px">30</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">weeping_vines</td>
<td style="border-style:solid; border-width:4; padding:6px">-231</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">wheat</td>
<td style="border-style:solid; border-width:4; padding:6px">334</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">wheat_seeds</td>
<td style="border-style:solid; border-width:4; padding:6px">291</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">white_candle</td>
<td style="border-style:solid; border-width:4; padding:6px">-413</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">white_candle_cake</td>
<td style="border-style:solid; border-width:4; padding:6px">-430</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">white_dye</td>
<td style="border-style:solid; border-width:4; padding:6px">410</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">white_glazed_terracotta</td>
<td style="border-style:solid; border-width:4; padding:6px">220</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">witch_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">452</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">wither_rose</td>
<td style="border-style:solid; border-width:4; padding:6px">-216</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">wither_skeleton_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">464</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">wolf_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">439</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">wood</td>
<td style="border-style:solid; border-width:4; padding:6px">-212</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">wooden_axe</td>
<td style="border-style:solid; border-width:4; padding:6px">311</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">wooden_button</td>
<td style="border-style:solid; border-width:4; padding:6px">143</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">wooden_door</td>
<td style="border-style:solid; border-width:4; padding:6px">359</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">wooden_hoe</td>
<td style="border-style:solid; border-width:4; padding:6px">329</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">wooden_pickaxe</td>
<td style="border-style:solid; border-width:4; padding:6px">310</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">wooden_pressure_plate</td>
<td style="border-style:solid; border-width:4; padding:6px">72</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">wooden_shovel</td>
<td style="border-style:solid; border-width:4; padding:6px">309</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">wooden_slab</td>
<td style="border-style:solid; border-width:4; padding:6px">158</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">wooden_sword</td>
<td style="border-style:solid; border-width:4; padding:6px">308</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">wool</td>
<td style="border-style:solid; border-width:4; padding:6px">35</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">writable_book</td>
<td style="border-style:solid; border-width:4; padding:6px">511</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">written_book</td>
<td style="border-style:solid; border-width:4; padding:6px">512</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">yellow_candle</td>
<td style="border-style:solid; border-width:4; padding:6px">-417</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">yellow_candle_cake</td>
<td style="border-style:solid; border-width:4; padding:6px">-434</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">yellow_dye</td>
<td style="border-style:solid; border-width:4; padding:6px">406</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">yellow_flower</td>
<td style="border-style:solid; border-width:4; padding:6px">37</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">yellow_glazed_terracotta</td>
<td style="border-style:solid; border-width:4; padding:6px">224</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">zoglin_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">499</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">zombie_horse_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">468</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">zombie_pigman_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">448</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">zombie_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">447</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">zombie_villager_spawn_egg</td>
<td style="border-style:solid; border-width:4; padding:6px">478</td>
<td style="border-style:solid; border-width:4; padding:6px"></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h1><p id="manifest.json">manifest.json</p></h1>

The manifest file contains all the basic information about the pack that Minecraft needs to identify it. The tables below contain all the components of the manifest, their individual properties, and what they mean.</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:4;">
<tr> <th style="border-style:solid; border-width:4;">Name</th> <th style="border-style:solid; border-width:4;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">capabilities</td>
<td style="border-style:solid; border-width:4; padding:6px">These are the different features that the pack makes use of that aren't necessarily enabled by default.</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:3;">
<tr> <th style="border-style:solid; border-width:3;">Name</th> <th style="border-style:solid; border-width:3;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">chemistry</td>
<td style="border-style:solid; border-width:3; padding:7px">Allows the pack to add, change or replace Chemistry functionality</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">experimental_custom_ui</td>
<td style="border-style:solid; border-width:3; padding:7px">Allows HTML files in the pack to be used for custom UI, and scripts in the pack to call and manipulate custom UI</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">raytraced</td>
<td style="border-style:solid; border-width:3; padding:7px">Indicates that this pack contains Raytracing Enhanced or Physical Based Materials for rendering</br></td>
</tr>
</table>
</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">dependencies</td>
<td style="border-style:solid; border-width:4; padding:6px">This section describes the packs that this pack depends on in order to work. Any packs defined here will be automatically added to the world when this one is added if they are present, or an error will be shown if they aren't. Each entry has the following parameters:</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:3;">
<tr> <th style="border-style:solid; border-width:3;">Name</th> <th style="border-style:solid; border-width:3;">Type</th> <th style="border-style:solid; border-width:3;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">uuid</td>
<td style="border-style:solid; border-width:3; padding:7px">String</td>
<td style="border-style:solid; border-width:3; padding:7px">This is the unique identifier of the pack that this pack depends on. It needs to be the exact same UUID that the pack has defined in the header section of it's manifest file</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">version</td>
<td style="border-style:solid; border-width:3; padding:7px">Vector [a, b, c]</td>
<td style="border-style:solid; border-width:3; padding:7px">This is the specific version of the pack that your pack depends on. Should match the version the other pack has in its manifest file</br></td>
</tr>
</table>
</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">format_version</td>
<td style="border-style:solid; border-width:4; padding:6px">This defines the current version of the manifest. Don't change this unless you have a good reason to</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">header</td>
<td style="border-style:solid; border-width:4; padding:6px">This is the heading of the manifest and is required for the manifest to be valid.</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:3;">
<tr> <th style="border-style:solid; border-width:3;">Name</th> <th style="border-style:solid; border-width:3;">Type</th> <th style="border-style:solid; border-width:3;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">base_game_version</td>
<td style="border-style:solid; border-width:3; padding:7px">Vector [a, b, c]</td>
<td style="border-style:solid; border-width:3; padding:7px">This is the version of the base game your world template requires, specified as [majorVersion, minorVersion, revision].</br>We use this to determine what version of the base game resource and behavior packs to apply when your content is used.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">description</td>
<td style="border-style:solid; border-width:3; padding:7px">String</td>
<td style="border-style:solid; border-width:3; padding:7px">This is a short description of the pack. It will appear in the game below the name of the pack. We recommend keeping it to 1-2 lines.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">lock_template_options</td>
<td style="border-style:solid; border-width:3; padding:7px">Boolean</td>
<td style="border-style:solid; border-width:3; padding:7px">This option is required for any world templates. This will lock the player from modifying the options of the world.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">min_engine_version</td>
<td style="border-style:solid; border-width:3; padding:7px">String</td>
<td style="border-style:solid; border-width:3; padding:7px">This is the minimum version of the game that this pack was written for.  This is a required field for resource and behavior packs. This helps the game identify whether any backwards compatibility is needed for your pack. You should always use the highest version currently available when creating packs</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">name</td>
<td style="border-style:solid; border-width:3; padding:7px">String</td>
<td style="border-style:solid; border-width:3; padding:7px">This is the name of the pack as it appears within Minecraft. This is a required field.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">uuid</td>
<td style="border-style:solid; border-width:3; padding:7px">String</td>
<td style="border-style:solid; border-width:3; padding:7px">This is a special type of identifier that uniquely identifies this pack from any other pack. UUIDs are written in the format xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx where each x is a hexadecimal value (0-9 or a-f). We recommend using an online service to generate this and guarantee their uniqueness (just bing UUID Generator to find some)</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">version</td>
<td style="border-style:solid; border-width:3; padding:7px">Vector [a, b, c]</td>
<td style="border-style:solid; border-width:3; padding:7px">This is the version of your pack in the format [majorVersion, minorVersion, revision].</br>The version number is used when importing a pack that has been imported before. The new pack will replace the old one if the version is higher, and ignored if it's the same or lower</br></td>
</tr>
</table>
</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">metadata</td>
<td style="border-style:solid; border-width:4; padding:6px">This section contains additional data about your pack and is otherwise optional.</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:3;">
<tr> <th style="border-style:solid; border-width:3;">Name</th> <th style="border-style:solid; border-width:3;">Type</th> <th style="border-style:solid; border-width:3;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">authors</td>
<td style="border-style:solid; border-width:3; padding:7px">Array</td>
<td style="border-style:solid; border-width:3; padding:7px">Name of the author(s) of the pack</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">license</td>
<td style="border-style:solid; border-width:3; padding:7px">String</td>
<td style="border-style:solid; border-width:3; padding:7px">The license of the pack</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">url</td>
<td style="border-style:solid; border-width:3; padding:7px">String</td>
<td style="border-style:solid; border-width:3; padding:7px">The home website of your pack</br></td>
</tr>
</table>
</td>
</tr>
<tr>
<td style="border-style:solid; border-width:4; padding:6px">modules</td>
<td style="border-style:solid; border-width:4; padding:6px">This section describes the modules that comprise the pack. Each entry here defines one of the kinds of contents of the pack.</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:3;">
<tr> <th style="border-style:solid; border-width:3;">Name</th> <th style="border-style:solid; border-width:3;">Type</th> <th style="border-style:solid; border-width:3;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">description</td>
<td style="border-style:solid; border-width:3; padding:7px">String</td>
<td style="border-style:solid; border-width:3; padding:7px">This is a short description of the module. This is not user-facing at the moment but is a good place to remind yourself why the module is defined</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">type</td>
<td style="border-style:solid; border-width:3; padding:7px">String</td>
<td style="border-style:solid; border-width:3; padding:7px">This is the type of the module. Can be any of the following: resources, data, client_data, interface, world_template</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">uuid</td>
<td style="border-style:solid; border-width:3; padding:7px">String</td>
<td style="border-style:solid; border-width:3; padding:7px">This is a unique identifier for the module in the same format as the pack's UUID in the header. This should be different from the pack's UUID, and different for every module</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">version</td>
<td style="border-style:solid; border-width:3; padding:7px">Vector [a, b, c]</td>
<td style="border-style:solid; border-width:3; padding:7px">This is the version of the module in the same format as the pack's version in the header. This can be used to further identify changes in your pack</br></td>
</tr>
</table>
</td>
</tr>
</table>
<h2>Examples</h2>
Behavior Pack<br / ><textarea readonly="true" cols="60" rows="32">

{
    "format_version": 1,
    "header": {
        "description": "Example vanilla behavior pack",
        "name": "Vanilla Behavior Pack",
        "uuid": "ee649bcf-256c-4013-9068-6a802b89d756",
        "version": [0, 0, 1]
    },
    "modules": [
        {
            "description": "Example behavior pack module",
            "type": "data",
            "uuid": "fa6e90c8-c925-460f-8155-c8a60b753caa",
            "version": [0, 0, 1]
        },
        {
            "description": "Example client scripts module",
            "type": "client_data",
            "uuid": "c05a992e-482a-455f-898c-58bbb4975e47",
            "version": [0, 0, 1]
        }
    ],
    "dependencies": [
        {
            "uuid": "66c6e9a8-3093-462a-9c36-dbb052165822",
            "version": [0, 0, 1]
        }
    ]
}

</textarea> </br>
Resource Pack<br / ><textarea readonly="true" cols="60" rows="22">

{
    "format_version": 1,
    "header": {
        "description": "Example vanilla resource pack",
        "name": "Vanilla Resource Pack",
        "uuid": "66c6e9a8-3093-462a-9c36-dbb052165822",
        "version": [0, 0, 1],
        "min_engine_version": [1, 2, 6]
        "vanilla": [1, 12, 0]
    },
    "modules": [
        {
            "description": "Example vanilla resource pack",
            "type": "resources",
            "uuid": "743f6949-53be-44b6-b326-398005028819",
            "version": [0, 0, 1]
        }
    ]
}

</textarea> </br>
<a href="#Index">Back to top</a><br><br>


</v-html>
</div>
</template>

<style scoped>
textarea{
    color: white;
}

::-webkit-scrollbar {
  width: 10px;
}

::-webkit-scrollbar-thumb:hover {
  background: white;
}

::-webkit-scrollbar-track {
  background: grey;
}
</style>