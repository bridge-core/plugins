<template>
<div style="overflow: scroll">
<v-html>
<h1>SCRIPTING DOCUMENTATION </br>Version: 1.17.10.4</h1>
<h2><p id="Index">Index</p></h2>
<table border="1">
<tr> <th><a href="#Script API Objects">Script API Objects</a></th> </tr>
<tr> <td> <a href="#Entity JS API Object"> Entity JS API Object</a> </tr> </td>
<tr> <td> <a href="#Level JS API Object"> Level JS API Object</a> </tr> </td>
<tr> <td> <a href="#Component JS API Object"> Component JS API Object</a> </tr> </td>
<tr> <td> <a href="#Query JS API Object"> Query JS API Object</a> </tr> </td>
<tr> <td> <a href="#ItemStack JS API Object"> ItemStack JS API Object</a> </tr> </td>
<tr> <td> <a href="#Block JS API Object"> Block JS API Object</a> </tr> </td>
<tr> <td> <a href="#Ticking Area JS API Object"> Ticking Area JS API Object</a> </tr> </td>
<tr> <td> <a href="#Entity Ticking Area JS API Object"> Entity Ticking Area JS API Object</a> </tr> </td>
<tr> <td> <a href="#Level Ticking Area JS API Object"> Level Ticking Area JS API Object</a> </tr> </td>
<tr> <th><a href="#Script Bindings">Script Bindings</a></th> </tr>
<tr> <td> <a href="#Logging Bindings"> Logging Bindings</a> </tr> </td>
<tr> <td> <a href="#Entity Bindings"> Entity Bindings</a> </tr> </td>
<tr> <td> <a href="#Component Bindings"> Component Bindings</a> </tr> </td>
<tr> <td> <a href="#Event Bindings"> Event Bindings</a> </tr> </td>
<tr> <td> <a href="#Entity Queries"> Entity Queries</a> </tr> </td>
<tr> <td> <a href="#Block Bindings"> Block Bindings</a> </tr> </td>
<tr> <td> <a href="#Slash Commands"> Slash Commands</a> </tr> </td>
<tr> <th><a href="#Script Components">Script Components</a></th> </tr>
<tr> <td> <a href="#Level Components"> Level Components</a> </tr> </td>
<tr> <td> <a href="#Server Components"> Server Components</a> </tr> </td>
<tr> <td> <a href="#Client Components"> Client Components</a> </tr> </td>
<tr> <td> <a href="#Block Components"> Block Components</a> </tr> </td>
<tr> <th><a href="#Script Events">Script Events</a></th> </tr>
<tr> <td> <a href="#Client Events"> Client Events</a> </tr> </td>
<tr> <td> <a href="#Server Events"> Server Events</a> </tr> </td>
<tr> <th><a href="#Scripting System">Scripting System</a></th> </tr>
<tr> <td> <a href="#Demos"> Demos</a> </tr> </td>
<tr> <td> <a href="#Known Issues"> Known Issues</a> </tr> </td>
<tr> <td> <a href="#Breaking Changes"> Breaking Changes</a> </tr> </td>
<tr> <td> <a href="#Pre-Requisites"> Pre-Requisites</a> </tr> </td>
<tr> <td> <a href="#Getting Started"> Getting Started</a> </tr> </td>
<tr> <td> <a href="#Structure of a Script"> Structure of a Script</a> </tr> </td>
<tr> <td> <a href="#Debugging"> Debugging</a> </tr> </td>
<tr> <th><a href="#User-Defined Components">User-Defined Components</a></th> </tr>
</table>
<a href="#Index">Back to top</a>
<h1><p id="Script API Objects">Script API Objects</p></h1>

Here you can find the definition of some objects returned by the script API.</br><h1><p id="Entity JS API Object">Entity JS API Object</p></h1>

<h2></h2>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:3;">
<tr> <th style="border-style:solid; border-width:3;">Name</th> <th style="border-style:solid; border-width:3;">Type</th> <th style="border-style:solid; border-width:3;">Entity JS API Object</th> <th style="border-style:solid; border-width:3;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">__identifier__</td>
<td style="border-style:solid; border-width:3; padding:7px">String</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">READ ONLY. This is the identifier for the object in the format namespace:name. For example, if the type is entity and the object is representing a vanilla cow, the identifier would be minecraft:cow</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">__type__</td>
<td style="border-style:solid; border-width:3; padding:7px">String</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">READ ONLY. This defines the type of object. Can be: "entity" or "item_entity".</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">id</td>
<td style="border-style:solid; border-width:3; padding:7px">Positive Integer</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">READ ONLY. This is the unique identifier of the entity.</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h1><p id="Level JS API Object">Level JS API Object</p></h1>

<h2></h2>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:3;">
<tr> <th style="border-style:solid; border-width:3;">Name</th> <th style="border-style:solid; border-width:3;">Type</th> <th style="border-style:solid; border-width:3;">Level JS API Object</th> <th style="border-style:solid; border-width:3;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">__type__</td>
<td style="border-style:solid; border-width:3; padding:7px">String</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">READ ONLY. This defines the type of object. Will be: "level".</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">level_id</td>
<td style="border-style:solid; border-width:3; padding:7px">Positive Integer</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">READ ONLY. This is the unique identifier of the level.</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h1><p id="Component JS API Object">Component JS API Object</p></h1>

<h2></h2>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:3;">
<tr> <th style="border-style:solid; border-width:3;">Name</th> <th style="border-style:solid; border-width:3;">Type</th> <th style="border-style:solid; border-width:3;">Component JS API Object</th> <th style="border-style:solid; border-width:3;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">__type__</td>
<td style="border-style:solid; border-width:3; padding:7px">String</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">READ ONLY. This defines the type of object. Will be: "component".</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">data</td>
<td style="border-style:solid; border-width:3; padding:7px">JavaScript Object</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">This is the content of the component.</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h1><p id="Query JS API Object">Query JS API Object</p></h1>

<h2></h2>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:3;">
<tr> <th style="border-style:solid; border-width:3;">Name</th> <th style="border-style:solid; border-width:3;">Type</th> <th style="border-style:solid; border-width:3;">Query JS API Object</th> <th style="border-style:solid; border-width:3;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">__type__</td>
<td style="border-style:solid; border-width:3; padding:7px">String</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">READ ONLY. This defines the type of object. Will be: "query".</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">query_id</td>
<td style="border-style:solid; border-width:3; padding:7px">Positive Integer</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">READ ONLY. This is the unique identifier of the query.</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h1><p id="ItemStack JS API Object">ItemStack JS API Object</p></h1>

<h2></h2>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:3;">
<tr> <th style="border-style:solid; border-width:3;">Name</th> <th style="border-style:solid; border-width:3;">Type</th> <th style="border-style:solid; border-width:3;">ItemStack JS API Object</th> <th style="border-style:solid; border-width:3;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">__identifier__</td>
<td style="border-style:solid; border-width:3; padding:7px">String</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">READ ONLY. This is the identifier for the object in the format namespace:name. For example, if the type is entity and the object is representing a vanilla cow, the identifier would be minecraft:cow</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">__type__</td>
<td style="border-style:solid; border-width:3; padding:7px">String</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">READ ONLY. This defines the type of object. Will be: "item_stack".</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">count</td>
<td style="border-style:solid; border-width:3; padding:7px">String</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">READ ONLY. This is the number of items in the stack.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">item</td>
<td style="border-style:solid; border-width:3; padding:7px">String</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">READ ONLY. This is the identifier of the item.</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h1><p id="Block JS API Object">Block JS API Object</p></h1>

<h2></h2>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:3;">
<tr> <th style="border-style:solid; border-width:3;">Name</th> <th style="border-style:solid; border-width:3;">Type</th> <th style="border-style:solid; border-width:3;">Block JS API Object</th> <th style="border-style:solid; border-width:3;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">__identifier__</td>
<td style="border-style:solid; border-width:3; padding:7px">String</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">READ ONLY. This is the identifier for the object in the format namespace:name. For example, if the type is block and the object is representing a block of bedrock, the identifier would be minecraft:bedrock</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">__type__</td>
<td style="border-style:solid; border-width:3; padding:7px">String</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">READ ONLY. This defines the type of object. Will be: "block".</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">block_position</td>
<td style="border-style:solid; border-width:3; padding:7px">JavaScript Object</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">READ ONLY. This is the position of the block and it functions as part of its unique identifier.</br><h3><p id="Parameters">Parameters</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">x</td>
<td style="border-style:solid; border-width:1; padding:9px">Integer</td>
<td style="border-style:solid; border-width:1; padding:9px">The x position</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">y</td>
<td style="border-style:solid; border-width:1; padding:9px">Integer</td>
<td style="border-style:solid; border-width:1; padding:9px">The y position</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">z</td>
<td style="border-style:solid; border-width:1; padding:9px">Integer</td>
<td style="border-style:solid; border-width:1; padding:9px">The z position</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

</td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">ticking_area</td>
<td style="border-style:solid; border-width:3; padding:7px">JavaScript Object</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">READ ONLY. This is the ticking area object that was used to get this block.</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h1><p id="Ticking Area JS API Object">Ticking Area JS API Object</p></h1>

<a href="#Index">Back to top</a><br><br>

<h1><p id="Entity Ticking Area JS API Object">Entity Ticking Area JS API Object</p></h1>

<h2></h2>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:3;">
<tr> <th style="border-style:solid; border-width:3;">Name</th> <th style="border-style:solid; border-width:3;">Type</th> <th style="border-style:solid; border-width:3;">Entity Ticking Area JS API Object</th> <th style="border-style:solid; border-width:3;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">__type__</td>
<td style="border-style:solid; border-width:3; padding:7px">String</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">READ ONLY. This defines the type of object. Will be: "entity_ticking_area".</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">entity_ticking_area_id</td>
<td style="border-style:solid; border-width:3; padding:7px">Positive Integer</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">READ ONLY. This is the unique identifier of the ticking area.</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h1><p id="Level Ticking Area JS API Object">Level Ticking Area JS API Object</p></h1>

<h2></h2>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:3;">
<tr> <th style="border-style:solid; border-width:3;">Name</th> <th style="border-style:solid; border-width:3;">Type</th> <th style="border-style:solid; border-width:3;">Level Ticking Area JS API Object</th> <th style="border-style:solid; border-width:3;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">__type__</td>
<td style="border-style:solid; border-width:3; padding:7px">String</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">READ ONLY. This defines the type of object. Will be: "level_ticking_area".</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">level_ticking_area_id</td>
<td style="border-style:solid; border-width:3; padding:7px">String</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">READ ONLY. This is the unique identifier of the ticking area.</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<br><br>

<h1><p id="Script Bindings">Script Bindings</p></h1>

Bindings are the capabilities of the Minecraft Script Engine to change or modify things in the game.</br><h1><p id="Logging Bindings">Logging Bindings</p></h1>

<h2></h2>

<h2><p id="log(Message)">log(Message)</p></h2>

The log function is accessed through the server or client objects and allows for logging a message to the ContentLog file. On Windows 10 devices it is located at ' %APPDATA%\..\Local\Packages\Microsoft.MinecraftUWP_8wekyb3d8bbwe\LocalState\logs '</br><h3></h3>

<h3><p id="Parameters">Parameters</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">Message</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px">The message that you want to send to the log file</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3>Code Example:</h3>
Log<br / ><textarea readonly="true" cols="38" rows="4">
system.exampleFunction = function() {
  client.log("example log message") 
}; 
</textarea> </br>
<br><br>

<br><br>

<h1><p id="Entity Bindings">Entity Bindings</p></h1>

<h2></h2>

<h2><p id="createEntity()">createEntity()</p></h2>

NOTE: Entities are created first on the server, with the client notified of new entities afterwards. Be aware that if you send the result object to the client right away, the created entity might not exist on the client yet.</br><h3></h3>

<h3><p id="Return Value">Return Value</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Value</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">Entity JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px">An object representing the newly created entity</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<br><br>

<h2><p id="createEntity(Type, TemplateIdentifier)">createEntity(Type, TemplateIdentifier)</p></h2>

NOTE: Entities are created first on the server, with the client notified of new entities afterwards. Be aware that if you send the result object to the client right away, the created entity might not exist on the client yet.</br><h3></h3>

<h3><p id="Parameters">Parameters</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">TemplateIdentifier</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px">This can be any of the entity identifiers from the applied Behavior Packs. For example specifying minecraft:cow here will make the provided entity a cow as defined in JSON</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">Type</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px">Specifies the type of the entity that is being created by the template. Valid inputs are `entity` and `item_entity`</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3><p id="Return Value">Return Value</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Value</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">Entity JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px">An object representing the newly created entity</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<br><br>

<h2><p id="destroyEntity(EntityObject)">destroyEntity(EntityObject)</p></h2>

<h3></h3>

<h3><p id="Parameters">Parameters</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">EntityObject</td>
<td style="border-style:solid; border-width:1; padding:9px">Entity JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The object that was retrieved from a call to createEntity() or retrieved from an entity event</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3><p id="Return Value">Return Value</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Value</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">Boolean</td>
<td style="border-style:solid; border-width:1; padding:9px">The entity was successfully destroyed</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<br><br>

<h2><p id="isValidEntity(EntityObject)">isValidEntity(EntityObject)</p></h2>

<h3></h3>

<h3><p id="Parameters">Parameters</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">EntityObject</td>
<td style="border-style:solid; border-width:1; padding:9px">Entity JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The object that was retrieved from a call to createEntity() or retrieved from an entity event</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3><p id="Return Value">Return Value</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Value</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">Boolean</td>
<td style="border-style:solid; border-width:1; padding:9px">The entity is in the Script Engine's database of entities</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<br><br>

<br><br>

<h1><p id="Component Bindings">Component Bindings</p></h1>

<h2></h2>

<h2><p id="registerComponent(ComponentIdentifier, ComponentData)">registerComponent(ComponentIdentifier, ComponentData)</p></h2>

<h3></h3>

<h3><p id="Parameters">Parameters</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">ComponentData</td>
<td style="border-style:solid; border-width:1; padding:9px">JavaScript Object</td>
<td style="border-style:solid; border-width:1; padding:9px">A JavaScript Object that defines the name of the fields and the data each field holds inside the component.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">ComponentIdentifier</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px">The identifier of the custom component. It is required to use a namespace so you can uniquely refer to it later without overlapping a name with a built-in component: for example 'myPack:myCustomComponent'</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3><p id="Return Value">Return Value</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Value</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">Boolean</td>
<td style="border-style:solid; border-width:1; padding:9px">The component was successfully registered</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3>Code Example:</h3>
Registering a custom component<br / ><textarea readonly="true" cols="125" rows="6">
const mySystem = server.registerSystem(0, 0);

mySystem.initialize = function() {
  this.registerComponent("myPack:myCustomComponent", { myString: "string", myNumber: 0, myBool: true, myArray: [1, 2, 3] });
};
</textarea> </br>
<br><br>

<h2><p id="createComponent(EntityObject, ComponentIdentifier)">createComponent(EntityObject, ComponentIdentifier)</p></h2>

<h3></h3>

<h3><p id="Parameters">Parameters</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">ComponentIdentifier</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px">The identifier of the component to add to the entity. This is either the identifier of a built-in component (check the Script Components section) or a custom component created with a call to registerComponent()</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">EntityObject</td>
<td style="border-style:solid; border-width:1; padding:9px">Entity JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The EntityObject that was retrieved from a call to createEntity() or retrieved from an event</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3><p id="Return Value">Return Value</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Value</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">Component JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px">An object with the following fields, and additionally, all the fields as defined in the component</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3>Code Example:</h3>
Creating a custom component<br / ><textarea readonly="true" cols="125" rows="20">
let globals = {
  ready: false
};

const mySystem = server.registerSystem(0, 0);

mySystem.initialize = function() {
  this.registerComponent("myPack:myCustomComponent", { myString: "string", myNumber: 0, myBool: true, myArray: [1, 2, 3] });
}

mySystem.update = function() {
  if(globals.ready == false) {
    globals.ready = true;
    let myEntity = this.createEntity();
    if(myEntity != null) {
      let myComponent = this.createComponent(myEntity, "myPack:myCustomComponent");
    }
  }
};
</textarea> </br>
<br><br>

<h2><p id="hasComponent(EntityObject, ComponentIdentifier)">hasComponent(EntityObject, ComponentIdentifier)</p></h2>

<h3></h3>

<h3><p id="Parameters">Parameters</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">ComponentIdentifier</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px">The identifier of the component to check on the entity. This is either the identifier of a built-in component (check the Script Components section) or a custom component created with a call to registerComponent()</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">EntityObject</td>
<td style="border-style:solid; border-width:1; padding:9px">Entity JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The EntityObject that was retrieved from a call to createEntity() or retrieved from an event</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3><p id="Return Value">Return Value</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Value</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">Boolean</td>
<td style="border-style:solid; border-width:1; padding:9px">The EntityObject has the component</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3>Code Example:</h3>
Check whether an entity has specified component<br / ><textarea readonly="true" cols="63" rows="16">
let globals = {
  ready: false
};

const mySystem = server.registerSystem(0, 0);

mySystem.update = function() {
  if(globals.ready == false) {
    globals.ready = true;
    let entity = this.createEntity("entity", "minecraft:pig");
    if(this.hasComponent(entity, "minecraft:nameable")) {
      // Do some work
    }
  }
};
</textarea> </br>
<br><br>

<h2><p id="getComponent(EntityObject, ComponentIdentifier)">getComponent(EntityObject, ComponentIdentifier)</p></h2>

<h3></h3>

<h3><p id="Parameters">Parameters</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">ComponentIdentifier</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px">The identifier of the component to retrieve from the entity. This is either the identifier of a built-in component (check the Script Components section) or a custom component created with a call to registerComponent()</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">EntityObject</td>
<td style="border-style:solid; border-width:1; padding:9px">Entity JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The EntityObject that was retrieved from a call to createEntity() or retrieved from an event</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3><p id="Return Value">Return Value</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Value</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">Component JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px">An object with the following fields, and additionally, all the fields as defined in the component</br><h5><p id="Component JS API Object">Component JS API Object</p></h5>

<h6></h6>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Component JS API Object</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:10px">__type__</td>
<td style="border-style:solid; border-width:1; padding:10px">String</td>
<td style="border-style:solid; border-width:1; padding:10px"></td>
<td style="border-style:solid; border-width:1; padding:10px">READ ONLY. This defines the type of object. Will be: "component".</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:10px">data</td>
<td style="border-style:solid; border-width:1; padding:10px">JavaScript Object</td>
<td style="border-style:solid; border-width:1; padding:10px"></td>
<td style="border-style:solid; border-width:1; padding:10px">This is the content of the component.</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

</td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3>Code Example:</h3>
Get a specified component from an entity<br / ><textarea readonly="true" cols="77" rows="19">
let globals = {
  ready: false
};

const mySystem = server.registerSystem(0, 0);

mySystem.update = function() {
  if(globals.ready == false) {
    globals.ready = true;
    let entity = this.createEntity("entity", "minecraft:pig");
    let positionComponent = this.getComponent(entity, "minecraft:position");
    if (positionComponent != null) {
      positionComponent.data.x = 0;
      positionComponent.data.y = 0;
      positionComponent.data.z = 0;
    }
  }
};
</textarea> </br>
<br><br>

<h2><p id="applyComponentChanges(EntityObject, ComponentObject)">applyComponentChanges(EntityObject, ComponentObject)</p></h2>

<h3></h3>

<h3><p id="Parameters">Parameters</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">ComponentObject</td>
<td style="border-style:solid; border-width:1; padding:9px">Component JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The component object retrieved from the entity that was returned by either createComponent() or getComponent()</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">EntityObject</td>
<td style="border-style:solid; border-width:1; padding:9px">Entity JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The entity object that we are applying the component changes to</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3><p id="Return Value">Return Value</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Value</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">Boolean</td>
<td style="border-style:solid; border-width:1; padding:9px">The component was successfully updated</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3>Code Example:</h3>
Apply updates to an entity's component<br / ><textarea readonly="true" cols="82" rows="17">
let globals = {
  pig: null
};

const mySystem = server.registerSystem(0, 0);

mySystem.update = function() {
  if(globals.pig == null) {
    globals.pig = this.createEntity("entity", "minecraft:pig");
  }
  else {
    let positionComponent = this.getComponent(globals.pig, "minecraft:position");
    positionComponent.data.y += 0.1;
    this.applyComponentChanges(globals.pig, positionComponent);
  }
};
</textarea> </br>
<br><br>

<h2><p id="destroyComponent(EntityObject, ComponentIdentifier)">destroyComponent(EntityObject, ComponentIdentifier)</p></h2>

<h3></h3>

<h3><p id="Parameters">Parameters</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">ComponentIdentifier</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px">The identifier of the component to remove from the entity. This is either the identifier of a built-in component (check the Script Components section) or a custom component created with a call to registerComponent()</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">EntityObject</td>
<td style="border-style:solid; border-width:1; padding:9px">Entity JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The EntityObject that was retrieved from a call to createEntity() or retrieved from an event</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3><p id="Return Value">Return Value</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Value</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">Boolean</td>
<td style="border-style:solid; border-width:1; padding:9px">The component was successfully removed from the entity</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3>Code Example:</h3>
Destroy an entity's component<br / ><textarea readonly="true" cols="125" rows="24">
let globals = {
  myEntity: null
};

const mySystem = server.registerSystem(0, 0);

mySystem.initialize = function() {
  this.registerComponent("myPack:myCustomComponent", { myString: "string", myNumber: 0, myBool: true, myArray: [1, 2, 3] });
};

mySystem.update = function() {
  if(globals.myEntity == null) {
    globals.myEntity = this.createEntity();
  }
  else {
    if(this.hasComponent(globals.myEntity, "myPack:myCustomComponent")) {
      this.destroyComponent(globals.myEntity, "myPack:myCustomComponent");
    }
    else {
      this.createComponent(globals.myEntity, "myPack:myCustomComponent");
    }
  }
};
</textarea> </br>
<br><br>

<br><br>

<h1><p id="Event Bindings">Event Bindings</p></h1>

These are the bindings used to handle events. For a list of events you can react to or trigger, check the Events section of this document.</br><h2></h2>

<h2><p id="registerEventData(EventIdentifier, EventData)">registerEventData(EventIdentifier, EventData)</p></h2>

<h3></h3>

<h3><p id="Parameters">Parameters</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">EventData</td>
<td style="border-style:solid; border-width:1; padding:9px">JavaScript Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The JavaScript object with the correct fields and default values for the event</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">EventIdentifier</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px">This is the identifier of the custom event we are registering. The namespace is required and can't be set to minecraft.</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3><p id="Return Value">Return Value</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Value</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">Boolean</td>
<td style="border-style:solid; border-width:1; padding:9px">Successfully registered the event data</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<br><br>

<h2><p id="createEventData(EventIdentifier)">createEventData(EventIdentifier)</p></h2>

<h3></h3>

<h3><p id="Parameters">Parameters</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">EventIdentifier</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px">This is the identifier of the custom event we are registering. The namespace is required and can't be set to minecraft.</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3><p id="Return Value">Return Value</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Value</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">JavaScript Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The object containing the event data</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<br><br>

<h2><p id="listenForEvent(EventIdentifier, CallbackObject)">listenForEvent(EventIdentifier, CallbackObject)</p></h2>

<h3></h3>

<h3><p id="Parameters">Parameters</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">CallbackObject</td>
<td style="border-style:solid; border-width:1; padding:9px">JavaScript Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The JavaScript object that will get called whenever the event is broadcast</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">EventIdentifier</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px">This is the identifier of the event to which we want to react. Can be the identifier of a built-in event or a custom one from script</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3><p id="Return Value">Return Value</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Value</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">Boolean</td>
<td style="border-style:solid; border-width:1; padding:9px">Successfully registered to listen for the event</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3>Code Example:</h3>
Register a callback for a specified event<br / ><textarea readonly="true" cols="110" rows="12">
const mySystem = client.registerSystem(0, 0);

mySystem.initialize = function() {
  this.listenForEvent("minecraft:client_entered_world", (eventData) => this.onClientEnteredWorld(eventData));
};

mySystem.onClientEnteredWorld = function(eventData) {
  let messageData = this.createEventData("minecraft:display_chat_event");
  messageData.data.message = "Player has entered the world";
  this.broadcastEvent("minecraft:display_chat_event", messageData);
};
</textarea> </br>
<br><br>

<h2><p id="broadcastEvent(EventIdentifier, EventData)">broadcastEvent(EventIdentifier, EventData)</p></h2>

<h3></h3>

<h3><p id="Parameters">Parameters</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">EventData</td>
<td style="border-style:solid; border-width:1; padding:9px">JavaScript Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The data for the event. You can create a new JavaScript Object with the parameters you want to pass in to the listener and the engine will take care of delivering the data to them</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">EventIdentifier</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px">This is the identifier of the event we want to react to. Can be the identifier of a built-in event or a custom one from script</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3><p id="Return Value">Return Value</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Value</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">Boolean</td>
<td style="border-style:solid; border-width:1; padding:9px">Successfully broadcasted the event</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3>Code Example:</h3>
Broadcasting an event<br / ><textarea readonly="true" cols="72" rows="9">
const mySystem = client.registerSystem(0, 0);

mySystem.initialize = function() {
  let eventData = this.createEventData("minecraft:display_chat_event");
  eventData.data.message = "Hello, World!";
  this.broadcastEvent("minecraft:display_chat_event", eventData);
};

</textarea> </br>
<br><br>

<br><br>

<h1><p id="Entity Queries">Entity Queries</p></h1>

Entity Queries are a way for you to filter for entities based on their components. Once you have registered a query, you can request all the entities that are captured by it. Entity Queries will only ever return entities that are currently active in the level. If your query extends into chunks that are not currently loaded, entities there will not be included in the query.</br><h2></h2>

<h2><p id="registerQuery()">registerQuery()</p></h2>

Allows you to register a query. A query will contain all entities that meet the filter requirement.</br>No filters are added by default when you register a query so it will capture all entities.</br><h3></h3>

<h3><p id="Return Value">Return Value</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Value</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">Query JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px">An object containing the ID of the query</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3>Code Example:</h3>
Query Registration<br / ><textarea readonly="true" cols="46" rows="6">
const mySystem = server.registerSystem(0, 0);

mySystem.initialize = function() {
  let myQuery = this.registerQuery();
};
</textarea> </br>
<br><br>

<h2><p id="registerQuery(Component, ComponentField1, ComponentField2, ComponentField3)">registerQuery(Component, ComponentField1, ComponentField2, ComponentField3)</p></h2>

Allows you to register a query that will only show entities that have the given component and define which fields of that component will be used as a filter when getting the entities from the query. You can either provide just the component identifier, or the component identifier and the name of 3 properties on that component to be tested (If you do specify property names, you must specify 3).</br><h3></h3>

<h3><p id="Parameters">Parameters</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Default Value</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">Component</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px"></td>
<td style="border-style:solid; border-width:1; padding:9px">This is the identifier of the component that will be used to filter entities when</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">ComponentField1</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px">"x"</td>
<td style="border-style:solid; border-width:1; padding:9px">This is the name of the first field of the component that we want to filter entities by. By default this is set to x.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">ComponentField2</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px">"y"</td>
<td style="border-style:solid; border-width:1; padding:9px">This is the name of the second field of the component that we want to filter entities by. By default this is set to y.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">ComponentField3</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px">"z"</td>
<td style="border-style:solid; border-width:1; padding:9px">This is the name of the third field of the component that we want to filter entities by. By default this is set to z.</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3><p id="Return Value">Return Value</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Value</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">Query JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px">An object containing the ID of the query</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3>Code Example:</h3>
Query Registration<br / ><textarea readonly="true" cols="78" rows="6">
const mySystem = server.registerSystem(0, 0);

mySystem.initialize = function() {
  let spatialQuery = this.registerQuery("minecraft:position", "x", "y", "z");
};
</textarea> </br>
<br><br>

<h2><p id="addFilterToQuery(Query, ComponentIdentifier)">addFilterToQuery(Query, ComponentIdentifier)</p></h2>

Allows you to add filters to your query. The query will only contain entities that have all the components specified.</br>By default no filters are added. This will allow queries to capture all entities.</br><h3>Parameters</h3>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">ComponentIdentifier</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px">This is the identifier of the component that will be added to the filter list. Only entities that have that component will be listed in the query</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">Query</td>
<td style="border-style:solid; border-width:2; padding:8px">Query JS API Object</td>
<td style="border-style:solid; border-width:2; padding:8px">The object containing the ID of the query that you want to apply the filter to</br></td>
</tr>
</table>
<h3>Code Example:</h3>
Adding a filter to a query<br / ><textarea readonly="true" cols="140" rows="17">
let globals = {
  simpleQuery: null
};
const mySystem = server.registerSystem(0, 0);

mySystem.initialize = function() {
  globals.simpleQuery = this.registerQuery();
};

mySystem.update = function() {
  globals.simpleQuery = this.registerQuery();
  this.addFilterToQuery(globals.simpleQuery, "minecraft:explode");  let explodingEntities = this.getEntitiesFromQuery(globals.simpleQuery);
  for(var entity in explodingEntities) {
    server.log(JSON.stringify(entity));
  }
};
</textarea> </br>
<a href="#Index">Back to top</a><br><br>

<h2><p id="getEntitiesFromQuery(Query)">getEntitiesFromQuery(Query)</p></h2>

Allows you to fetch the entities captured by a query.</br><h3></h3>

<h3><p id="Parameters">Parameters</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">Query</td>
<td style="border-style:solid; border-width:1; padding:9px">Query JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px">This is the query you registered earlier using registerQuery()</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3><p id="Return Value">Return Value</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Value</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">Array</td>
<td style="border-style:solid; border-width:1; padding:9px">An array of EntityObjects representing the entities found within the query</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3>Code Example:</h3>
Get a list of entities from a query<br / ><textarea readonly="true" cols="60" rows="10">
const mySystem = server.registerSystem(0, 0);

mySystem.update = function() {
  let simpleQuery = this.registerQuery();
  let allEntities = this.getEntitiesFromQuery(simpleQuery);
  for(var entity in allEntities) {
    server.log(JSON.stringify(entity));
  }
};
</textarea> </br>
<br><br>

<h2><p id="getEntitiesFromQuery(Query, ComponentField1_Min, ComponentField2_Min, ComponentField3_Min, ComponentField1_Max, ComponentField2_Max, ComponentField3_Max)">getEntitiesFromQuery(Query, ComponentField1_Min, ComponentField2_Min, ComponentField3_Min, ComponentField1_Max, ComponentField2_Max, ComponentField3_Max)</p></h2>

Allows you to fetch the entities captured by a query that was created with a component filter built-in. The only entities that will be returned are those entities that have the component that was defined when the query was registered and that have a value in the three fields on that component that were defined in the query within the values specified in the call to getEntitiesFromQuery.</br><h3></h3>

<h3><p id="Parameters">Parameters</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">ComponentField1_Max</td>
<td style="border-style:solid; border-width:1; padding:9px">Decimal</td>
<td style="border-style:solid; border-width:1; padding:9px">The maximum value that the first component field needs to be on an entity for that entity to be included in the query</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">ComponentField1_Min</td>
<td style="border-style:solid; border-width:1; padding:9px">Decimal</td>
<td style="border-style:solid; border-width:1; padding:9px">The minimum value that the first component field needs to be on an entity for that entity to be included in the query</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">ComponentField2_Max</td>
<td style="border-style:solid; border-width:1; padding:9px">Decimal</td>
<td style="border-style:solid; border-width:1; padding:9px">The maximum value that the second component field needs to be on an entity for that entity to be included in the query</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">ComponentField2_Min</td>
<td style="border-style:solid; border-width:1; padding:9px">Decimal</td>
<td style="border-style:solid; border-width:1; padding:9px">The minimum value that the second component field needs to be on an entity for that entity to be included in the query</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">ComponentField3_Max</td>
<td style="border-style:solid; border-width:1; padding:9px">Decimal</td>
<td style="border-style:solid; border-width:1; padding:9px">The maximum value that the third component field needs to be on an entity for that entity to be included in the query</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">ComponentField3_Min</td>
<td style="border-style:solid; border-width:1; padding:9px">Decimal</td>
<td style="border-style:solid; border-width:1; padding:9px">The minimum value that the third component field needs to be on an entity for that entity to be included in the query</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">Query</td>
<td style="border-style:solid; border-width:1; padding:9px">Query JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px">This is the query you created earlier using registerQuery(...)</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3><p id="Return Value">Return Value</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Value</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">Array</td>
<td style="border-style:solid; border-width:1; padding:9px">An array of EntityObjects representing the entities found within the query</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3>Code Example:</h3>
Get a list of entities from a query<br / ><textarea readonly="true" cols="91" rows="17">
let globals = {
  spatialQuery: null
};

const mySystem = server.registerSystem(0, 0);

mySystem.initialize = function() {
  globals.spatialQuery = this.registerQuery("minecraft:position", "x", "y", "z");
};

mySystem.update = function() {
  let closeEntities = this.getEntitiesFromQuery(globals.spatialQuery, 0, 10, 0, 5, 0, 10);
  for(var entity in closeEntities) {
    server.log(JSON.stringify(entity));
  }
};
</textarea> </br>
<br><br>

<br><br>

<h1><p id="Block Bindings">Block Bindings</p></h1>

These functions define how you interact with blocks.</br><h2></h2>

<h2><p id="getBlock(Ticking Area, x, y, z)">getBlock(Ticking Area, x, y, z)</p></h2>

Allows you to get a block from the world when provided an x, y, and z position. The block must be within a ticking area.</br><h3></h3>

<h3><p id="Parameters">Parameters</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">Ticking Area</td>
<td style="border-style:solid; border-width:1; padding:9px">Ticking Area JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The ticking area the block is in</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">x</td>
<td style="border-style:solid; border-width:1; padding:9px">Integer</td>
<td style="border-style:solid; border-width:1; padding:9px">The x position of the block you want</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">y</td>
<td style="border-style:solid; border-width:1; padding:9px">Integer</td>
<td style="border-style:solid; border-width:1; padding:9px">The y position of the block you want</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">z</td>
<td style="border-style:solid; border-width:1; padding:9px">Integer</td>
<td style="border-style:solid; border-width:1; padding:9px">The z position of the block you want</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3><p id="Return Value">Return Value</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Value</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px"></td>
<td style="border-style:solid; border-width:1; padding:9px">object</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px"></td>
<td style="border-style:solid; border-width:1; padding:9px">null</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<br><br>

<h2><p id="getBlock(Ticking Area, PositionObject)">getBlock(Ticking Area, PositionObject)</p></h2>

Allows you to get a block from the world when provided a JavaScript object containing a position. The block must be within a ticking area.</br><h3></h3>

<h3><p id="Parameters">Parameters</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">PositionObject</td>
<td style="border-style:solid; border-width:1; padding:9px">JavaScript Object</td>
<td style="border-style:solid; border-width:1; padding:9px">A JavaScript object with the x, y, and z position of the block you want</br><h5><p id="Parameters">Parameters</p></h5>

<h6></h6>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:10px">x</td>
<td style="border-style:solid; border-width:1; padding:10px">Integer</td>
<td style="border-style:solid; border-width:1; padding:10px">The x position</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:10px">y</td>
<td style="border-style:solid; border-width:1; padding:10px">Integer</td>
<td style="border-style:solid; border-width:1; padding:10px">The y position</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:10px">z</td>
<td style="border-style:solid; border-width:1; padding:10px">Integer</td>
<td style="border-style:solid; border-width:1; padding:10px">The z position</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

</td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">Ticking Area</td>
<td style="border-style:solid; border-width:1; padding:9px">Ticking Area JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The ticking area the block is in</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3><p id="Return Value">Return Value</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Value</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">Block JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px">An object containing the block</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<br><br>

<h2><p id="getBlocks(Ticking Area, x min, y min, z min, x max, y max, z max)">getBlocks(Ticking Area, x min, y min, z min, x max, y max, z max)</p></h2>

Allows you to get an array of blocks from the world when provided a minimum and maximum x, y, and z position. The blocks must be within a ticking area. This call can be slow if given a lot of blocks, and should be used infrequently.</br><h3></h3>

<h3><p id="Parameters">Parameters</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">Ticking Area</td>
<td style="border-style:solid; border-width:1; padding:9px">Ticking Area JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The ticking area the blocks are in</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">x max</td>
<td style="border-style:solid; border-width:1; padding:9px">Integer</td>
<td style="border-style:solid; border-width:1; padding:9px">The maximum x position of the blocks you want</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">x min</td>
<td style="border-style:solid; border-width:1; padding:9px">Integer</td>
<td style="border-style:solid; border-width:1; padding:9px">The minimum x position of the blocks you want</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">y max</td>
<td style="border-style:solid; border-width:1; padding:9px">Integer</td>
<td style="border-style:solid; border-width:1; padding:9px">The maximum y position of the blocks you want</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">y min</td>
<td style="border-style:solid; border-width:1; padding:9px">Integer</td>
<td style="border-style:solid; border-width:1; padding:9px">The minimum y position of the blocks you want</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">z max</td>
<td style="border-style:solid; border-width:1; padding:9px">Integer</td>
<td style="border-style:solid; border-width:1; padding:9px">The maximum z position of the blocks you want</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">z min</td>
<td style="border-style:solid; border-width:1; padding:9px">Integer</td>
<td style="border-style:solid; border-width:1; padding:9px">The minimum z position of the blocks you want</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3><p id="Return Value">Return Value</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Value</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px"></td>
<td style="border-style:solid; border-width:1; padding:9px">array</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px"></td>
<td style="border-style:solid; border-width:1; padding:9px">null</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<br><br>

<h2><p id="getBlocks(Ticking Area, Minimum PositionObject, Maximum PositionObject)">getBlocks(Ticking Area, Minimum PositionObject, Maximum PositionObject)</p></h2>

Allows you to get an array of blocks from the world when provided a minimum and maximum position. The blocks must be within a ticking area. This call can be slow if given a lot of blocks, and should be used infrequently.</br><h3></h3>

<h3><p id="Parameters">Parameters</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">Maximum PositionObject</td>
<td style="border-style:solid; border-width:1; padding:9px">JavaScript Object</td>
<td style="border-style:solid; border-width:1; padding:9px">A JavaScript object with the maximum x, y, and z position of the blocks you want</br><h5><p id="Parameters">Parameters</p></h5>

<h6></h6>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:10px">x</td>
<td style="border-style:solid; border-width:1; padding:10px">Integer</td>
<td style="border-style:solid; border-width:1; padding:10px">The x position</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:10px">y</td>
<td style="border-style:solid; border-width:1; padding:10px">Integer</td>
<td style="border-style:solid; border-width:1; padding:10px">The y position</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:10px">z</td>
<td style="border-style:solid; border-width:1; padding:10px">Integer</td>
<td style="border-style:solid; border-width:1; padding:10px">The z position</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

</td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">Minimum PositionObject</td>
<td style="border-style:solid; border-width:1; padding:9px">JavaScript Object</td>
<td style="border-style:solid; border-width:1; padding:9px">A JavaScript object with the minimum x, y, and z position of the blocks you want</br><h5><p id="Parameters">Parameters</p></h5>

<h6></h6>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:10px">x</td>
<td style="border-style:solid; border-width:1; padding:10px">Integer</td>
<td style="border-style:solid; border-width:1; padding:10px">The x position</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:10px">y</td>
<td style="border-style:solid; border-width:1; padding:10px">Integer</td>
<td style="border-style:solid; border-width:1; padding:10px">The y position</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:10px">z</td>
<td style="border-style:solid; border-width:1; padding:10px">Integer</td>
<td style="border-style:solid; border-width:1; padding:10px">The z position</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

</td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">Ticking Area</td>
<td style="border-style:solid; border-width:1; padding:9px">Ticking Area JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The ticking area the blocks are in</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3><p id="Return Value">Return Value</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Value</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">Array</td>
<td style="border-style:solid; border-width:1; padding:9px">A 3D array of block objects. Indexs are the blocks positions relative to the min position given</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px"></td>
<td style="border-style:solid; border-width:1; padding:9px">null</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<br><br>

<br><br>

<h1><p id="Slash Commands">Slash Commands</p></h1>

<h2></h2>

<h2><p id="executeCommand(Command, Callback)">executeCommand(Command, Callback)</p></h2>

<h3></h3>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">Callback</td>
<td style="border-style:solid; border-width:2; padding:8px">JSON Object</td>
<td style="border-style:solid; border-width:2; padding:8px">The JavaScript object that will be called after the command executes</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">Command</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px">The slash command to run</br></td>
</tr>
</table>
<h3>Example</h3>
<br / ><textarea readonly="true" cols="183" rows="11">
system.executeCommand("/fill ~ ~ ~ ~100 ~5 ~50 stone", (commandResultData) => this.commandCallback(commandResultData));

system.commandCallback = function (commandResultData) {
  let eventData = this.createEventData("minecraft:display_chat_event");
  if (eventData) {
    eventData.data.message = message;
    this.broadcastEvent("minecraft:display_chat_event", "Callback called! Command: " + commandResultData.command + " Data: " + JSON.stringify(commandResultData.data, null, "    ") );
  }
};

</textarea> </br>
<a href="#Index">Back to top</a><br><br>

<br><br>

<br><br>

<h1><p id="Script Components">Script Components</p></h1>

This is the documentation for the attributes, properties, and components available from the Minecraft Script Engine.</br>There are two kinds of components: server components and client components. We will go into a bit more detail on what they are in their respective sections below.</br>Components can be added, retrieved, updated, and removed from entities. They do not exist on their own. Currently only user-defined components can be added and removed from entities. A component must be in an entity in order to retrieve or update it.</br>Check the Script Engine Bindings section to see how to add, remove, retrieve, and update components. This section deals with the specific API of each component.</br><h1><p id="Level Components">Level Components</p></h1>

<h2></h2>

<h2><p id="minecraft:ticking_areas">minecraft:ticking_areas</p></h2>

<a href="#Index">Back to top</a><br><br>

<h2><p id="minecraft:weather">minecraft:weather</p></h2>

<h3></h3>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">do_weather_cycle</td>
<td style="border-style:solid; border-width:2; padding:8px">Boolean</td>
<td style="border-style:solid; border-width:2; padding:8px">This is the world option that determines if the vanilla weather cycle will be used</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">lightning_level</td>
<td style="border-style:solid; border-width:2; padding:8px">Decimal</td>
<td style="border-style:solid; border-width:2; padding:8px">A value between 0 and 1 that determines how much lightning and thunder there is</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">lightning_time</td>
<td style="border-style:solid; border-width:2; padding:8px">Integer</td>
<td style="border-style:solid; border-width:2; padding:8px">How long, in ticks, it will lightning and thunder for</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">rain_level</td>
<td style="border-style:solid; border-width:2; padding:8px">Decimal</td>
<td style="border-style:solid; border-width:2; padding:8px">A value between 0 and 1 that determains how heavy the rainfall is</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">rain_time</td>
<td style="border-style:solid; border-width:2; padding:8px">Integer</td>
<td style="border-style:solid; border-width:2; padding:8px">How long, in ticks, it will rain for</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<br><br>

<h1><p id="Server Components">Server Components</p></h1>

As much as possible, the API of each component matches its JSON counterpart (with some differences noted).</br><h2></h2>

<h2><p id="minecraft:armor_container">minecraft:armor_container</p></h2>

<h3></h3>
<br / ><textarea readonly="true" cols="113" rows="12">
// This example will check the players helmet armor slot for a specific item after the player attacks an entity.
system.listenForEvent("minecraft:player_attacked_entity", function(eventData) {
    // Get the players armor container
    let playerArmor = system.getComponent(eventData.data.player, "minecraft:armor_container");
    // Get the players helmet
    let playerHelmet = playerArmor.data[0];
    // Destroy the attacked entity if the player has a gold helmet equipped
    if (playerHelmet.item == "minecraft:golden_helmet") {
        system.destroyEntity(eventData.data.attacked_entity);
    }
});
</textarea> </br>
<a href="#Index">Back to top</a><br><br>

<h2><p id="minecraft:attack">minecraft:attack</p></h2>

<h3></h3>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">damage</td>
<td style="border-style:solid; border-width:2; padding:8px">Range [a, b]</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">Range of the random amount of damage the melee attack deals. A negative value can heal the entity instead of hurting it</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Default Value</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">range_max</td>
<td style="border-style:solid; border-width:1; padding:9px">Decimal</td>
<td style="border-style:solid; border-width:1; padding:9px">0.0</td>
<td style="border-style:solid; border-width:1; padding:9px">The maximum amount of damage the entity will deal</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">range_min</td>
<td style="border-style:solid; border-width:1; padding:9px">Decimal</td>
<td style="border-style:solid; border-width:1; padding:9px">0.0</td>
<td style="border-style:solid; border-width:1; padding:9px">The minimum amount of damage the entity will deal</br></td>
</tr>
</table>
</td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h2><p id="minecraft:container">minecraft:container</p></h2>

<h3></h3>
<br / ><textarea readonly="true" cols="71" rows="8">
// This example will check if a block has a container.
let block; // check getBlock API on how to access a block
let has_container = system.hasComponent(block, "minecraft:container");
if (has_container === true) {
  let container = system.getComponent(block, "minecraft:container");
  // you can now use the container to read items.

</textarea> </br>
<a href="#Index">Back to top</a><br><br>

<h2><p id="minecraft:collision_box">minecraft:collision_box</p></h2>

Sets the width and height of the Entity's collision box.</br><h3></h3>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">height</td>
<td style="border-style:solid; border-width:2; padding:8px">Decimal</td>
<td style="border-style:solid; border-width:2; padding:8px">1.0</td>
<td style="border-style:solid; border-width:2; padding:8px">Height of the collision box in blocks. A negative value will be assumed to be 0.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">width</td>
<td style="border-style:solid; border-width:2; padding:8px">Decimal</td>
<td style="border-style:solid; border-width:2; padding:8px">1.0</td>
<td style="border-style:solid; border-width:2; padding:8px">Width and Depth of the collision box in blocks. A negative value will be assumed to be 0.</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h2><p id="minecraft:damage_sensor">minecraft:damage_sensor</p></h2>

Defines what events to call when this entity is damaged by specific entities or items.</br><h3></h3>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">triggers</td>
<td style="border-style:solid; border-width:2; padding:8px">List</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">List of triggers with the events to call when taking specific kinds of damage.</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Default Value</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">cause</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px">none</td>
<td style="border-style:solid; border-width:1; padding:9px">Type of damage that triggers the events.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">damage_modifier</td>
<td style="border-style:solid; border-width:1; padding:9px">Decimal</td>
<td style="border-style:solid; border-width:1; padding:9px">0.0</td>
<td style="border-style:solid; border-width:1; padding:9px">A modifier that adds to/removes from the base damage from the damage cause. It does not reduce damage to less than 0.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">damage_multiplier</td>
<td style="border-style:solid; border-width:1; padding:9px">Decimal</td>
<td style="border-style:solid; border-width:1; padding:9px">1.0</td>
<td style="border-style:solid; border-width:1; padding:9px">A multiplier that modifies the base damage from the damage cause. If deals_damage is true the multiplier can only reduce the damage the entity will take to a minimum of 1.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">deals_damage</td>
<td style="border-style:solid; border-width:1; padding:9px">Boolean</td>
<td style="border-style:solid; border-width:1; padding:9px">true</td>
<td style="border-style:solid; border-width:1; padding:9px">If true, the damage dealt to the entity will take away health from it, set to false to make the entity ignore that damage.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">on_damage</td>
<td style="border-style:solid; border-width:1; padding:9px">JSON Object</td>
<td style="border-style:solid; border-width:1; padding:9px"></td>
<td style="border-style:solid; border-width:1; padding:9px">Specifies filters for entity definitions and events.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">on_damage_sound_event</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px"></td>
<td style="border-style:solid; border-width:1; padding:9px">Defines what sound to play, if any, when the on_damage filters are met.</br></td>
</tr>
</table>
</td>
</tr>
</table>
<h3></h3>
<br / ><textarea readonly="true" cols="162" rows="8">
// This example will cause an entity (in this case, a creeper) to start exploding when the player attacks it.
// Note: the entity must have the damage_sensor component and the associated events defined in their JSON description.
this.listenForEvent("minecraft:player_attacked_entity", function(eventData) {
  let damageSensorComponent = serverSystem.getComponent(eventData.attacked_entity, "minecraft:damage_sensor");
  damageSensorComponent.data[0].on_damage = { event:"minecraft:start_exploding", filters:[{test:"has_component", operator:"==", value:"minecraft:breathable"}] };
  serverSystem.applyComponentChanges(eventData.attacked_entity, damageSensorComponent);
});
</textarea> </br>
<a href="#Index">Back to top</a><br><br>

<h2><p id="minecraft:equipment">minecraft:equipment</p></h2>

Sets the Equipment table to use for this Entity.</br><h3></h3>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">slot_drop_chance</td>
<td style="border-style:solid; border-width:2; padding:8px">List</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">A list of slots with the chance to drop an equipped item from that slot.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">table</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">The file path to the equipment table, relative to the behavior pack's root.</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h2><p id="minecraft:equippable">minecraft:equippable</p></h2>

Defines an entity's behavior for having items equipped to it.</br><h3></h3>

<h3><p id="slots">slots</p></h3>

List of slots and the item that can be equipped.</br><h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Default Value</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">accepted_items</td>
<td style="border-style:solid; border-width:1; padding:9px">List</td>
<td style="border-style:solid; border-width:1; padding:9px"></td>
<td style="border-style:solid; border-width:1; padding:9px">The list of items that can go in this slot.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">interact_text</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px"></td>
<td style="border-style:solid; border-width:1; padding:9px">Text to be displayed when the entity can be equipped with this item when playing with Touch-screen controls.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">item</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px"></td>
<td style="border-style:solid; border-width:1; padding:9px">Identifier of the item that can be equipped for this slot.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">on_equip</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px"></td>
<td style="border-style:solid; border-width:1; padding:9px">Event to trigger when this entity is equipped with this item.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">on_unequip</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px"></td>
<td style="border-style:solid; border-width:1; padding:9px">Event to trigger when this item is removed from this entity.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">slot</td>
<td style="border-style:solid; border-width:1; padding:9px">Integer</td>
<td style="border-style:solid; border-width:1; padding:9px">0</td>
<td style="border-style:solid; border-width:1; padding:9px">The slot number of this slot.</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<br><br>

<h2><p id="minecraft:explode">minecraft:explode</p></h2>

Defines how the entity explodes.</br><h3></h3>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">breaks_blocks</td>
<td style="border-style:solid; border-width:2; padding:8px">Boolean</td>
<td style="border-style:solid; border-width:2; padding:8px">true</td>
<td style="border-style:solid; border-width:2; padding:8px">If true, the explosion will destroy blocks in the explosion radius.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">causes_fire</td>
<td style="border-style:solid; border-width:2; padding:8px">Boolean</td>
<td style="border-style:solid; border-width:2; padding:8px">false</td>
<td style="border-style:solid; border-width:2; padding:8px">If true, blocks in the explosion radius will be set on fire.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">destroy_affected_by_griefing</td>
<td style="border-style:solid; border-width:2; padding:8px">Boolean</td>
<td style="border-style:solid; border-width:2; padding:8px">false</td>
<td style="border-style:solid; border-width:2; padding:8px">If true, whether the explosion breaks blocks is affected by the mob griefing game rule.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">fire_affected_by_griefing</td>
<td style="border-style:solid; border-width:2; padding:8px">Boolean</td>
<td style="border-style:solid; border-width:2; padding:8px">false</td>
<td style="border-style:solid; border-width:2; padding:8px">If true, whether the explosion causes fire is affected by the mob griefing game rule.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">fuse_length</td>
<td style="border-style:solid; border-width:2; padding:8px">Range [a, b]</td>
<td style="border-style:solid; border-width:2; padding:8px">[0.0, 0.0]</td>
<td style="border-style:solid; border-width:2; padding:8px">The range for the random amount of time the fuse will be lit before exploding, a negative value means the explosion will be immediate.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">fuse_lit</td>
<td style="border-style:solid; border-width:2; padding:8px">Boolean</td>
<td style="border-style:solid; border-width:2; padding:8px">false</td>
<td style="border-style:solid; border-width:2; padding:8px">If true, the fuse is already lit when this component is added to the entity.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">max_resistance</td>
<td style="border-style:solid; border-width:2; padding:8px">Decimal</td>
<td style="border-style:solid; border-width:2; padding:8px">3.40282e+38</td>
<td style="border-style:solid; border-width:2; padding:8px">A blocks explosion resistance will be capped at this value when an explosion occurs.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">power</td>
<td style="border-style:solid; border-width:2; padding:8px">Decimal</td>
<td style="border-style:solid; border-width:2; padding:8px">3</td>
<td style="border-style:solid; border-width:2; padding:8px">The radius of the explosion in blocks and the amount of damage the explosion deals.</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h2><p id="minecraft:hand_container">minecraft:hand_container</p></h2>

<h3></h3>
<br / ><textarea readonly="true" cols="108" rows="12">
// This example will check the players offhand slot for a specific item after the player attacks an entity.
system.listenForEvent("minecraft:player_attacked_entity", function(eventData) {
    // Get the players hand container
    let handContainer = system.getComponent(eventData.data.player, "minecraft:hand_container");
    // Get the players offhand item
    let offhandItem = handContainer.data[1];
    // Destroy the attacked entity if the player has a totem in their offhand
    if (offhandItem.item == "minecraft:totem") {
        system.destroyEntity(eventData.data.attacked_entity);
    }
});
</textarea> </br>
<a href="#Index">Back to top</a><br><br>

<h2><p id="minecraft:healable">minecraft:healable</p></h2>

Defines the interactions with this entity for healing it.</br><h3></h3>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">filters</td>
<td style="border-style:solid; border-width:2; padding:8px">Minecraft Filter</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">The filter group that defines the conditions for using this item to heal the entity.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">force_use</td>
<td style="border-style:solid; border-width:2; padding:8px">Boolean</td>
<td style="border-style:solid; border-width:2; padding:8px">false</td>
<td style="border-style:solid; border-width:2; padding:8px">Determines if item can be used regardless of entity being at full health.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">items</td>
<td style="border-style:solid; border-width:2; padding:8px">Array</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">The array of items that can be used to heal this entity.</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Default Value</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">heal_amount</td>
<td style="border-style:solid; border-width:1; padding:9px">Integer</td>
<td style="border-style:solid; border-width:1; padding:9px">1</td>
<td style="border-style:solid; border-width:1; padding:9px">The amount of health this entity gains when fed this item.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">item</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px"></td>
<td style="border-style:solid; border-width:1; padding:9px">Item identifier that can be used to heal this entity.</br></td>
</tr>
</table>
</td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h2><p id="minecraft:health">minecraft:health</p></h2>

<h3></h3>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">max</td>
<td style="border-style:solid; border-width:2; padding:8px">Integer</td>
<td style="border-style:solid; border-width:2; padding:8px">10</td>
<td style="border-style:solid; border-width:2; padding:8px">The maximum health the entity can heal</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">value</td>
<td style="border-style:solid; border-width:2; padding:8px">Integer</td>
<td style="border-style:solid; border-width:2; padding:8px">1</td>
<td style="border-style:solid; border-width:2; padding:8px">Current health of the entity</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h2><p id="minecraft:hotbar_container">minecraft:hotbar_container</p></h2>

<h3></h3>
<br / ><textarea readonly="true" cols="118" rows="12">
// This example will check the players first hotbar item slot for a specific item after the player attacks an entity.
system.listenForEvent("minecraft:player_attacked_entity", function(eventData) {
    // Get the players hotbar
    let playerHotbar = system.getComponent(eventData.data.player, "minecraft:hotbar_container");
    // Get the item at the first slot in the hotbar
    let firstHotbarSlot = playerHotbar.data[0];
    // Destroy the attacked entity if the player has an apple in their first hotbar slot
    if (firstHotbarSlot.item == "minecraft:apple") {
        system.destroyEntity(eventData.data.attacked_entity);
    }
});
</textarea> </br>
<a href="#Index">Back to top</a><br><br>

<h2><p id="minecraft:interact">minecraft:interact</p></h2>

<h3></h3>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">add_items</td>
<td style="border-style:solid; border-width:2; padding:8px">JSON Object</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">Loot table with items to add to the player's inventory upon successful interaction</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Default Value</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">table</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px"></td>
<td style="border-style:solid; border-width:1; padding:9px">File path, relative to the behavior pack's path, to the loot table file</br></td>
</tr>
</table>
</td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">cooldown</td>
<td style="border-style:solid; border-width:2; padding:8px">Decimal</td>
<td style="border-style:solid; border-width:2; padding:8px">0.0</td>
<td style="border-style:solid; border-width:2; padding:8px">Time in seconds before this entity can be interacted with again</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">hurt_item</td>
<td style="border-style:solid; border-width:2; padding:8px">Integer</td>
<td style="border-style:solid; border-width:2; padding:8px">0</td>
<td style="border-style:solid; border-width:2; padding:8px">The amount of damage the item will take when used to interact with this entity. A value of 0 means the item won't lose durability</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">interact_text</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">Text to show when the player is able to interact in this way with this entity when playing with Touch-screen controls</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">on_interact</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">An event identifier to fire when the interaction occurs</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">particle_on_start</td>
<td style="border-style:solid; border-width:2; padding:8px">JSON Object</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">Particle effect that will be triggered at the start of the interaction</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Default Value</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">particle_offset_towards_interactor</td>
<td style="border-style:solid; border-width:1; padding:9px">Boolean</td>
<td style="border-style:solid; border-width:1; padding:9px">false</td>
<td style="border-style:solid; border-width:1; padding:9px">Whether or not the particle will appear closer to who performed the interaction</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">particle_type</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px"></td>
<td style="border-style:solid; border-width:1; padding:9px">The type of particle that will be spawned</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">particle_y_offset</td>
<td style="border-style:solid; border-width:1; padding:9px">Decimal</td>
<td style="border-style:solid; border-width:1; padding:9px">0.0</td>
<td style="border-style:solid; border-width:1; padding:9px">Will offset the particle this amount in the y direction</br></td>
</tr>
</table>
</td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">play_sounds</td>
<td style="border-style:solid; border-width:2; padding:8px">Array</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">An array of sound identifiers to play when the interaction occurs</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">spawn_entities</td>
<td style="border-style:solid; border-width:2; padding:8px">Array</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">An array of entity identifiers to spawn when the interaction occurs</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">spawn_items</td>
<td style="border-style:solid; border-width:2; padding:8px">JSON Object</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">Loot table with items to drop on the ground upon successful interaction</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Default Value</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">table</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px"></td>
<td style="border-style:solid; border-width:1; padding:9px">File path, relative to the behavior pack's path, to the loot table file</br></td>
</tr>
</table>
</td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">swing</td>
<td style="border-style:solid; border-width:2; padding:8px">Boolean</td>
<td style="border-style:solid; border-width:2; padding:8px">false</td>
<td style="border-style:solid; border-width:2; padding:8px">If true, the player will do the 'swing' animation when interacting with this entity</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">transform_to_item</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">The item used will transform to this item upon successful interaction. Format: itemName:auxValue</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">use_item</td>
<td style="border-style:solid; border-width:2; padding:8px">Boolean</td>
<td style="border-style:solid; border-width:2; padding:8px">false</td>
<td style="border-style:solid; border-width:2; padding:8px">If true, the interaction will use an item</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h2><p id="minecraft:inventory">minecraft:inventory</p></h2>

<h3></h3>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">additional_slots_per_strength</td>
<td style="border-style:solid; border-width:2; padding:8px">Integer</td>
<td style="border-style:solid; border-width:2; padding:8px">0</td>
<td style="border-style:solid; border-width:2; padding:8px">Number of slots that this entity can gain per extra strength</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">can_be_siphoned_from</td>
<td style="border-style:solid; border-width:2; padding:8px">Boolean</td>
<td style="border-style:solid; border-width:2; padding:8px">false</td>
<td style="border-style:solid; border-width:2; padding:8px">If true, the contents of this inventory can be removed by a hopper</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">container_type</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px">none</td>
<td style="border-style:solid; border-width:2; padding:8px">Type of container this entity has. Can be horse, minecart_chest, minecart_hopper, inventory, container or hopper</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">inventory_size</td>
<td style="border-style:solid; border-width:2; padding:8px">Integer</td>
<td style="border-style:solid; border-width:2; padding:8px">5</td>
<td style="border-style:solid; border-width:2; padding:8px">Number of slots the container has</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">private</td>
<td style="border-style:solid; border-width:2; padding:8px">Boolean</td>
<td style="border-style:solid; border-width:2; padding:8px">false</td>
<td style="border-style:solid; border-width:2; padding:8px">If true, only the entity can access the inventory</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">restrict_to_owner</td>
<td style="border-style:solid; border-width:2; padding:8px">Boolean</td>
<td style="border-style:solid; border-width:2; padding:8px">false</td>
<td style="border-style:solid; border-width:2; padding:8px">If true, the entity's inventory can only be accessed by its owner or itself</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h2><p id="minecraft:inventory_container">minecraft:inventory_container</p></h2>

<h3></h3>
<br / ><textarea readonly="true" cols="121" rows="12">
// This example will check the players third inventory item slot for a specific item after the player attacks an entity.
system.listenForEvent("minecraft:player_attacked_entity", function(eventData) {
    // Get the players inventory
    let playerInventory = system.getComponent(eventData.data.player, "minecraft:inventory_container");
    // Get the item at the third slot in the inventory
    let thirdItemSlot = playerInventory.data[2];
    // Destroy the attacked entity if the player has an apple in their third item slot
    if (thirdItemSlot.item == "minecraft:apple") {
        system.destroyEntity(eventData.data.attacked_entity);
    }
});
</textarea> </br>
<a href="#Index">Back to top</a><br><br>

<h2><p id="minecraft:lookat">minecraft:lookat</p></h2>

Defines the behavior when another entity looks at this entity.</br><h3></h3>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">allow_invulnerable</td>
<td style="border-style:solid; border-width:2; padding:8px">Boolean</td>
<td style="border-style:solid; border-width:2; padding:8px">false</td>
<td style="border-style:solid; border-width:2; padding:8px">If true, invulnerable entities (e.g. Players in creative mode) are considered valid targets.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">filters</td>
<td style="border-style:solid; border-width:2; padding:8px">Minecraft Filter</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">Defines the entities that can trigger this component.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">look_cooldown</td>
<td style="border-style:solid; border-width:2; padding:8px">Range [a, b]</td>
<td style="border-style:solid; border-width:2; padding:8px">[0, 0]</td>
<td style="border-style:solid; border-width:2; padding:8px">The range for the random amount of time during which the entity is 'cooling down' and won't get angered or look for a target.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">look_event</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">The event identifier to run when the entities specified in filters look at this entity.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">search_radius</td>
<td style="border-style:solid; border-width:2; padding:8px">Decimal</td>
<td style="border-style:solid; border-width:2; padding:8px">10</td>
<td style="border-style:solid; border-width:2; padding:8px">Maximum distance this entity will look for another entity looking at it.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">set_target</td>
<td style="border-style:solid; border-width:2; padding:8px">Boolean</td>
<td style="border-style:solid; border-width:2; padding:8px">true</td>
<td style="border-style:solid; border-width:2; padding:8px">If true, this entity will set the attack target as the entity that looked at it.</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h2><p id="minecraft:nameable">minecraft:nameable</p></h2>

<h3></h3>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">allow_name_tag_renaming</td>
<td style="border-style:solid; border-width:2; padding:8px">Boolean</td>
<td style="border-style:solid; border-width:2; padding:8px">true</td>
<td style="border-style:solid; border-width:2; padding:8px">If true, this entity can be renamed with name tags</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">always_show</td>
<td style="border-style:solid; border-width:2; padding:8px">Boolean</td>
<td style="border-style:solid; border-width:2; padding:8px">false</td>
<td style="border-style:solid; border-width:2; padding:8px">If true, the name will always be shown</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">default_trigger</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">Trigger to run when the entity gets named</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">name</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">The current name of the entity, empty if the entity hasn't been named yet, making this non-empty will apply the name to the entity</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">name_actions</td>
<td style="border-style:solid; border-width:2; padding:8px">JSON Object</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">Describes the special names for this entity and the events to call when the entity acquires those names</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Default Value</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">name_filter</td>
<td style="border-style:solid; border-width:1; padding:9px">List</td>
<td style="border-style:solid; border-width:1; padding:9px"></td>
<td style="border-style:solid; border-width:1; padding:9px">List of special names that will cause the events defined in 'on_named' to fire</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">on_named</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px"></td>
<td style="border-style:solid; border-width:1; padding:9px">Event to be called when this entity acquires the name specified in 'name_filter'</br></td>
</tr>
</table>
</td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h2><p id="minecraft:position">minecraft:position</p></h2>

<h3></h3>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">x</td>
<td style="border-style:solid; border-width:2; padding:8px">Decimal</td>
<td style="border-style:solid; border-width:2; padding:8px">0.0</td>
<td style="border-style:solid; border-width:2; padding:8px">Position along the X-Axis (east-west) of the entity</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">y</td>
<td style="border-style:solid; border-width:2; padding:8px">Decimal</td>
<td style="border-style:solid; border-width:2; padding:8px">0.0</td>
<td style="border-style:solid; border-width:2; padding:8px">Position along the Y-Axis (height) of the entity</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">z</td>
<td style="border-style:solid; border-width:2; padding:8px">Decimal</td>
<td style="border-style:solid; border-width:2; padding:8px">0.0</td>
<td style="border-style:solid; border-width:2; padding:8px">Position along the Z-Axis (north-south) of the entity</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h2><p id="minecraft:rotation">minecraft:rotation</p></h2>

<h3></h3>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">x</td>
<td style="border-style:solid; border-width:2; padding:8px">Decimal</td>
<td style="border-style:solid; border-width:2; padding:8px">0.0</td>
<td style="border-style:solid; border-width:2; padding:8px">Controls the head rotation looking up and down</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">y</td>
<td style="border-style:solid; border-width:2; padding:8px">Decimal</td>
<td style="border-style:solid; border-width:2; padding:8px">0.0</td>
<td style="border-style:solid; border-width:2; padding:8px">Controls the body rotation parallel to the floor</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h2><p id="minecraft:shooter">minecraft:shooter</p></h2>

<h3></h3>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">auxVal</td>
<td style="border-style:solid; border-width:2; padding:8px">Integer</td>
<td style="border-style:solid; border-width:2; padding:8px">-1</td>
<td style="border-style:solid; border-width:2; padding:8px">ID of the Potion effect to be applied on hit</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">def</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">Entity identifier to use as projectile for the ranged attack. The entity must have the projectile component to be able to be shot as a projectile</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h2><p id="minecraft:spawn_entity">minecraft:spawn_entity</p></h2>

Adds a timer after which this entity will spawn another entity or item (similar to vanilla's chicken's egg-laying behavior).</br><h3></h3>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">filters</td>
<td style="border-style:solid; border-width:2; padding:8px">Minecraft Filter</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">If present, the specified entity will only spawn if the filter evaluates to true.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">max_wait_time</td>
<td style="border-style:solid; border-width:2; padding:8px">Integer</td>
<td style="border-style:solid; border-width:2; padding:8px">600</td>
<td style="border-style:solid; border-width:2; padding:8px">Maximum amount of time to randomly wait in seconds before another entity is spawned.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">min_wait_time</td>
<td style="border-style:solid; border-width:2; padding:8px">Integer</td>
<td style="border-style:solid; border-width:2; padding:8px">300</td>
<td style="border-style:solid; border-width:2; padding:8px">Minimum amount of time to randomly wait in seconds before another entity is spawned.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">num_to_spawn</td>
<td style="border-style:solid; border-width:2; padding:8px">Integer</td>
<td style="border-style:solid; border-width:2; padding:8px">1</td>
<td style="border-style:solid; border-width:2; padding:8px">The number of entities of this type to spawn each time that this triggers.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">should_leash</td>
<td style="border-style:solid; border-width:2; padding:8px">Boolean</td>
<td style="border-style:solid; border-width:2; padding:8px">false</td>
<td style="border-style:solid; border-width:2; padding:8px">If true, this the spawned entity will be leashed to the parent.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">single_use</td>
<td style="border-style:solid; border-width:2; padding:8px">Boolean</td>
<td style="border-style:solid; border-width:2; padding:8px">false</td>
<td style="border-style:solid; border-width:2; padding:8px">If true, this component will only ever spawn the specified entity once.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">spawn_entity</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">Identifier of the entity to spawn, leave empty to spawn the item defined above instead.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">spawn_event</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px">minecraft:entity_born</td>
<td style="border-style:solid; border-width:2; padding:8px">Event to call when the entity is spawned.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">spawn_item</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px">egg</td>
<td style="border-style:solid; border-width:2; padding:8px">Item identifier of the item to spawn.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">spawn_method</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px">born</td>
<td style="border-style:solid; border-width:2; padding:8px">Method to use to spawn the entity.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">spawn_sound</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px">plop</td>
<td style="border-style:solid; border-width:2; padding:8px">Identifier of the sound effect to play when the entity is spawned.</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h2><p id="minecraft:tag">minecraft:tag</p></h2>

<a href="#Index">Back to top</a><br><br>

<h2><p id="minecraft:teleport">minecraft:teleport</p></h2>

<h3></h3>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">dark_teleport_chance</td>
<td style="border-style:solid; border-width:2; padding:8px">Decimal</td>
<td style="border-style:solid; border-width:2; padding:8px">0.01</td>
<td style="border-style:solid; border-width:2; padding:8px">Modifies the chance that the entity will teleport if the entity is in darkness</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">light_teleport_chance</td>
<td style="border-style:solid; border-width:2; padding:8px">Decimal</td>
<td style="border-style:solid; border-width:2; padding:8px">0.01</td>
<td style="border-style:solid; border-width:2; padding:8px">Modifies the chance that the entity will teleport if the entity is in daylight</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">max_random_teleport_time</td>
<td style="border-style:solid; border-width:2; padding:8px">Decimal</td>
<td style="border-style:solid; border-width:2; padding:8px">20</td>
<td style="border-style:solid; border-width:2; padding:8px">Maximum amount of time in seconds between random teleports</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">min_random_teleport_time</td>
<td style="border-style:solid; border-width:2; padding:8px">Decimal</td>
<td style="border-style:solid; border-width:2; padding:8px">0</td>
<td style="border-style:solid; border-width:2; padding:8px">Minimum amount of time in seconds between random teleports</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">random_teleport_cube</td>
<td style="border-style:solid; border-width:2; padding:8px">Vector [a, b, c]</td>
<td style="border-style:solid; border-width:2; padding:8px">[32, 16, 32]</td>
<td style="border-style:solid; border-width:2; padding:8px">Entity will teleport to a random position within the area defined by this cube</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">random_teleports</td>
<td style="border-style:solid; border-width:2; padding:8px">Boolean</td>
<td style="border-style:solid; border-width:2; padding:8px">true</td>
<td style="border-style:solid; border-width:2; padding:8px">If true, the entity will teleport randomly</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">target_distance</td>
<td style="border-style:solid; border-width:2; padding:8px">Decimal</td>
<td style="border-style:solid; border-width:2; padding:8px">16</td>
<td style="border-style:solid; border-width:2; padding:8px">Maximum distance the entity will teleport when chasing a target</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">target_teleport_chance</td>
<td style="border-style:solid; border-width:2; padding:8px">Decimal</td>
<td style="border-style:solid; border-width:2; padding:8px">1</td>
<td style="border-style:solid; border-width:2; padding:8px">The chance that the entity will teleport between 0.0 and 1.0. 1.0 means 100%</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h2><p id="minecraft:ticking_area_description">minecraft:ticking_area_description</p></h2>

<h3></h3>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">is_circle</td>
<td style="border-style:solid; border-width:2; padding:8px">Boolean</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">Is the area a circle. If false the area is a square.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">max</td>
<td style="border-style:solid; border-width:2; padding:8px">Vector [a, b, c]</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">(if area is a square) The edge of the area.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">name</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">The name of the area.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">origin</td>
<td style="border-style:solid; border-width:2; padding:8px">Vector [a, b, c]</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">The origin position of the area.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">radius</td>
<td style="border-style:solid; border-width:2; padding:8px">Vector [a, b, c]</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">(if area is a circle) The radius of the area.</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h2><p id="minecraft:tick_world">minecraft:tick_world</p></h2>

<h3></h3>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">distance_to_players</td>
<td style="border-style:solid; border-width:2; padding:8px">Decimal</td>
<td style="border-style:solid; border-width:2; padding:8px">distance_to_players</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">never_despawn</td>
<td style="border-style:solid; border-width:2; padding:8px">Boolean</td>
<td style="border-style:solid; border-width:2; padding:8px">Whether or not this ticking area will despawn when a player is out of range</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">radius</td>
<td style="border-style:solid; border-width:2; padding:8px">Integer</td>
<td style="border-style:solid; border-width:2; padding:8px">The radius in chunks of the ticking area</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">ticking_area</td>
<td style="border-style:solid; border-width:2; padding:8px">Entity Ticking Area JS API Object</td>
<td style="border-style:solid; border-width:2; padding:8px">The ticking area entity that is attached to this entity</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h2><p id="minecraft:transformation">minecraft:transformation</p></h2>

<h3></h3>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">add</td>
<td style="border-style:solid; border-width:2; padding:8px">JSON Object</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">List of components to add to the entity after the transformation</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Default Value</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">component_groups</td>
<td style="border-style:solid; border-width:1; padding:9px">List</td>
<td style="border-style:solid; border-width:1; padding:9px"></td>
<td style="border-style:solid; border-width:1; padding:9px">Names of component groups to add</br></td>
</tr>
</table>
</td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">begin_transform_sound</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">Sound to play when the transformation starts</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">delay</td>
<td style="border-style:solid; border-width:2; padding:8px">JSON Object</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">Defines the properties of the delay for the transformation</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Default Value</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">block_assist_chance</td>
<td style="border-style:solid; border-width:1; padding:9px">Decimal</td>
<td style="border-style:solid; border-width:1; padding:9px">0.0</td>
<td style="border-style:solid; border-width:1; padding:9px">Chance that the entity will look for nearby blocks that can speed up the transformation. Value must be between 0.0 and 1.0</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">block_chance</td>
<td style="border-style:solid; border-width:1; padding:9px">Decimal</td>
<td style="border-style:solid; border-width:1; padding:9px">0.0</td>
<td style="border-style:solid; border-width:1; padding:9px">Chance that, once a block is found, will help speed up the transformation</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">block_max</td>
<td style="border-style:solid; border-width:1; padding:9px">Integer</td>
<td style="border-style:solid; border-width:1; padding:9px">0</td>
<td style="border-style:solid; border-width:1; padding:9px">Maximum number of blocks the entity will look for to aid in the transformation. If not defined or set to 0, it will be set to the block radius</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">block_radius</td>
<td style="border-style:solid; border-width:1; padding:9px">Integer</td>
<td style="border-style:solid; border-width:1; padding:9px">0</td>
<td style="border-style:solid; border-width:1; padding:9px">Distance in Blocks that the entity will search for blocks that can help the transformation</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">block_types</td>
<td style="border-style:solid; border-width:1; padding:9px">List</td>
<td style="border-style:solid; border-width:1; padding:9px"></td>
<td style="border-style:solid; border-width:1; padding:9px">List of blocks that can help the transformation of this entity</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">keep_owner</td>
<td style="border-style:solid; border-width:1; padding:9px">Boolean</td>
<td style="border-style:solid; border-width:1; padding:9px"></td>
<td style="border-style:solid; border-width:1; padding:9px">If this entity is owned by another entity, it should remain owned after transformation</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">value</td>
<td style="border-style:solid; border-width:1; padding:9px">Decimal</td>
<td style="border-style:solid; border-width:1; padding:9px">0.0</td>
<td style="border-style:solid; border-width:1; padding:9px">Time in seconds before the entity transforms</br></td>
</tr>
</table>
</td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">drop_equipment</td>
<td style="border-style:solid; border-width:2; padding:8px">Boolean</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">Cause the entity to drop all equipment upon transformation</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">into</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">Entity Definition that this entity will transform into</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">transformation_sound</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">Sound to play when the entity is done transforming</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<br><br>

<h1><p id="Client Components">Client Components</p></h1>

<h2></h2>

<h2><p id="minecraft:molang">minecraft:molang</p></h2>

<h3>Code Example:</h3>
<br / ><textarea readonly="true" cols="73" rows="5">
let molangComponent = this.createComponent(entity, "minecraft:molang"); 
molangComponent["variable.molangexample"] = 1.0; 
this.applyComponentChanges(molangComponent); 

</textarea> </br>
<a href="#Index">Back to top</a><br><br>

<br><br>

<h1><p id="Block Components">Block Components</p></h1>

<h2></h2>

<h2><p id="minecraft:blockstate">minecraft:blockstate</p></h2>

<h3>Code Example:</h3>
<br / ><textarea readonly="true" cols="76" rows="5">
let blockstateComponent = this.getComponent(block, "minecraft:blockstate");
blockstateComponent.data.coral_color = "blue";
this.applyComponentChanges(block, blockstateComponent);

</textarea> </br>
<a href="#Index">Back to top</a><br><br>

<br><br>

<br><br>

<h1><p id="Script Events">Script Events</p></h1>

Here you can find the list of events that you can listen for and respond to in your scripts.</br><h1><p id="Client Events">Client Events</p></h1>

<h2></h2>

<h2><p id="Listening Events">Listening Events</p></h2>

<h3></h3>

<h3><p id="minecraft:client_entered_world">minecraft:client_entered_world</p></h3>

<a href="#Index">Back to top</a><br><br>

<h3><p id="minecraft:hit_result_changed">minecraft:hit_result_changed</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">entity</td>
<td style="border-style:solid; border-width:1; padding:9px">Entity JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The entity that was hit or null if it fired when moving off of an entity</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">position</td>
<td style="border-style:solid; border-width:1; padding:9px">Vector [a, b, c]</td>
<td style="border-style:solid; border-width:1; padding:9px">The position of the entity that was hit or null if it fired when moving off an entity</br></td>
</tr>
</table>
<h4>Code Example:</h4>
Responding to hit_result_changed<br / ><textarea readonly="true" cols="127" rows="14">
const mySystem = client.registerSystem(0, 0);

mySystem.initialize = function() {
  this.listenForEvent("minecraft:hit_result_changed", (eventData) => this.onHitChanged(eventData));
};

mySystem.onHitChanged = function(eventData) {
  if(eventData.position != null) {
    let chatEvent = this.createEventData("minecraft:display_chat_event");
    chatEvent.data.message = "Hit at x:" + eventData.position.x + " y:" + eventData.position.y + " z:" + eventData.position.z;
    this.broadcastEvent("minecraft:display_chat_event", chatEvent);
  }
};
</textarea> </br>
<a href="#Index">Back to top</a><br><br>

<h3><p id="minecraft:hit_result_continuous">minecraft:hit_result_continuous</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">entity</td>
<td style="border-style:solid; border-width:1; padding:9px">Entity JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The entity that was hit or null if it not pointing at an entity</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">position</td>
<td style="border-style:solid; border-width:1; padding:9px">Vector [a, b, c]</td>
<td style="border-style:solid; border-width:1; padding:9px">The position of the entity that was hit or block that was hit</br></td>
</tr>
</table>
<h4>Code Example:</h4>
Responding to hit_result_continuous<br / ><textarea readonly="true" cols="132" rows="14">
const mySystem = client.registerSystem(0, 0);

mySystem.initialize = function() {
  this.listenForEvent("minecraft:hit_result_continuous", (eventData) => this.onHit(eventData));
};

mySystem.onHit = function(eventData) {
  if(eventData.position != null) {
    let chatEvent = this.createEventData("minecraft:display_chat_event");
    chatEvent.data.message = "Position at x:" + eventData.position.x + " y:" + eventData.position.y + " z:" + eventData.position.z;
    this.broadcastEvent("minecraft:display_chat_event", chatEvent);
  }
};
</textarea> </br>
<a href="#Index">Back to top</a><br><br>

<h3><p id="minecraft:pick_hit_result_changed">minecraft:pick_hit_result_changed</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">entity</td>
<td style="border-style:solid; border-width:1; padding:9px">Entity JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The entity that was hit or null if it fired when moving off of an entity</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">position</td>
<td style="border-style:solid; border-width:1; padding:9px">Vector [a, b, c]</td>
<td style="border-style:solid; border-width:1; padding:9px">The position of the entity that was hit or null if it fired when moving off an entity</br></td>
</tr>
</table>
<h4>Code Example:</h4>
Responding to pick_hit_result_changed<br / ><textarea readonly="true" cols="128" rows="14">
const mySystem = client.registerSystem(0, 0);

mySystem.initialize = function() {
  this.listenForEvent("minecraft:pick_hit_result_changed", (eventData) => this.onPickChanged(eventData));
};

mySystem.onPickChanged = function(eventData) {
  if(eventData.position != null) {
    let chatEvent = this.createEventData("minecraft:display_chat_event");
    chatEvent.data.message = "Pick at x:" + eventData.position.x + " y:" + eventData.position.y + " z:" + eventData.position.z;
    this.broadcastEvent("minecraft:display_chat_event", chatEvent);
  }
};
</textarea> </br>
<a href="#Index">Back to top</a><br><br>

<h3><p id="minecraft:pick_hit_result_continuous">minecraft:pick_hit_result_continuous</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">entity</td>
<td style="border-style:solid; border-width:1; padding:9px">Entity JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The entity that was hit or null if it not pointing at an entity</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">position</td>
<td style="border-style:solid; border-width:1; padding:9px">Vector [a, b, c]</td>
<td style="border-style:solid; border-width:1; padding:9px">The position of the entity that was hit or block that was hit</br></td>
</tr>
</table>
<h4>Code Example:</h4>
Responding to pick_hit_result_continuous<br / ><textarea readonly="true" cols="157" rows="14">
const mySystem = client.registerSystem(0, 0);

mySystem.initialize = function() {
  this.listenForEvent("minecraft:pick_hit_result_continuous", (eventData) => this.onPick(eventData));
};

mySystem.onPick = function(eventData) {
  if(eventData.position != null) {
    let chatEvent = this.createEventData("minecraft:display_chat_event");
    chatEvent.data.message = "Pick at:" + eventData.position.x + " y:" + eventData.position.y + " z:" + eventData.position.y + " z:" + eventData.position.z;
    this.broadcastEvent("minecraft:display_chat_event", chatEvent);
  }
};
</textarea> </br>
<a href="#Index">Back to top</a><br><br>

<br><br>

<h2><p id="Trigger-able Events">Trigger-able Events</p></h2>

<h3></h3>

<h3><p id="minecraft:display_chat_event">minecraft:display_chat_event</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Default Value</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">message</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px"></td>
<td style="border-style:solid; border-width:1; padding:9px">The chat message that will be displayed</br></td>
</tr>
</table>
<h4>Code Example:</h4>
Trigger chat event<br / ><textarea readonly="true" cols="72" rows="8">
const mySystem = server.registerSystem(0, 0);

mySystem.update = function() {
  let chatEvent = this.createEventData("minecraft:display_chat_event");
  chatEvent.data.message = "Hello, World!";
  this.broadcastEvent("minecraft:display_chat_event", chatEvent);
};
</textarea> </br>
<a href="#Index">Back to top</a><br><br>

<h3><p id="minecraft:load_ui">minecraft:load_ui</p></h3>

<h4>Event Data Parameters</h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Default Value</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">options</td>
<td style="border-style:solid; border-width:1; padding:9px">JSON Object</td>
<td style="border-style:solid; border-width:1; padding:9px"></td>
<td style="border-style:solid; border-width:1; padding:9px">You can define the following options for the screen by setting their value to true or false:</br><h5><p id="absorbs_input">absorbs_input</p></h5>

If true, input will not be passed down to any other screens underneath</br><a href="#Index">Back to top</a><br><br>

<h5><p id="always_accepts_input">always_accepts_input</p></h5>

If true, the screen will always accept and process input for as long as it is in the stack, even if other custom UI screens appear on top of it</br><a href="#Index">Back to top</a><br><br>

<h5><p id="force_render_below">force_render_below</p></h5>

If true, this screen will be rendered even if another screen is on top of it and will render over them, including the HUD</br><a href="#Index">Back to top</a><br><br>

<h5><p id="is_showing_menu">is_showing_menu</p></h5>

If true, the screen will be treated as the pause menu and the pause menu won't be allowed to show on top of this screen</br><a href="#Index">Back to top</a><br><br>

<h5><p id="render_game_behind">render_game_behind</p></h5>

If true, the game will continue to be rendered underneath this screen</br><a href="#Index">Back to top</a><br><br>

<h5><p id="render_only_when_topmost">render_only_when_topmost</p></h5>

If true, this screen will only be rendered if it is the screen at the top of the stack</br><a href="#Index">Back to top</a><br><br>

<h5><p id="should_steal_mouse">should_steal_mouse</p></h5>

If true, the screen will capture the mouse pointer and limit its movement to the UI screen</br><a href="#Index">Back to top</a><br><br>

</td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">path</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px"></td>
<td style="border-style:solid; border-width:1; padding:9px">The file path to the screen's HTML file</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3><p id="minecraft:send_ui_event">minecraft:send_ui_event</p></h3>

Custom UI is based on HTML 5. Review the scripting demo for an example of a custom UI file.</br><h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">data</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px">The data for the UI event being triggered</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">eventIdentifier</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px">The identifier of the UI event</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3><p id="minecraft:spawn_particle_attached_entity">minecraft:spawn_particle_attached_entity</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Default Value</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">effect</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px"></td>
<td style="border-style:solid; border-width:1; padding:9px">The identifier of the particle effect you want to attach to the entity. This is the same name you gave the effect in its JSON file</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">entity</td>
<td style="border-style:solid; border-width:1; padding:9px">Entity JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px"></td>
<td style="border-style:solid; border-width:1; padding:9px">The entity object you want to attach the effect to</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">offset</td>
<td style="border-style:solid; border-width:1; padding:9px">Vector [a, b, c]</td>
<td style="border-style:solid; border-width:1; padding:9px">[0, 0, 0]</td>
<td style="border-style:solid; border-width:1; padding:9px">The offset from the entity's "center" where you want to spawn the effect</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3><p id="minecraft:spawn_particle_in_world">minecraft:spawn_particle_in_world</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Default Value</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">effect</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px"></td>
<td style="border-style:solid; border-width:1; padding:9px">The identifier of the particle effect you want to attach to spawn. This is the same name you gave the effect in its JSON file</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">position</td>
<td style="border-style:solid; border-width:1; padding:9px">Vector [a, b, c]</td>
<td style="border-style:solid; border-width:1; padding:9px">[0, 0, 0]</td>
<td style="border-style:solid; border-width:1; padding:9px">The position in the world where you want to spawn the effect</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3><p id="minecraft:unload_ui">minecraft:unload_ui</p></h3>

<a href="#Index">Back to top</a><br><br>

<h3><p id="minecraft:script_logger_config">minecraft:script_logger_config</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Default Value</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">log_errors</td>
<td style="border-style:solid; border-width:1; padding:9px">Boolean</td>
<td style="border-style:solid; border-width:1; padding:9px">false</td>
<td style="border-style:solid; border-width:1; padding:9px">Set to true to log any scripting errors that occur on the client</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">log_information</td>
<td style="border-style:solid; border-width:1; padding:9px">Boolean</td>
<td style="border-style:solid; border-width:1; padding:9px">false</td>
<td style="border-style:solid; border-width:1; padding:9px">Set to true to log any general scripting information that occurs on the client. This includes any logging done with client.log()</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">log_warnings</td>
<td style="border-style:solid; border-width:1; padding:9px">Boolean</td>
<td style="border-style:solid; border-width:1; padding:9px">false</td>
<td style="border-style:solid; border-width:1; padding:9px">Set to true to log any scripting warnings that occur on the client</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<br><br>

<br><br>

<h1><p id="Server Events">Server Events</p></h1>

<h2></h2>

<h2><p id="Listening Events">Listening Events</p></h2>

<h3></h3>

<h3><p id="minecraft:entity_attack">minecraft:entity_attack</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">entity</td>
<td style="border-style:solid; border-width:1; padding:9px">Entity JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The entity that attacked</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">target</td>
<td style="border-style:solid; border-width:1; padding:9px">Entity JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The entity that was targeted in the attack</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3><p id="minecraft:player_attacked_entity">minecraft:player_attacked_entity</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">attacked_entity</td>
<td style="border-style:solid; border-width:1; padding:9px">Entity JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The entity that was attacked by the player</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">player</td>
<td style="border-style:solid; border-width:1; padding:9px">Entity JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The player that attacked an entity</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3><p id="minecraft:entity_acquired_item">minecraft:entity_acquired_item</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">acquired_amount</td>
<td style="border-style:solid; border-width:1; padding:9px">Integer</td>
<td style="border-style:solid; border-width:1; padding:9px">The total number of items acquired by the entity during this event</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">acquisition_method</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px">The way the entity acquired the item</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">entity</td>
<td style="border-style:solid; border-width:1; padding:9px">Entity JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The entity who acquired the item</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">item_stack</td>
<td style="border-style:solid; border-width:1; padding:9px">ItemStack JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The item that was acquired</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">secondary_entity</td>
<td style="border-style:solid; border-width:1; padding:9px">Entity JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px">If it exists, the entity that affected the item before it was acquired. Example: A player completes a trade with a villager. The `entity` property would be the player and the `secondary_entity` would be the villager</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3><p id="minecraft:entity_carried_item_changed">minecraft:entity_carried_item_changed</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">carried_item</td>
<td style="border-style:solid; border-width:1; padding:9px">ItemStack JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The item that is now in the entities hands</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">entity</td>
<td style="border-style:solid; border-width:1; padding:9px">Entity JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The entity that changed what they were carrying</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">hand</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px">Defines which hand the item was equipped to. Either main or offhand.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">previous_carried_item</td>
<td style="border-style:solid; border-width:1; padding:9px">ItemStack JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The item that was previously in the entities hands</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3><p id="minecraft:entity_created">minecraft:entity_created</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">entity</td>
<td style="border-style:solid; border-width:1; padding:9px">Entity JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The entity that was just created</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3><p id="minecraft:entity_definition_event">minecraft:entity_definition_event</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">entity</td>
<td style="border-style:solid; border-width:1; padding:9px">Entity JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The entity that was affected</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">event</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px">The event that was triggered</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3><p id="minecraft:entity_death">minecraft:entity_death</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">block_position</td>
<td style="border-style:solid; border-width:1; padding:9px">JavaScript Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The position of the block that killed the entity</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">cause</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px">The cause of the entity's death</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">entity</td>
<td style="border-style:solid; border-width:1; padding:9px">Entity JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The entity that died</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">killer</td>
<td style="border-style:solid; border-width:1; padding:9px">Entity JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The entity that killed the entity</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">projectile_type</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px">The type of the projectile that killed the entity</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3><p id="minecraft:entity_dropped_item">minecraft:entity_dropped_item</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">entity</td>
<td style="border-style:solid; border-width:1; padding:9px">Entity JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The entity who dropped the item</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">item_stack</td>
<td style="border-style:solid; border-width:1; padding:9px">ItemStack JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The item that was dropped</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3><p id="minecraft:entity_equipped_armor">minecraft:entity_equipped_armor</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">entity</td>
<td style="border-style:solid; border-width:1; padding:9px">Entity JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The entity who is equipping the armor</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">item_stack</td>
<td style="border-style:solid; border-width:1; padding:9px">ItemStack JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The armor that is being equipped</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">slot</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px">Defines which slot the item was equipped to.</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3><p id="minecraft:entity_hurt">minecraft:entity_hurt</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">absorbed_damage</td>
<td style="border-style:solid; border-width:1; padding:9px">Integer</td>
<td style="border-style:solid; border-width:1; padding:9px">The amount the damage was reduced by by the entity's absorption effect</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">attacker</td>
<td style="border-style:solid; border-width:1; padding:9px">Entity JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px">Present only when damaged by an entity or projectile. The entity that attacked and caused the damage</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">block_position</td>
<td style="border-style:solid; border-width:1; padding:9px">Vector [a, b, c]</td>
<td style="border-style:solid; border-width:1; padding:9px">Present only when damaged by a block. This is the position of the block that hit the entity</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">cause</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px">The way the entity took damage. Refer to the Damage Source documentation for a complete list of sources</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">damage</td>
<td style="border-style:solid; border-width:1; padding:9px">Integer</td>
<td style="border-style:solid; border-width:1; padding:9px">The amount of damage the entity took after immunity and armor are taken into account</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">entity</td>
<td style="border-style:solid; border-width:1; padding:9px">Entity JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The entity that took damage</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">projectile_type</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px">Present only when damaged by a projectile. This is the identifier of the projectile that hit the entity</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3><p id="minecraft:entity_move">minecraft:entity_move</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">entity</td>
<td style="border-style:solid; border-width:1; padding:9px">Entity JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The entity that moved</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3><p id="minecraft:entity_sneak">minecraft:entity_sneak</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">entity</td>
<td style="border-style:solid; border-width:1; padding:9px">Entity JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The entity that changed their sneaking state</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">sneaking</td>
<td style="border-style:solid; border-width:1; padding:9px">Boolean</td>
<td style="border-style:solid; border-width:1; padding:9px">If true, the entity just started sneaking. If false, the entity just stopped sneaking</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3><p id="minecraft:entity_start_riding">minecraft:entity_start_riding</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">entity</td>
<td style="border-style:solid; border-width:1; padding:9px">Entity JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The rider</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">ride</td>
<td style="border-style:solid; border-width:1; padding:9px">Entity JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The entity being ridden</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3><p id="minecraft:entity_stop_riding">minecraft:entity_stop_riding</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">entity</td>
<td style="border-style:solid; border-width:1; padding:9px">Entity JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The entity that was riding another entity</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">entity_is_being_destroyed</td>
<td style="border-style:solid; border-width:1; padding:9px">Boolean</td>
<td style="border-style:solid; border-width:1; padding:9px">If true, the rider stopped riding because they are now dead</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">exit_from_rider</td>
<td style="border-style:solid; border-width:1; padding:9px">Boolean</td>
<td style="border-style:solid; border-width:1; padding:9px">If true, the rider stopped riding by their own decision</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">switching_rides</td>
<td style="border-style:solid; border-width:1; padding:9px">Boolean</td>
<td style="border-style:solid; border-width:1; padding:9px">If true, the rider stopped riding because they are now riding a different entity</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3><p id="minecraft:entity_tick">minecraft:entity_tick</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">entity</td>
<td style="border-style:solid; border-width:1; padding:9px">Entity JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The entity that was ticked</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3><p id="minecraft:entity_use_item">minecraft:entity_use_item</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">entity</td>
<td style="border-style:solid; border-width:1; padding:9px">Entity JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The entity who is using the item</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">item_stack</td>
<td style="border-style:solid; border-width:1; padding:9px">ItemStack JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The item that is being used</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">use_method</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px">The way the entity used the item</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3><p id="minecraft:block_destruction_started">minecraft:block_destruction_started</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">block_position</td>
<td style="border-style:solid; border-width:1; padding:9px">JavaScript Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The position of the block that is being destroyed</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">player</td>
<td style="border-style:solid; border-width:1; padding:9px">Entity JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The player that started destoying the block</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3><p id="minecraft:block_destruction_stopped">minecraft:block_destruction_stopped</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">block_position</td>
<td style="border-style:solid; border-width:1; padding:9px">JavaScript Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The position of the block that was being destroyed</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">destruction_progress</td>
<td style="border-style:solid; border-width:1; padding:9px">Decimal</td>
<td style="border-style:solid; border-width:1; padding:9px">How far along the destruction was before it was stopped (0 - 1 range)</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">player</td>
<td style="border-style:solid; border-width:1; padding:9px">Entity JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The player that stopped destoying the block</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3><p id="minecraft:block_exploded">minecraft:block_exploded</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">block_identifier</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px">The identifier of the block that was destroyed</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">block_position</td>
<td style="border-style:solid; border-width:1; padding:9px">JavaScript Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The position of the block that was destroyed by the explosion</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">cause</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px">The cause of the block's destruction</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">entity</td>
<td style="border-style:solid; border-width:1; padding:9px">Entity JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The entity that exploded</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3><p id="minecraft:block_interacted_with">minecraft:block_interacted_with</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">block_position</td>
<td style="border-style:solid; border-width:1; padding:9px">JavaScript Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The position of the block that is being interacted with</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">player</td>
<td style="border-style:solid; border-width:1; padding:9px">Entity JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The player that interacted with the block</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3><p id="minecraft:piston_moved_block">minecraft:piston_moved_block</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">block_position</td>
<td style="border-style:solid; border-width:1; padding:9px">JavaScript Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The position of the block that was moved</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">piston_action</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px">The action the piston took, "extended" or "retracted"</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">piston_position</td>
<td style="border-style:solid; border-width:1; padding:9px">JavaScript Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The position of the piston that moved the block</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3><p id="minecraft:player_destroyed_block">minecraft:player_destroyed_block</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">block_identifier</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px">The identifier of the block that was destroyed</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">block_position</td>
<td style="border-style:solid; border-width:1; padding:9px">JavaScript Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The position of the block that was destroyed</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">player</td>
<td style="border-style:solid; border-width:1; padding:9px">Entity JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The player that destroyed the block</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3><p id="minecraft:player_placed_block">minecraft:player_placed_block</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">block_position</td>
<td style="border-style:solid; border-width:1; padding:9px">JavaScript Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The position of the block that was placed</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">player</td>
<td style="border-style:solid; border-width:1; padding:9px">Entity JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The player that placed the block</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3><p id="minecraft:play_sound">minecraft:play_sound</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Default Value</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">pitch</td>
<td style="border-style:solid; border-width:1; padding:9px">Decimal</td>
<td style="border-style:solid; border-width:1; padding:9px">1.0</td>
<td style="border-style:solid; border-width:1; padding:9px">The pitch of the sound effect. A value of 1.0 will play the sound effect with regular pitch</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">position</td>
<td style="border-style:solid; border-width:1; padding:9px">Vector [a, b, c]</td>
<td style="border-style:solid; border-width:1; padding:9px">[0, 0, 0]</td>
<td style="border-style:solid; border-width:1; padding:9px">The position in the world we want to play the sound at</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">sound</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px"></td>
<td style="border-style:solid; border-width:1; padding:9px">The identifier of the sound you want to play. Only sounds defined in the applied resource packs can be played</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">volume</td>
<td style="border-style:solid; border-width:1; padding:9px">Decimal</td>
<td style="border-style:solid; border-width:1; padding:9px">1.0</td>
<td style="border-style:solid; border-width:1; padding:9px">The volume of the sound effect. A value of 1.0 will play the sound effect at the volume it was recorded at</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3><p id="minecraft:projectile_hit">minecraft:projectile_hit</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">entity</td>
<td style="border-style:solid; border-width:1; padding:9px">Entity JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The entity that was hit by the projectile, if any</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">owner</td>
<td style="border-style:solid; border-width:1; padding:9px">Entity JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The entity that fired the projectile</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">position</td>
<td style="border-style:solid; border-width:1; padding:9px">Vector [a, b, c]</td>
<td style="border-style:solid; border-width:1; padding:9px">The position of the collision</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">projectile</td>
<td style="border-style:solid; border-width:1; padding:9px">Entity JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px">The projectile in question</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3><p id="minecraft:weather_changed">minecraft:weather_changed</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">dimension</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px">The name of the dimension where the weather change happened</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">lightning</td>
<td style="border-style:solid; border-width:1; padding:9px">Boolean</td>
<td style="border-style:solid; border-width:1; padding:9px">Tells if the new weather has lightning</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">raining</td>
<td style="border-style:solid; border-width:1; padding:9px">Boolean</td>
<td style="border-style:solid; border-width:1; padding:9px">Tells if the new weather has rain</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<br><br>

<h2><p id="Trigger-able Events">Trigger-able Events</p></h2>

<h3></h3>

<h3><p id="minecraft:entity_definition_event">minecraft:entity_definition_event</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Default Value</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">entity</td>
<td style="border-style:solid; border-width:1; padding:9px">Entity JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px"></td>
<td style="border-style:solid; border-width:1; padding:9px">The entity object you want to attach the effect to</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">event</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px"></td>
<td style="border-style:solid; border-width:1; padding:9px">The identifier of the event to trigger on that entity. Both built-in (minecraft:) and custom events are supported</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3><p id="minecraft:display_chat_event">minecraft:display_chat_event</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Default Value</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">message</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px"></td>
<td style="border-style:solid; border-width:1; padding:9px">The chat message that will be displayed</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3><p id="minecraft:execute_command">minecraft:execute_command</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Default Value</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">command</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px"></td>
<td style="border-style:solid; border-width:1; padding:9px">The command that will be run</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3><p id="minecraft:play_sound">minecraft:play_sound</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Default Value</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">pitch</td>
<td style="border-style:solid; border-width:1; padding:9px">Decimal</td>
<td style="border-style:solid; border-width:1; padding:9px">1.0</td>
<td style="border-style:solid; border-width:1; padding:9px">The pitch of the sound effect. A value of 1.0 will play the sound effect with regular pitch</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">position</td>
<td style="border-style:solid; border-width:1; padding:9px">Vector [a, b, c]</td>
<td style="border-style:solid; border-width:1; padding:9px">[0, 0, 0]</td>
<td style="border-style:solid; border-width:1; padding:9px">The position in the world we want to play the sound at</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">sound</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px"></td>
<td style="border-style:solid; border-width:1; padding:9px">The identifier of the sound you want to play. Only sounds defined in the applied resource packs can be played</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">volume</td>
<td style="border-style:solid; border-width:1; padding:9px">Decimal</td>
<td style="border-style:solid; border-width:1; padding:9px">1.0</td>
<td style="border-style:solid; border-width:1; padding:9px">The volume of the sound effect. A value of 1.0 will play the sound effect at the volume it was recorded at</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3><p id="minecraft:spawn_particle_attached_entity">minecraft:spawn_particle_attached_entity</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Default Value</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">effect</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px"></td>
<td style="border-style:solid; border-width:1; padding:9px">The identifier of the particle effect you want to attach to the entity. This is the same identifier you gave the effect in its JSON file</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">entity</td>
<td style="border-style:solid; border-width:1; padding:9px">Entity JS API Object</td>
<td style="border-style:solid; border-width:1; padding:9px"></td>
<td style="border-style:solid; border-width:1; padding:9px">The entity object you want to attach the effect to</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">offset</td>
<td style="border-style:solid; border-width:1; padding:9px">Vector [a, b, c]</td>
<td style="border-style:solid; border-width:1; padding:9px">[0, 0, 0]</td>
<td style="border-style:solid; border-width:1; padding:9px">The offset from the entity's "center" where you want to spawn the effect</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3><p id="minecraft:spawn_particle_in_world">minecraft:spawn_particle_in_world</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Default Value</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">dimension</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px">overworld</td>
<td style="border-style:solid; border-width:1; padding:9px">The dimension in which you want to spawn the effect. Can be "overworld", "nether", or "the end"</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">effect</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px"></td>
<td style="border-style:solid; border-width:1; padding:9px">The identifier of the particle effect you want to attach to spawn. This is the same name you gave the effect in its JSON file</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">position</td>
<td style="border-style:solid; border-width:1; padding:9px">Vector [a, b, c]</td>
<td style="border-style:solid; border-width:1; padding:9px">[0, 0, 0]</td>
<td style="border-style:solid; border-width:1; padding:9px">The position in the world where you want to spawn the effect</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h3><p id="minecraft:script_logger_config">minecraft:script_logger_config</p></h3>

<h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Default Value</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">log_errors</td>
<td style="border-style:solid; border-width:1; padding:9px">Boolean</td>
<td style="border-style:solid; border-width:1; padding:9px">false</td>
<td style="border-style:solid; border-width:1; padding:9px">Set to true to log any scripting errors that occur on the server</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">log_information</td>
<td style="border-style:solid; border-width:1; padding:9px">Boolean</td>
<td style="border-style:solid; border-width:1; padding:9px">false</td>
<td style="border-style:solid; border-width:1; padding:9px">Set to true to log any general scripting information that occurs on the server. This includes any logging done with server.log()</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">log_warnings</td>
<td style="border-style:solid; border-width:1; padding:9px">Boolean</td>
<td style="border-style:solid; border-width:1; padding:9px">false</td>
<td style="border-style:solid; border-width:1; padding:9px">Set to true to log any scripting warnings that occur on the server</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<br><br>

<br><br>

<br><br>

<h1><p id="Scripting System">Scripting System</p></h1>

The Minecraft Script Engine uses the JavaScript language.</br>You can write JavaScript scripts and bundle them with Behavior Packs to listen and respond to game events, get and modify data in components that entities have, and affect different parts of the game.</br><h1><p id="Demos">Demos</p></h1>

<h2></h2>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:3;">
<tr> <th style="border-style:solid; border-width:3;">Demo</th> <th style="border-style:solid; border-width:3;">Last Updated</th> <th style="border-style:solid; border-width:3;">Download Link</th> </tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">Mob Arena</td>
<td style="border-style:solid; border-width:3; padding:7px">10/24/2018</td>
<td style="border-style:solid; border-width:3; padding:7px">https://aka.ms/minecraftscripting_mobarena</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">Turn-Based RPG</td>
<td style="border-style:solid; border-width:3; padding:7px">10/24/2018</td>
<td style="border-style:solid; border-width:3; padding:7px">https://aka.ms/minecraftscripting_turnbased</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h1><p id="Known Issues">Known Issues</p></h1>

<h2></h2>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:3;">
<tr> <th style="border-style:solid; border-width:3;">Issue</th> <th style="border-style:solid; border-width:3;">Workaround</th> </tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">Scripts are not loaded properly from archived packs</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">Custom UI doesn't work in VR or MR mode</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">Custom UI doesn't retain state upon suspend and resume</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">Exiting a world without scripts and entering one that has scripts might cause the wrong world to load</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">Calling removeEntity on a dying entity might cause the game to crash</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h1><p id="Breaking Changes">Breaking Changes</p></h1>

<h2></h2>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:3;">
<tr> <th style="border-style:solid; border-width:3;">Category</th> <th style="border-style:solid; border-width:3;">Change</th> </tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">UI</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">Components</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">Events</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">Events</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">Events</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">Events</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h1><p id="Pre-Requisites">Pre-Requisites</p></h1>

</br>NOTE: Scripts are only supported on Windows 10 PCs at the moment. If you try to open a world with scripts on a device that doesn't support scripts, you will see an error message letting you know you can't enter the world.</br><h2></h2>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:3;">
<tr> <th style="border-style:solid; border-width:3;">Software</th> <th style="border-style:solid; border-width:3;">Minimum</th> <th style="border-style:solid; border-width:3;">Recommended</th> </tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">Code Editor</td>
<td style="border-style:solid; border-width:3; padding:7px">Visual Studio Code or any plain-text editor</td>
<td style="border-style:solid; border-width:3; padding:7px">Visual Studio Community 2017 with the following components installed: 'JavaScript diagnostics', 'JavaScript and TypeScript language support', 'Just-In-Time debugger'</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">Debugger</td>
<td style="border-style:solid; border-width:3; padding:7px">N/A</td>
<td style="border-style:solid; border-width:3; padding:7px">Visual Studio Community 2017</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">Minecraft</td>
<td style="border-style:solid; border-width:3; padding:7px">Minecraft  on your Windows 10 device</td>
<td style="border-style:solid; border-width:3; padding:7px">Minecraft  on your Windows 10 device</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">Other</td>
<td style="border-style:solid; border-width:3; padding:7px">Vanilla Behavior Pack  available from https://aka.ms/behaviorpacktemplate</td>
<td style="border-style:solid; border-width:3; padding:7px">Vanilla Behavior Pack  available from https://aka.ms/behaviorpacktemplate</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">Storage</td>
<td style="border-style:solid; border-width:3; padding:7px">1.0 GB of free space for text editor, game, and scripts</td>
<td style="border-style:solid; border-width:3; padding:7px">3.0 GB of free space for Visual Studio, game, and scripts</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h1><p id="Getting Started">Getting Started</p></h1>

Once you have downloaded the Behavior Pack, unzip it to a folder. Inside the Behavior Pack you will find the scripts folder which contains all the scripting files you want to run.</br>In the scripts folder you will find two folders: one for client scripts and one for server scripts.</br>-Server Scripts: These scripts run on the server side of the game. This includes spawning new entities, adding components, or modifying components on an entity.</br>-Client Scripts: These scripts run on each individual player's side of the game. This is a good place to respond to events and manage anything specific to the player.</br>Once you have chosen whether you are making a client or server script, simply add a new blank text file with .js extension to the appropriate folder, and open it in your preferred code editor. Then code away! You can have as many or as few JavaScript files as you want here (the name of the files doesn't matter) and they will all be run independently of each other!</br></br> NOTE: For scripts to be run by the game, you need to enable Experimental Gameplay on the world where you will run scripts on. This will be necessary while scripting is still in beta.</br>When entering a world that has client scripts in it, you will be prompted to accept that you wish to run scripts on your device (this will show up both for local worlds as well as multiplayer worlds).</br>Additionally, if your pack contains client scripts, you need to include a client_data module in the pack's manifest. This tells the game anything in the scripts/client folder needs to be sent over to the clients. Please refer to the Add-on Documentation page for more information on the pack's manifest contents.</br><h2>Folder Structure</h2>
Example of manifest module needed for client scripts<br / ><textarea readonly="true" cols="60" rows="9">

        {
            "description": "Example client scripts module",
            "type": "client_data",
            "uuid": "c05a992e-482a-455f-898c-58bbb4975e47",
            "version": [0, 0, 1]
        }

</textarea> </br>
vanilla_behavior_pack<br / ><textarea readonly="true" cols="22" rows="8">
|-scripts
|--client
|---myClientScript.js
|--server
|---myServerScript.js
|-manifest.json
|-pack_icon.png
</textarea> </br>
<a href="#Index">Back to top</a><br><br>

<h1><p id="Structure of a Script">Structure of a Script</p></h1>

These are, in a way, the required parts of a script but they are by no means the only parts you can have. You can create additional methods as needed - just make sure they are called from somewhere in one of the methods below!</br><h2></h2>

<h2><p id="1. System Registration">1. System Registration</p></h2>

<h3></h3>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">majorVersion</td>
<td style="border-style:solid; border-width:2; padding:8px">Integer</td>
<td style="border-style:solid; border-width:2; padding:8px">This is the major version of the Minecraft Script Engine your script was designed to work with</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">minorVersion</td>
<td style="border-style:solid; border-width:2; padding:8px">Integer</td>
<td style="border-style:solid; border-width:2; padding:8px">This is the revision of the Minecraft Script Engine your script was designed to work with</br></td>
</tr>
</table>
<h3>Code Examples:</h3>
Client System<br / ><textarea readonly="true" cols="54" rows="2">
let sampleClientSystem = client.registerSystem(0, 0);
</textarea> </br>
Server System<br / ><textarea readonly="true" cols="54" rows="2">
let sampleServerSystem = server.registerSystem(0, 0);
</textarea> </br>
<a href="#Index">Back to top</a><br><br>

<h2><p id="2. System Initialization">2. System Initialization</p></h2>

You can use this to set up the environment for your script: register custom components and events, sign up event listeners, etc. This will run BEFORE the world is ready and the player has been added to it. This function should be used to initialize variables and setup event listeners. 					You shouldn't try to spawn or interact with any entities at this point! You should also avoid interaction with UI elements or sending messages to the chat window since this is called before the player is ready.</br><h3>Code Example:</h3>
<br / ><textarea readonly="true" cols="82" rows="4">
sampleSystem.initialize = function() {
  //register event data, register components, register queries, listen for events
};
</textarea> </br>
<a href="#Index">Back to top</a><br><br>

<h2><p id="3. System Update">3. System Update</p></h2>

<h3>Code Example:</h3>
<br / ><textarea readonly="true" cols="35" rows="4">
sampleSystem.update = function() {
  //Update all the things
};
</textarea> </br>
<a href="#Index">Back to top</a><br><br>

<h2><p id="4. System Shutdown">4. System Shutdown</p></h2>

<h3>Code Example:</h3>
<br / ><textarea readonly="true" cols="37" rows="4">
sampleSystem.shutdown = function() {
  //Cleanup script only things
};
</textarea> </br>
<a href="#Index">Back to top</a><br><br>

<br><br>

<h1><p id="Debugging">Debugging</p></h1>

There are two ways to tell what happened when something goes wrong with a script: in-game and advanced, which we will describe below. You only need the game and your script to debug in-game, but you will need a Windows 10 PC and Visual Studio installed for the advanced debugging.</br><h2></h2>

<h2><p id="In-Game">In-Game</p></h2>

We strongly encourage you to build further debug messages and tools into your scripts while working on them. This will help you discern when something isn't working quite right. Reach out on the official Discord channel if you need additional help: https://discord.gg/Minecraft</br><a href="#Index">Back to top</a><br><br>

<h2><p id="Real-Time (Advanced)">Real-Time (Advanced)</p></h2>

If you installed Visual Studio with the components mentioned in the "Recommended" section of this document you will have installed and enabled the Just-In-Time Debugger. This tool will pop-up a message from Visual Studio whenever an exception occurs in your script and allow you to open Visual Studio on the line of your script that broke.</br></br>Additionally, you can connect to the Script Engine manually and debug your code. You can use remote debugging to connect and debug Minecraft running on another device. Please refer to the Visual Studio Debugger documentation above for instructions on how to use remote debugging.</br>First you need to start up Visual Studio. If this is the first time you have launched Visual Studio after installation, we suggest setting up your environment for JavaScript development and logging in to your Microsoft account when prompted. This will set up the Visual Studio interface with the most important tools you will need.</br>Once you have Visual Studio open you should launch Minecraft. Then create a new world with Experimental Gameplay enabled and apply the Behavior Pack containing your scripts.</br>After creating the world go back to Visual Studio and click on the Debug menu. Then click on "Attach to Process". In the window that opens there will be a search box titled Filter Process. Click on it and type Minecraft.</br>Once the list is narrowed down to only the instance of Minecraft running, you can verify that the Script Engine is running by looking at the Type column. This will say Script and either x86 or x64.</br></br>Select the process and click on Attach to attach the debugger to the game. Now you will be able to press the Pause button to pause the Script Engine when the next line of script code runs. This allows you to inspect the values of variables in your script and break into Visual Studio if an error occurs in your code.</br>WARNING: When you hit a breakpoint to step through code with a debugger, it is possible for a client to time out and disconnect or for the server to disconnect all players.</br><a href="#Index">Back to top</a><br><br>

<br><br>

<br><br>

<h1><p id="User-Defined Components">User-Defined Components</p></h1>

User-Defined components are a special kind of component that can be defined in script and no built-in game system acts on it.</br>The component needs to be registered with the Script Engine by giving it a name and a set of fields in the format name:value. Once applied, the component behaves like any of the built-in components: you can get it from an entity, modify its values, and apply the changes.</br>Currently User-Defined components are the only components that can be dynamically added and removed from an entity using scripts. They don't need to be previously defined in an entity's JSON file. In the current version these components will NOT be saved out or loaded back in: they only exist while the entity is there and need to be added back when reloading the level.</br><h2>Code Example:</h2>
Component Registration<br / ><textarea readonly="true" cols="125" rows="2">
this.registerComponent("myNamespace:myComponent", { myString: "TamerJeison", myInt: 42, myFloat: 1.0, myArray: [1, 2, 3] });
</textarea> </br>
<a href="#Index">Back to top</a><br><br>

</v-html>
</div>
</template>

<style scoped>
textarea{
  color: white;
}

::-webkit-scrollbar {
  width: 10px;
}

::-webkit-scrollbar-thumb:hover {
  background: white;
}

::-webkit-scrollbar-track {
  background: grey;
}
</style>