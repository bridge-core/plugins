<template>
<div style="overflow: scroll">
<v-html>
<h1>BLOCKS DOCUMENTATION </br>Version: 1.17.10.4</h1>
<h2><p id="Index">Index</p></h2>
<table border="1">
<tr> <th><a href="#Blocks">Blocks</a></th> </tr>
<tr> <td> <a href="#Block Components"> Block Components</a> </tr> </td>
<tr> <td> <a href="#Block Definition Properties"> Block Definition Properties</a> </tr> </td>
<tr> <td> <a href="#Block Description Properties"> Block Description Properties</a> </tr> </td>
<tr> <td> <a href="#Block Event Responses"> Block Event Responses</a> </tr> </td>
<tr> <td> <a href="#Block Trigger Components"> Block Trigger Components</a> </tr> </td>
</table>
<a href="#Index">Back to top</a>
<h1><p id="Blocks">Blocks</p></h1>

<h1><p id="Block Components">Block Components</p></h1>

<h2></h2>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:3;">
<tr> <th style="border-style:solid; border-width:3;">Name</th> <th style="border-style:solid; border-width:3;">Type</th> <th style="border-style:solid; border-width:3;">Default Value</th> <th style="border-style:solid; border-width:3;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">minecraft:block_light_absorption</td>
<td style="border-style:solid; border-width:3; padding:7px">Integer</td>
<td style="border-style:solid; border-width:3; padding:7px">0</td>
<td style="border-style:solid; border-width:3; padding:7px">The amount of light this block will absorb.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">minecraft:block_light_emission</td>
<td style="border-style:solid; border-width:3; padding:7px">Decimal</td>
<td style="border-style:solid; border-width:3; padding:7px">0.0</td>
<td style="border-style:solid; border-width:3; padding:7px">The amount of light this block will emit in a range [0.0, 1.0].</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">minecraft:breakonpush</td>
<td style="border-style:solid; border-width:3; padding:7px">Boolean</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">When pushed by a piston the block breaks</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">minecraft:breathability</td>
<td style="border-style:solid; border-width:3; padding:7px">Enumerator</td>
<td style="border-style:solid; border-width:3; padding:7px">solid</td>
<td style="border-style:solid; border-width:3; padding:7px">Property describing the breathability of this block and whether it is treated as a solid or as air.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">minecraft:destroy_time</td>
<td style="border-style:solid; border-width:3; padding:7px">Decimal</td>
<td style="border-style:solid; border-width:3; padding:7px">0.0</td>
<td style="border-style:solid; border-width:3; padding:7px">Sets the destroy time property for the block. Greater numbers result in greater mining times.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">minecraft:display_name</td>
<td style="border-style:solid; border-width:3; padding:7px">String</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Specifies the display name id for the block.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">minecraft:entity_collision</td>
<td style="border-style:solid; border-width:3; padding:7px">Boolean</td>
<td style="border-style:solid; border-width:3; padding:7px">false</td>
<td style="border-style:solid; border-width:3; padding:7px">Can only be set to false, it disables the collision of the block with entities</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">origin</td>
<td style="border-style:solid; border-width:2; padding:8px">Array</td>
<td style="border-style:solid; border-width:2; padding:8px">[-8.0, 0.0, -8.0]</td>
<td style="border-style:solid; border-width:2; padding:8px">Minimal position Bounds of the collision box</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">size</td>
<td style="border-style:solid; border-width:2; padding:8px">Array</td>
<td style="border-style:solid; border-width:2; padding:8px">[16.0, 16.0, 16.0]</td>
<td style="border-style:solid; border-width:2; padding:8px">Size of each side of the box of the component</br></td>
</tr>
</table>
</td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">minecraft:explosion_resistance</td>
<td style="border-style:solid; border-width:3; padding:7px">Decimal</td>
<td style="border-style:solid; border-width:3; padding:7px">0.0</td>
<td style="border-style:solid; border-width:3; padding:7px">Sets the explosion resistance for this block.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">minecraft:flammable</td>
<td style="border-style:solid; border-width:3; padding:7px">JSON Object</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Describes the flammable properties for this block.</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">burn_odds</td>
<td style="border-style:solid; border-width:2; padding:8px">Integer</td>
<td style="border-style:solid; border-width:2; padding:8px">0</td>
<td style="border-style:solid; border-width:2; padding:8px">How likely the block will be destroyed by flames when on fire.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">flame_odds</td>
<td style="border-style:solid; border-width:2; padding:8px">Integer</td>
<td style="border-style:solid; border-width:2; padding:8px">0</td>
<td style="border-style:solid; border-width:2; padding:8px">How likely the block will catch flame when next to a fire.</br></td>
</tr>
</table>
</td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">minecraft:friction</td>
<td style="border-style:solid; border-width:3; padding:7px">Decimal</td>
<td style="border-style:solid; border-width:3; padding:7px">0.1</td>
<td style="border-style:solid; border-width:3; padding:7px">Property describing the friction for this block. Friction effects an entities movements when it walks on the block.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">minecraft:geometry</td>
<td style="border-style:solid; border-width:3; padding:7px">String</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">The geometry definition name to use.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">minecraft:immovable</td>
<td style="border-style:solid; border-width:3; padding:7px">Boolean</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">An Immovable block cannot be pushed by pistons</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">minecraft:map_color</td>
<td style="border-style:solid; border-width:3; padding:7px">String</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">A color represented as a hex value. This will be the color rendered to a map.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">minecraft:material_instances</td>
<td style="border-style:solid; border-width:3; padding:7px">JSON Object</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Maps face or material_instance names in a geometry file to an actual material instance. Material instance can either be a full material instance or a name to another already defined instance</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">minecraft:onlypistonpush</td>
<td style="border-style:solid; border-width:3; padding:7px">Boolean</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Blocks with those components won't stick to stickyPistons</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">minecraft:pick_collision</td>
<td style="border-style:solid; border-width:3; padding:7px">Boolean</td>
<td style="border-style:solid; border-width:3; padding:7px">false</td>
<td style="border-style:solid; border-width:3; padding:7px">Can only be set to false, it disables the collision of the block with entities</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">origin</td>
<td style="border-style:solid; border-width:2; padding:8px">Array</td>
<td style="border-style:solid; border-width:2; padding:8px">[-8.0, 0.0, -8.0]</td>
<td style="border-style:solid; border-width:2; padding:8px">Minimal position Bounds of the collision box</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">size</td>
<td style="border-style:solid; border-width:2; padding:8px">Array</td>
<td style="border-style:solid; border-width:2; padding:8px">[16.0, 16.0, 16.0]</td>
<td style="border-style:solid; border-width:2; padding:8px">Size of each side of the box of the component</br></td>
</tr>
</table>
</td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">minecraft:placement_filter</td>
<td style="border-style:solid; border-width:3; padding:7px">JSON Object</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Sets rules for under what conditions the block can be placed/survive</br><h3><p id="conditions">conditions</p></h3>

List of conditions where the block can be placed/survive</br><h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Default Value</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">allowed_faces</td>
<td style="border-style:solid; border-width:1; padding:9px">Array</td>
<td style="border-style:solid; border-width:1; padding:9px"></td>
<td style="border-style:solid; border-width:1; padding:9px">List of any of the following strings: up, down, north, south, east, west, side, all</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">block_filter</td>
<td style="border-style:solid; border-width:1; padding:9px">Array</td>
<td style="border-style:solid; border-width:1; padding:9px"></td>
<td style="border-style:solid; border-width:1; padding:9px">List of blocks (can use tags to specify them) that this block can be placed against in the allowed_faces direction</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

</td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">minecraft:preventsjumping</td>
<td style="border-style:solid; border-width:3; padding:7px">Boolean</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">this component makes it so actors can't jump when walking on this block</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">minecraft:random_ticking</td>
<td style="border-style:solid; border-width:3; padding:7px">JSON Object</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Describes the component that will trigger an even at a regular interval between two values</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">Trigger</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">on_tick</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Default Value</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">condition</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px">1</td>
<td style="border-style:solid; border-width:1; padding:9px">The condition of event to be executed on the block.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">event</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px">set_block_property</td>
<td style="border-style:solid; border-width:1; padding:9px">The type of event executed on the block.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">range</td>
<td style="border-style:solid; border-width:1; padding:9px">Array</td>
<td style="border-style:solid; border-width:1; padding:9px">[10, 10]</td>
<td style="border-style:solid; border-width:1; padding:9px">The Range between which the component will trigger his event.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">target</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px">self</td>
<td style="border-style:solid; border-width:1; padding:9px">The target of event executed on the block.</br></td>
</tr>
</table>
</td>
</tr>
</table>
</td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">minecraft:rotation</td>
<td style="border-style:solid; border-width:3; padding:7px">Vector [a, b, c]</td>
<td style="border-style:solid; border-width:3; padding:7px">rotation[0, 0, 0]</td>
<td style="border-style:solid; border-width:3; padding:7px">This is the block's rotation around the center of the cube in degrees. The rotation order is x-y-z.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">minecraft:ticking</td>
<td style="border-style:solid; border-width:3; padding:7px">JSON Object</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Describes the component that will trigger an even at a regular interval between two values</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">Trigger</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">on_tick</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Default Value</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">condition</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px">1</td>
<td style="border-style:solid; border-width:1; padding:9px">The condition of event to be executed on the block.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">event</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px">set_block_property</td>
<td style="border-style:solid; border-width:1; padding:9px">The type of event executed on the block.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">range</td>
<td style="border-style:solid; border-width:1; padding:9px">Array</td>
<td style="border-style:solid; border-width:1; padding:9px">[10, 10]</td>
<td style="border-style:solid; border-width:1; padding:9px">The Range between which the component will trigger his event.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">target</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px">self</td>
<td style="border-style:solid; border-width:1; padding:9px">The target of event executed on the block.</br></td>
</tr>
</table>
</td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">looping</td>
<td style="border-style:solid; border-width:2; padding:8px">Boolean</td>
<td style="border-style:solid; border-width:2; padding:8px">true</td>
<td style="border-style:solid; border-width:2; padding:8px">Does the event loop</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">range</td>
<td style="border-style:solid; border-width:2; padding:8px">Array</td>
<td style="border-style:solid; border-width:2; padding:8px">[10, 10]</td>
<td style="border-style:solid; border-width:2; padding:8px">The Range between which the component will trigger his event.</br></td>
</tr>
</table>
</td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">minecraft:unit_cube</td>
<td style="border-style:solid; border-width:3; padding:7px">String</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Specifies that a unit cube is to be used with tessellation.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">minecraft:unwalkable</td>
<td style="border-style:solid; border-width:3; padding:7px">Boolean</td>
<td style="border-style:solid; border-width:3; padding:7px">false</td>
<td style="border-style:solid; border-width:3; padding:7px">Sets the block as unwalkable. Mobs would not attempt to path over top of it when the value is set to true.</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h1><p id="Block Definition Properties">Block Definition Properties</p></h1>

These properties are part of the Block Definition. This helps the system determine how to parse and initialize this block.</br><h2></h2>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:3;">
<tr> <th style="border-style:solid; border-width:3;">Name</th> <th style="border-style:solid; border-width:3;">Type</th> <th style="border-style:solid; border-width:3;">Default Value</th> <th style="border-style:solid; border-width:3;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">format_version</td>
<td style="border-style:solid; border-width:3; padding:7px">String</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Specifies the version of the game this entity was made in. If the version is lower than the current version, any changes made to the entity in the vanilla version will be applied to it.</br></td>
</tr>
</table>
<h2>Code Example</h2>
Example<br / ><textarea readonly="true" cols="66" rows="20">
{
  "format_version": "1.16.0",
  "minecraft:block": {
    "description": {
      "identifier": "design:lavenderstone"
    },
    "components": {
      "minecraft:loot": "loot_tables/chests/simple_dungeon.json",
      "minecraft:destroy_time": 4.0,
      "minecraft:friction": 0.6,
      "minecraft:map_color": "#00ff00",
      "minecraft:flammable": {
        "flame_odds": 50,
        "burn_odds": 0
    },
      "minecraft:block_light_emission": 1.0
    }
  }
}
</textarea> </br>
<a href="#Index">Back to top</a><br><br>

<h1><p id="Block Description Properties">Block Description Properties</p></h1>

<h2></h2>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:3;">
<tr> <th style="border-style:solid; border-width:3;">Name</th> <th style="border-style:solid; border-width:3;">Type</th> <th style="border-style:solid; border-width:3;">Default Value</th> <th style="border-style:solid; border-width:3;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">identifier</td>
<td style="border-style:solid; border-width:3; padding:7px">String</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">The identifier for this block. The name must include a namespace and must not use the Minecraft namespace unless overriding a Vanilla block.</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h1><p id="Block Event Responses">Block Event Responses</p></h1>

Event responses for block trigger components.</br><h2></h2>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:3;">
<tr> <th style="border-style:solid; border-width:3;">Name</th> <th style="border-style:solid; border-width:3;">Type</th> <th style="border-style:solid; border-width:3;">Default Value</th> <th style="border-style:solid; border-width:3;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">add_mob_effect</td>
<td style="border-style:solid; border-width:3; padding:7px">JSON Object</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Apply mob effect to target.</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">amplifier</td>
<td style="border-style:solid; border-width:2; padding:8px">Integer</td>
<td style="border-style:solid; border-width:2; padding:8px">0</td>
<td style="border-style:solid; border-width:2; padding:8px">The amplifier for the mob effect.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">duration</td>
<td style="border-style:solid; border-width:2; padding:8px">Decimal</td>
<td style="border-style:solid; border-width:2; padding:8px">0.0</td>
<td style="border-style:solid; border-width:2; padding:8px">The duration of the mob effect.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">effect</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">The mob effect to apply.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">target</td>
<td style="border-style:solid; border-width:2; padding:8px">Minecraft Filter</td>
<td style="border-style:solid; border-width:2; padding:8px">self</td>
<td style="border-style:solid; border-width:2; padding:8px">The target context to execute against.</br></td>
</tr>
</table>
</td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">damage</td>
<td style="border-style:solid; border-width:3; padding:7px">JSON Object</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Deals damage to the target.</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">amount</td>
<td style="border-style:solid; border-width:2; padding:8px">Integer</td>
<td style="border-style:solid; border-width:2; padding:8px">0</td>
<td style="border-style:solid; border-width:2; padding:8px">The amount of damage to deal.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">target</td>
<td style="border-style:solid; border-width:2; padding:8px">Minecraft Filter</td>
<td style="border-style:solid; border-width:2; padding:8px">self</td>
<td style="border-style:solid; border-width:2; padding:8px">The target context to execute against.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">type</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">The type of damage to deal.</br></td>
</tr>
</table>
</td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">decrement_stack</td>
<td style="border-style:solid; border-width:3; padding:7px">JSON Object</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Decrement item stack.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">die</td>
<td style="border-style:solid; border-width:3; padding:7px">JSON Object</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Kill target. If target is self and this is run from a block then destroy the block.</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">target</td>
<td style="border-style:solid; border-width:2; padding:8px">Minecraft Filter</td>
<td style="border-style:solid; border-width:2; padding:8px">self</td>
<td style="border-style:solid; border-width:2; padding:8px">The target context to execute against.</br></td>
</tr>
</table>
</td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">play_effect</td>
<td style="border-style:solid; border-width:3; padding:7px">JSON Object</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Spawns a particle effect relative to target position.</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">data</td>
<td style="border-style:solid; border-width:2; padding:8px">Integer</td>
<td style="border-style:solid; border-width:2; padding:8px">0</td>
<td style="border-style:solid; border-width:2; padding:8px">Particle data value.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">effect</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">The name of the particle effect to create.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">target</td>
<td style="border-style:solid; border-width:2; padding:8px">Minecraft Filter</td>
<td style="border-style:solid; border-width:2; padding:8px">self</td>
<td style="border-style:solid; border-width:2; padding:8px">The target context to execute against.</br></td>
</tr>
</table>
</td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">play_sound</td>
<td style="border-style:solid; border-width:3; padding:7px">JSON Object</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Play a sound relative to target position.</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">sound</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">The name of the sound to play.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">target</td>
<td style="border-style:solid; border-width:2; padding:8px">Minecraft Filter</td>
<td style="border-style:solid; border-width:2; padding:8px">self</td>
<td style="border-style:solid; border-width:2; padding:8px">The target context to execute against.</br></td>
</tr>
</table>
</td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">remove_mob_effect</td>
<td style="border-style:solid; border-width:3; padding:7px">JSON Object</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Removes mob effect from target.</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">effect</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">The mob effect to remove. Use 'all' to remove all mob effects from target.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">target</td>
<td style="border-style:solid; border-width:2; padding:8px">Minecraft Filter</td>
<td style="border-style:solid; border-width:2; padding:8px">self</td>
<td style="border-style:solid; border-width:2; padding:8px">The target context to execute against.</br></td>
</tr>
</table>
</td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">run_command</td>
<td style="border-style:solid; border-width:3; padding:7px">JSON Object</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Triggers a slash command or a list of slash commands.</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">command</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">Slash command to run.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">command array</td>
<td style="border-style:solid; border-width:2; padding:8px">Array</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">List of slash commands to run.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">target</td>
<td style="border-style:solid; border-width:2; padding:8px">Minecraft Filter</td>
<td style="border-style:solid; border-width:2; padding:8px">self</td>
<td style="border-style:solid; border-width:2; padding:8px">The target context to execute against.</br></td>
</tr>
</table>
</td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">set_block</td>
<td style="border-style:solid; border-width:3; padding:7px">JSON Object</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Sets this block to another block type.</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">block_type</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">The type of block to set.</br></td>
</tr>
</table>
</td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">set_block_at_pos</td>
<td style="border-style:solid; border-width:3; padding:7px">JSON Object</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Sets a block relative to this block to another block type.</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">block_offset</td>
<td style="border-style:solid; border-width:2; padding:8px">Vector [a, b, c]</td>
<td style="border-style:solid; border-width:2; padding:8px">[0.0, 0.0, 0.0]</td>
<td style="border-style:solid; border-width:2; padding:8px">The offset from the block's center.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">block_type</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">The type of block to set.</br></td>
</tr>
</table>
</td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">set_block_property</td>
<td style="border-style:solid; border-width:3; padding:7px">JSON Object</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Sets a block property on this block.</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">property</td>
<td style="border-style:solid; border-width:2; padding:8px">MoLang</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">Block property to set on the block.</br></td>
</tr>
</table>
</td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">spawn_loot</td>
<td style="border-style:solid; border-width:3; padding:7px">JSON Object</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Spawn loot from block.</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">table</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">File path, relative to the Behavior Pack's path, to the loot table file.</br></td>
</tr>
</table>
</td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">swing</td>
<td style="border-style:solid; border-width:3; padding:7px">JSON Object</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Event causes the actor to swing.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">teleport</td>
<td style="border-style:solid; border-width:3; padding:7px">JSON Object</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Teleport target randomly around destination point.</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">avoid_water</td>
<td style="border-style:solid; border-width:2; padding:8px">Boolean</td>
<td style="border-style:solid; border-width:2; padding:8px">true</td>
<td style="border-style:solid; border-width:2; padding:8px">Determines if the teleport avoids putting the target in water.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">destination</td>
<td style="border-style:solid; border-width:2; padding:8px">Vector [a, b, c]</td>
<td style="border-style:solid; border-width:2; padding:8px">[0.0, 0.0, 0.0]</td>
<td style="border-style:solid; border-width:2; padding:8px">Origin destination of the teleport.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">land_on_block</td>
<td style="border-style:solid; border-width:2; padding:8px">Boolean</td>
<td style="border-style:solid; border-width:2; padding:8px">true</td>
<td style="border-style:solid; border-width:2; padding:8px">Determines if the teleport places the target on a block.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">max_range</td>
<td style="border-style:solid; border-width:2; padding:8px">Vector [a, b, c]</td>
<td style="border-style:solid; border-width:2; padding:8px">[8.0, 8.0, 8.0]</td>
<td style="border-style:solid; border-width:2; padding:8px">Max range the target can teleport relative to the origin destination.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">target</td>
<td style="border-style:solid; border-width:2; padding:8px">Minecraft Filter</td>
<td style="border-style:solid; border-width:2; padding:8px">self</td>
<td style="border-style:solid; border-width:2; padding:8px">The target context to execute against.</br></td>
</tr>
</table>
</td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">transform_item</td>
<td style="border-style:solid; border-width:3; padding:7px">JSON Object</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Transforms item into another item.</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">transform</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">Name of the item it should transform into</br></td>
</tr>
</table>
</td>
</tr>
</table>
<h2>Code Example</h2>
Event Response Example<br / ><textarea readonly="true" cols="61" rows="23">

    "minecraft:block": {
      "description": {
        "identifier": "test:on_interact_change_state_block",
        "properties": {
          "minecraft:direction": {
          }
        }
      },
      "components": {
        "minecraft:on_interact": {
          "event": "test_event"
        }
      },
      "events": {
        "test_event": {
          "set_block_property": {
            "minecraft:direction": "1"
          }
        }
      }
    }
</textarea> </br>
<a href="#Index">Back to top</a><br><br>

<h1><p id="Block Trigger Components">Block Trigger Components</p></h1>

<h2></h2>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:3;">
<tr> <th style="border-style:solid; border-width:3;">Name</th> <th style="border-style:solid; border-width:3;">Type</th> <th style="border-style:solid; border-width:3;">Default Value</th> <th style="border-style:solid; border-width:3;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">minecraft:on_fall_on</td>
<td style="border-style:solid; border-width:3; padding:7px">JSON Object</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Describes event for this block.</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">condition</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">The condition of event to be executed on the block.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">event</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">The event executed on the block.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">min_fall_distance</td>
<td style="border-style:solid; border-width:2; padding:8px">Decimal</td>
<td style="border-style:solid; border-width:2; padding:8px">0.0</td>
<td style="border-style:solid; border-width:2; padding:8px">The minimum distance in blocks that an actor needs to fall to trigger this event.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">target</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px">self</td>
<td style="border-style:solid; border-width:2; padding:8px">The target of event executed on the block.</br></td>
</tr>
</table>
</td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">minecraft:on_interact</td>
<td style="border-style:solid; border-width:3; padding:7px">JSON Object</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Describes event for this block.</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">condition</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">The condition of event to be executed on the block.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">event</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">The event executed on the block.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">target</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px">self</td>
<td style="border-style:solid; border-width:2; padding:8px">The target of event executed on the block.</br></td>
</tr>
</table>
</td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">minecraft:on_placed</td>
<td style="border-style:solid; border-width:3; padding:7px">JSON Object</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Describes event for this block.</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">condition</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">The condition of event to be executed on the block.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">event</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">The event executed on the block.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">target</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px">self</td>
<td style="border-style:solid; border-width:2; padding:8px">The target of event executed on the block.</br></td>
</tr>
</table>
</td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">minecraft:on_player_destroyed</td>
<td style="border-style:solid; border-width:3; padding:7px">JSON Object</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Describes event for this block.</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">condition</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">The condition of event to be executed on the block.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">event</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">The event executed on the block.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">target</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px">self</td>
<td style="border-style:solid; border-width:2; padding:8px">The target of event executed on the block.</br></td>
</tr>
</table>
</td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">minecraft:on_player_placing</td>
<td style="border-style:solid; border-width:3; padding:7px">JSON Object</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Describes event for this block.</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">condition</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">The condition of event to be executed on the block.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">event</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">The event executed on the block.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">target</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px">self</td>
<td style="border-style:solid; border-width:2; padding:8px">The target of event executed on the block.</br></td>
</tr>
</table>
</td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">minecraft:on_step_off</td>
<td style="border-style:solid; border-width:3; padding:7px">JSON Object</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Describes event for this block.</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">condition</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">The condition of event to be executed on the block.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">event</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">The event executed on the block.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">target</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px">self</td>
<td style="border-style:solid; border-width:2; padding:8px">The target of event executed on the block.</br></td>
</tr>
</table>
</td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">minecraft:on_step_on</td>
<td style="border-style:solid; border-width:3; padding:7px">JSON Object</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Describes event for this block.</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">condition</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">The condition of event to be executed on the block.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">event</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">The event executed on the block.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">target</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px">self</td>
<td style="border-style:solid; border-width:2; padding:8px">The target of event executed on the block.</br></td>
</tr>
</table>
</td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<br><br>

</v-html>
</div>
</template>

<style scoped>
textarea{
  color: white;
}
::-webkit-scrollbar {
  width: 10px;
}

::-webkit-scrollbar-thumb:hover {
  background: white;
}

::-webkit-scrollbar-track {
  background: grey;
}
</style>