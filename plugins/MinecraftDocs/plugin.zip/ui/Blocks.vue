<template>
<div style="overflow: scroll">
<v-html>
  <h1>BLOCKS DOCUMENTATION </br>Version: 1.19.10.20</h1>
This is documentation for a preview release of Minecraft. New features, components, and capabilities in this release are not final and might change without notice before the final release.<br/>Be sure to check the documentation once the release is out of preview if your add-on isn't working properly. Resource and Behavior Packs created for the preview are not guaranteed to work on the final release.<br/>
<h2><p id="Index">Index</p></h2>
<table border="1">
<tr> <th><a href="#Blocks">Blocks</a></th> </tr>
<tr> <td> <a href="#Block Components"> Block Components</a> </tr> </td>
<tr> <td> <a href="#Block Definition Properties"> Block Definition Properties</a> </tr> </td>
<tr> <td> <a href="#Block Description Properties"> Block Description Properties</a> </tr> </td>
<tr> <td> <a href="#Block Event Responses"> Block Event Responses</a> </tr> </td>
<tr> <td> <a href="#Block Trigger Components"> Block Trigger Components</a> </tr> </td>
</table>
<a href="#Index">Back to top</a>
<h1><p id="Blocks">Blocks</p></h1>

<h1><p id="Block Components">Block Components</p></h1>

<h2></h2>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:3;">
<tr> <th style="border-style:solid; border-width:3;">Name</th> <th style="border-style:solid; border-width:3;">Type</th> <th style="border-style:solid; border-width:3;">Default Value</th> <th style="border-style:solid; border-width:3;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">minecraft:aim_collision</td>
<td style="border-style:solid; border-width:3; padding:7px">Boolean / JSON Object</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Describes the collision of the block for raycast and its outline. If set to false it disables the collision of the block with entities. An origin of [-8.0, 0.0, -8.0] with a size of [16, 16, 16] is a unit cube.</br>Experimental toggles required: Holiday Creator Features</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">origin</td>
<td style="border-style:solid; border-width:2; padding:8px">Vector [a, b, c]</td>
<td style="border-style:solid; border-width:2; padding:8px">[-8.0, 0.0, -8.0]</td>
<td style="border-style:solid; border-width:2; padding:8px">Minimal position Bounds of the selection box. Origin is specified as [x, y, z] and must be in the range (-8, 0, -8) to (8, 16, 8), inclusive</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">size</td>
<td style="border-style:solid; border-width:2; padding:8px">Vector [a, b, c]</td>
<td style="border-style:solid; border-width:2; padding:8px">[16.0, 16.0, 16.0]</td>
<td style="border-style:solid; border-width:2; padding:8px">Size of each side of the selection box. Size is specified as [x, y, z]. Origin + size must be in the range (-8, 0, -8) to (8, 16, 8), inclusive</br></td>
</tr>
</table>
</td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">minecraft:block_light_emission</td>
<td style="border-style:solid; border-width:3; padding:7px">Decimal</td>
<td style="border-style:solid; border-width:3; padding:7px">0.0</td>
<td style="border-style:solid; border-width:3; padding:7px">The amount of light this block will emit in a range [0.0, 1.0].</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">minecraft:breathability</td>
<td style="border-style:solid; border-width:3; padding:7px">Enumerator</td>
<td style="border-style:solid; border-width:3; padding:7px">solid</td>
<td style="border-style:solid; border-width:3; padding:7px">The breathing type of this block that affects the breathing state of mobs when they have their breathing points inside this block. Available values: solid, air</br>Experimental toggles required: Holiday Creator Features</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">minecraft:collision_box</td>
<td style="border-style:solid; border-width:3; padding:7px">Boolean / JSON Object</td>
<td style="border-style:solid; border-width:3; padding:7px">true</td>
<td style="border-style:solid; border-width:3; padding:7px">Defines the area of the block that collides with entities. If set to true, a unit cube is used. If set to false, the block's collision with entities is disabled. If you want to specify this component as an object, you can either provide both an "origin" and "size", just an "origin", just a "size", or just a "shape", but no other combination of these fields. If this component is omitted, the collision box of a unit cube will be used.</br>Experimental toggles required: Holiday Creator Features</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">origin</td>
<td style="border-style:solid; border-width:2; padding:8px">Vector [a, b, c]</td>
<td style="border-style:solid; border-width:2; padding:8px">[-8.0, 0.0, -8.0]</td>
<td style="border-style:solid; border-width:2; padding:8px">Minimal position Bounds of the collision box. Origin is specified as [x, y, z] and must be in the range (-8, 0, -8) to (8, 16, 8), inclusive</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">size</td>
<td style="border-style:solid; border-width:2; padding:8px">Vector [a, b, c]</td>
<td style="border-style:solid; border-width:2; padding:8px">[16.0, 16.0, 16.0]</td>
<td style="border-style:solid; border-width:2; padding:8px">Size of each side of the collision box. Size is specified as [x, y, z]. Origin + size must be in the range (-8, 0, -8) to (8, 16, 8), inclusive</br></td>
</tr>
</table>
</td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">minecraft:crafting_table</td>
<td style="border-style:solid; border-width:3; padding:7px">JSON Object</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Describes the component of a custom crafting table. This component supports only "recipe_shaped" and "recipe_shapeless" typed recipes and not others like "recipe_furnace" or "recipe_brewing_mix". If there are two recipes for one item, the recipe book will pick the first that was parsed. If two input recipes are the same, crafting may assert and the resulting item may vary.</br>Experimental toggles required: Holiday Creator Features</br><h3><p id="crafting_tags">crafting_tags</p></h3>

Defines the tags recipes should define to be crafted on this table. Limited to 64 tags. Each tag is limited to 64 characters.</br><a href="#Index">Back to top</a><br><br>

<h3><p id="table_name">table_name</p></h3>

Specifies the language file key that maps to what text will be displayed in the UI of this table. If the string given can not be resolved as a loc string, the raw string given will be displayed. If this field is omitted, the name displayed will default to the name specified in the display_name component. If this block has no display_name component, the name displayed will default to the name of the block.</br><a href="#Index">Back to top</a><br><br>

</td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">minecraft:creative_category</td>
<td style="border-style:solid; border-width:3; padding:7px">String</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Specifies the menu category and group for the block, which determine where this block is placed in the inventory and crafting table container screens. If this component is omitted, the block will not appear in the inventory or crafting table container screens.</br>Experimental toggles required: Holiday Creator Features</br><h3><p id="category">category</p></h3>

Determines which category this block will be placed under in the inventory and crafting table container screens. Options are "construction", "nature", "equipment", "items", and "none". If omitted or "none" is specified, the block will not appear in the inventory or crafting table container screens.</br><a href="#Index">Back to top</a><br><br>

<h3><p id="group">group</p></h3>

Specifies the language file key that maps to which expandable/collapsible group this block will be a part of within a category. If the string given can not be resolved as a loc string, then we will check if there is an existing group whose name matches the raw string. If this field is omitted, or there is no group whose name matches the loc string or the raw string, this block will be placed standalone in the given category.</br><a href="#Index">Back to top</a><br><br>

</td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">minecraft:destroy_time</td>
<td style="border-style:solid; border-width:3; padding:7px">Decimal</td>
<td style="border-style:solid; border-width:3; padding:7px">0.0</td>
<td style="border-style:solid; border-width:3; padding:7px">Sets the destroy time property for the block. Greater numbers result in greater mining times. Time is measured in seconds with base equipment.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">minecraft:display_name</td>
<td style="border-style:solid; border-width:3; padding:7px">Localization String</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Specifies the language file key that maps to what text will be displayed when you hover over the block. Key is limited to 256 characters.</br>Experimental toggles required: Holiday Creator Features</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">minecraft:explosion_resistance</td>
<td style="border-style:solid; border-width:3; padding:7px">Decimal</td>
<td style="border-style:solid; border-width:3; padding:7px">0.0</td>
<td style="border-style:solid; border-width:3; padding:7px">Sets the explosion resistance for this block.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">minecraft:flammable</td>
<td style="border-style:solid; border-width:3; padding:7px">JSON Object</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Describes the flammable properties for this block.</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">burn_odds</td>
<td style="border-style:solid; border-width:2; padding:8px">Integer</td>
<td style="border-style:solid; border-width:2; padding:8px">0</td>
<td style="border-style:solid; border-width:2; padding:8px">How likely the block will be destroyed by flames when on fire. Value must be greater than or equal to 0.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">flame_odds</td>
<td style="border-style:solid; border-width:2; padding:8px">Integer</td>
<td style="border-style:solid; border-width:2; padding:8px">0</td>
<td style="border-style:solid; border-width:2; padding:8px">How likely the block will catch flame when next to a fire. Value must be greater than or equal to 0.</br></td>
</tr>
</table>
</td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">minecraft:friction</td>
<td style="border-style:solid; border-width:3; padding:7px">Decimal</td>
<td style="border-style:solid; border-width:3; padding:7px">0.6</td>
<td style="border-style:solid; border-width:3; padding:7px">Property describing the friction for this block in a range of [0.1, 1.0]. Friction affects an entity's movement speed when it travels on the block. Greater value results in less friction.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">minecraft:geometry</td>
<td style="border-style:solid; border-width:3; padding:7px">Identifier String</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">The geometry description identifier to use, this identifier must match an existing geometry identifier in any of the currently loaded resource packs.</br>Experimental toggles required: Holiday Creator Features</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">minecraft:light_dampening</td>
<td style="border-style:solid; border-width:3; padding:7px">Integer</td>
<td style="border-style:solid; border-width:3; padding:7px">0</td>
<td style="border-style:solid; border-width:3; padding:7px">The amount that light will be dampened when it passes through the block, in a range (0-15). Higher value means the light will be dampened more.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">minecraft:loot</td>
<td style="border-style:solid; border-width:3; padding:7px">Path String</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">The path to the loot table, relative to the behavior pack. Path string is limited to 256 characters.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">minecraft:map_color</td>
<td style="border-style:solid; border-width:3; padding:7px">String</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Sets the color of the block when rendered to a map. The color is represented as a hex value in the format "#RRGGBB". May also be expressed as an array of [R, G, B] from 0 to 255. If this component is omitted, the block will not show up on the map.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">minecraft:material_instances</td>
<td style="border-style:solid; border-width:3; padding:7px">JSON Object</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">The material instances for a block. Maps face or material_instance names in a geometry file to an actual material instance. You can assign a material instance object to any of these faces: 'up', 'down', 'north', 'south', 'east', 'west', or '*'. You can also give an instance the name of your choosing such as 'my_instance', and then assign it to a face by doing 'north':'my_instance'.</br>Experimental toggles required: Holiday Creator Features</br><h3><p id="Material Instance">Material Instance</p></h3>

A material instance definition to map to a material instance in a geometry file. The material instance '*' will be used for any materials that don't have a match.</br><h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Default Value</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">ambient_occlusion</td>
<td style="border-style:solid; border-width:1; padding:9px">Boolean</td>
<td style="border-style:solid; border-width:1; padding:9px">true</td>
<td style="border-style:solid; border-width:1; padding:9px">Should this material have ambient occlusion applied when lighting? If true, shadows will be created around and underneath the block.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">face_dimming</td>
<td style="border-style:solid; border-width:1; padding:9px">Boolean</td>
<td style="border-style:solid; border-width:1; padding:9px">true</td>
<td style="border-style:solid; border-width:1; padding:9px">Should this material be dimmed by the direction it's facing?</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">render_method</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px">opaque</td>
<td style="border-style:solid; border-width:1; padding:9px">The render method to use. Must be one of these options:</br>'opaque' - Used for a regular block texture without an alpha layer. Does not allow for transparency or translucency.</br>'double_sided' - Used for completely disabling backface culling.</br>'blend' - Used for a block like stained glass. Allows for transparency and translucency (slightly transparent textures).</br>'alpha_test' - Used for a block like the vanilla (unstained) glass. Does not allow for translucency, only fully opaque or fully transparent textures. Also disables backface culling.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">texture</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px"></td>
<td style="border-style:solid; border-width:1; padding:9px">Texture name for the material.</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

</td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">minecraft:part_visibility</td>
<td style="border-style:solid; border-width:3; padding:7px">JSON Object</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Sets conditions for when the block's different parts are visible.</br>Experimental toggles required: Upcoming Creator Features</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">conditions</td>
<td style="border-style:solid; border-width:2; padding:8px">JSON Object</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">A JSON object that contains a list of key/value pairs that map from bone name in a geometry file (key) to a condition that turns their rendering on/off (value). The condition should be a Molang query that uses block properties to determine true/false. Supported queries include 'has_block_property', 'block_property', and other queries that can evaluate without knowledge of the block's in-game positional or player affected data.</br></td>
</tr>
</table>
</td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">minecraft:placement_filter</td>
<td style="border-style:solid; border-width:3; padding:7px">JSON Object</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Sets rules for under what conditions the block can be placed/survive</br>Experimental toggles required: Holiday Creator Features</br><h3><p id="conditions">conditions</p></h3>

List of conditions where the block can be placed/survive. Limited to 64 conditions.</br><h4></h4>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Default Value</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">allowed_faces</td>
<td style="border-style:solid; border-width:1; padding:9px">Array</td>
<td style="border-style:solid; border-width:1; padding:9px"></td>
<td style="border-style:solid; border-width:1; padding:9px">List of any of the following strings: up, down, north, south, east, west, side, all. Limited to 6 faces.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">block_filter</td>
<td style="border-style:solid; border-width:1; padding:9px">Array</td>
<td style="border-style:solid; border-width:1; padding:9px"></td>
<td style="border-style:solid; border-width:1; padding:9px">List of blocks (can use tags to specify them) that this block can be placed against in the allowed_faces direction. Limited to 64 blocks.</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

</td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">minecraft:random_ticking</td>
<td style="border-style:solid; border-width:3; padding:7px">JSON Object</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Triggers the specified event randomly based on the random tick speed gamerule. The random tick speed determines how often blocks are updated. Some other examples of game mechanics that use random ticking are crop growth and fire spreading.</br>Experimental toggles required: Holiday Creator Features</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">on_tick</td>
<td style="border-style:solid; border-width:2; padding:8px">Trigger</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">The event that will be triggered on random ticks.</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Default Value</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">condition</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px">1</td>
<td style="border-style:solid; border-width:1; padding:9px">A condition using Molang queries that results to true/false. If true on the random tick, the event will be triggered. If false on the random tick, the event will not be triggered.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">event</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px">set_block_property</td>
<td style="border-style:solid; border-width:1; padding:9px">The event that will be triggered.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">target</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px">self</td>
<td style="border-style:solid; border-width:1; padding:9px">The target of the event executed by the block.</br></td>
</tr>
</table>
</td>
</tr>
</table>
</td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">minecraft:rotation</td>
<td style="border-style:solid; border-width:3; padding:7px">Vector [a, b, c]</td>
<td style="border-style:solid; border-width:3; padding:7px">rotation[0, 0, 0]</td>
<td style="border-style:solid; border-width:3; padding:7px">This is the block's rotation around the center of the cube in degrees. The rotation order is x-y-z. Angles need to be in factors of 90.</br>Experimental toggles required: Holiday Creator Features</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">minecraft:ticking</td>
<td style="border-style:solid; border-width:3; padding:7px">JSON Object</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Triggers the specified event, either once, or at a regular interval equal to a number of ticks randomly chosen from the range provided.</br>Experimental toggles required: Holiday Creator Features</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">looping</td>
<td style="border-style:solid; border-width:2; padding:8px">Boolean</td>
<td style="border-style:solid; border-width:2; padding:8px">true</td>
<td style="border-style:solid; border-width:2; padding:8px">Does the event loop? If false, the event will only be triggered once, after a delay equal to a number of ticks randomly chosen from the range. If true, the event will loop, and each interval between events will be equal to a number of ticks randomly chosen from the range.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">on_tick</td>
<td style="border-style:solid; border-width:2; padding:8px">Trigger</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">The event that will be triggered once or on an interval.</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:1;">
<tr> <th style="border-style:solid; border-width:1;">Name</th> <th style="border-style:solid; border-width:1;">Type</th> <th style="border-style:solid; border-width:1;">Default Value</th> <th style="border-style:solid; border-width:1;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">condition</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px">1</td>
<td style="border-style:solid; border-width:1; padding:9px">A condition using Molang queries that results to true/false. If true on the scheduled tick, the event will be triggered. If false on the scheduled tick, the event will not be triggered.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">event</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px">set_block_property</td>
<td style="border-style:solid; border-width:1; padding:9px">The event that will be triggered.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:1; padding:9px">target</td>
<td style="border-style:solid; border-width:1; padding:9px">String</td>
<td style="border-style:solid; border-width:1; padding:9px">self</td>
<td style="border-style:solid; border-width:1; padding:9px">The target of the event executed by the block.</br></td>
</tr>
</table>
</td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">range</td>
<td style="border-style:solid; border-width:2; padding:8px">Array</td>
<td style="border-style:solid; border-width:2; padding:8px">[10, 10]</td>
<td style="border-style:solid; border-width:2; padding:8px">The Range between which the component will trigger his event.</br></td>
</tr>
</table>
</td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">minecraft:unit_cube</td>
<td style="border-style:solid; border-width:3; padding:7px">JSON Object</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Specifies that a unit cube is to be used with tessellation.</br>Experimental toggles required: Holiday Creator Features</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">minecraft:unwalkable</td>
<td style="border-style:solid; border-width:3; padding:7px">Boolean</td>
<td style="border-style:solid; border-width:3; padding:7px">false</td>
<td style="border-style:solid; border-width:3; padding:7px">Sets the block as unwalkable. Mobs would not attempt to path over top of it when the value is set to true.</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h1><p id="Block Definition Properties">Block Definition Properties</p></h1>

These properties are part of the Block Definition. This helps the system determine how to parse and initialize this block.</br><h2></h2>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:3;">
<tr> <th style="border-style:solid; border-width:3;">Name</th> <th style="border-style:solid; border-width:3;">Type</th> <th style="border-style:solid; border-width:3;">Default Value</th> <th style="border-style:solid; border-width:3;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">format_version</td>
<td style="border-style:solid; border-width:3; padding:7px">String</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Specifies the version of the game this entity was made in. If the version is lower than the current version, any changes made to the entity in the vanilla version will be applied to it.</br></td>
</tr>
</table>
<h2>Code Example</h2>
Example<br / ><textarea readonly="true" cols="66" rows="20">
{
  "format_version": "1.16.0",
  "minecraft:block": {
    "description": {
      "identifier": "design:lavenderstone"
    },
    "components": {
      "minecraft:loot": "loot_tables/chests/simple_dungeon.json",
      "minecraft:destroy_time": 4.0,
      "minecraft:friction": 0.6,
      "minecraft:map_color": "#00ff00",
      "minecraft:flammable": {
        "flame_odds": 50,
        "burn_odds": 0
    },
      "minecraft:block_light_emission": 1.0
    }
  }
}
</textarea> </br>
<a href="#Index">Back to top</a><br><br>

<h1><p id="Block Description Properties">Block Description Properties</p></h1>

<h2></h2>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:3;">
<tr> <th style="border-style:solid; border-width:3;">Name</th> <th style="border-style:solid; border-width:3;">Type</th> <th style="border-style:solid; border-width:3;">Default Value</th> <th style="border-style:solid; border-width:3;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">identifier</td>
<td style="border-style:solid; border-width:3; padding:7px">String</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">The identifier for this block. The name must include a namespace and must not use the Minecraft namespace unless overriding a Vanilla block.</br></td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<h1><p id="Block Event Responses">Block Event Responses</p></h1>

Event responses for block trigger components.</br><h2></h2>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:3;">
<tr> <th style="border-style:solid; border-width:3;">Name</th> <th style="border-style:solid; border-width:3;">Type</th> <th style="border-style:solid; border-width:3;">Default Value</th> <th style="border-style:solid; border-width:3;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">add_mob_effect</td>
<td style="border-style:solid; border-width:3; padding:7px">JSON Object</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Apply mob effect to target.</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">amplifier</td>
<td style="border-style:solid; border-width:2; padding:8px">Integer</td>
<td style="border-style:solid; border-width:2; padding:8px">0</td>
<td style="border-style:solid; border-width:2; padding:8px">The amplifier for the mob effect.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">duration</td>
<td style="border-style:solid; border-width:2; padding:8px">Decimal</td>
<td style="border-style:solid; border-width:2; padding:8px">0.0</td>
<td style="border-style:solid; border-width:2; padding:8px">The duration of the mob effect.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">effect</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">The mob effect to apply.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">target</td>
<td style="border-style:solid; border-width:2; padding:8px">Minecraft Filter</td>
<td style="border-style:solid; border-width:2; padding:8px">self</td>
<td style="border-style:solid; border-width:2; padding:8px">The target context to execute against.</br></td>
</tr>
</table>
</td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">damage</td>
<td style="border-style:solid; border-width:3; padding:7px">JSON Object</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Deals damage to the target.</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">amount</td>
<td style="border-style:solid; border-width:2; padding:8px">Integer</td>
<td style="border-style:solid; border-width:2; padding:8px">0</td>
<td style="border-style:solid; border-width:2; padding:8px">The amount of damage to deal.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">mob_amount</td>
<td style="border-style:solid; border-width:2; padding:8px">Integer</td>
<td style="border-style:solid; border-width:2; padding:8px">0</td>
<td style="border-style:solid; border-width:2; padding:8px">The amount of damage to deal if held by a mob.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">target</td>
<td style="border-style:solid; border-width:2; padding:8px">Minecraft Filter</td>
<td style="border-style:solid; border-width:2; padding:8px">self</td>
<td style="border-style:solid; border-width:2; padding:8px">The target context to execute against.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">type</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">The type of damage to deal.</br></td>
</tr>
</table>
</td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">decrement_stack</td>
<td style="border-style:solid; border-width:3; padding:7px">JSON Object</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Decrement item stack.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">die</td>
<td style="border-style:solid; border-width:3; padding:7px">JSON Object</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Kill target. If target is self and this is run from a block then destroy the block.</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">target</td>
<td style="border-style:solid; border-width:2; padding:8px">Minecraft Filter</td>
<td style="border-style:solid; border-width:2; padding:8px">self</td>
<td style="border-style:solid; border-width:2; padding:8px">The target context to execute against.</br></td>
</tr>
</table>
</td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">play_effect</td>
<td style="border-style:solid; border-width:3; padding:7px">JSON Object</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Spawns a particle effect relative to target position.</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">data</td>
<td style="border-style:solid; border-width:2; padding:8px">Integer</td>
<td style="border-style:solid; border-width:2; padding:8px">0</td>
<td style="border-style:solid; border-width:2; padding:8px">Particle data value.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">effect</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">The name of the particle effect to create.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">target</td>
<td style="border-style:solid; border-width:2; padding:8px">Minecraft Filter</td>
<td style="border-style:solid; border-width:2; padding:8px">self</td>
<td style="border-style:solid; border-width:2; padding:8px">The target context to execute against.</br></td>
</tr>
</table>
</td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">play_sound</td>
<td style="border-style:solid; border-width:3; padding:7px">JSON Object</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Play a sound relative to target position.</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">sound</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">The name of the sound to play.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">target</td>
<td style="border-style:solid; border-width:2; padding:8px">Minecraft Filter</td>
<td style="border-style:solid; border-width:2; padding:8px">self</td>
<td style="border-style:solid; border-width:2; padding:8px">The target context to execute against.</br></td>
</tr>
</table>
</td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">remove_mob_effect</td>
<td style="border-style:solid; border-width:3; padding:7px">JSON Object</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Removes mob effect from target.</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">effect</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">The mob effect to remove. Use 'all' to remove all mob effects from target.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">target</td>
<td style="border-style:solid; border-width:2; padding:8px">Minecraft Filter</td>
<td style="border-style:solid; border-width:2; padding:8px">self</td>
<td style="border-style:solid; border-width:2; padding:8px">The target context to execute against.</br></td>
</tr>
</table>
</td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">run_command</td>
<td style="border-style:solid; border-width:3; padding:7px">JSON Object</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Triggers a slash command or a list of slash commands.</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">command</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">Slash command to run.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">command array</td>
<td style="border-style:solid; border-width:2; padding:8px">Array</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">List of slash commands to run.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">target</td>
<td style="border-style:solid; border-width:2; padding:8px">Minecraft Filter</td>
<td style="border-style:solid; border-width:2; padding:8px">self</td>
<td style="border-style:solid; border-width:2; padding:8px">The target context to execute against.</br></td>
</tr>
</table>
</td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">set_block</td>
<td style="border-style:solid; border-width:3; padding:7px">JSON Object</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Sets this block to another block type.</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">block_type</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">The type of block to set.</br></td>
</tr>
</table>
</td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">set_block_at_pos</td>
<td style="border-style:solid; border-width:3; padding:7px">JSON Object</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Sets a block relative to this block to another block type.</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">block_offset</td>
<td style="border-style:solid; border-width:2; padding:8px">Vector [a, b, c]</td>
<td style="border-style:solid; border-width:2; padding:8px">[0.0, 0.0, 0.0]</td>
<td style="border-style:solid; border-width:2; padding:8px">The offset from the block's center.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">block_type</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">The type of block to set.</br></td>
</tr>
</table>
</td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">set_block_property</td>
<td style="border-style:solid; border-width:3; padding:7px">JSON Object</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Sets a block property on this block.</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">property</td>
<td style="border-style:solid; border-width:2; padding:8px">Molang</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">Block property to set on the block.</br></td>
</tr>
</table>
</td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">spawn_loot</td>
<td style="border-style:solid; border-width:3; padding:7px">JSON Object</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Spawn loot from block.</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">table</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">File path, relative to the Behavior Pack's path, to the loot table file.</br></td>
</tr>
</table>
</td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">swing</td>
<td style="border-style:solid; border-width:3; padding:7px">JSON Object</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Event causes the actor to swing.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">teleport</td>
<td style="border-style:solid; border-width:3; padding:7px">JSON Object</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Teleport target randomly around destination point.</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">avoid_water</td>
<td style="border-style:solid; border-width:2; padding:8px">Boolean</td>
<td style="border-style:solid; border-width:2; padding:8px">true</td>
<td style="border-style:solid; border-width:2; padding:8px">Determines if the teleport avoids putting the target in water.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">destination</td>
<td style="border-style:solid; border-width:2; padding:8px">Vector [a, b, c]</td>
<td style="border-style:solid; border-width:2; padding:8px">[0.0, 0.0, 0.0]</td>
<td style="border-style:solid; border-width:2; padding:8px">Origin destination of the teleport.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">land_on_block</td>
<td style="border-style:solid; border-width:2; padding:8px">Boolean</td>
<td style="border-style:solid; border-width:2; padding:8px">true</td>
<td style="border-style:solid; border-width:2; padding:8px">Determines if the teleport places the target on a block.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">max_range</td>
<td style="border-style:solid; border-width:2; padding:8px">Vector [a, b, c]</td>
<td style="border-style:solid; border-width:2; padding:8px">[8.0, 8.0, 8.0]</td>
<td style="border-style:solid; border-width:2; padding:8px">Max range the target can teleport relative to the origin destination.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">target</td>
<td style="border-style:solid; border-width:2; padding:8px">Minecraft Filter</td>
<td style="border-style:solid; border-width:2; padding:8px">self</td>
<td style="border-style:solid; border-width:2; padding:8px">The target context to execute against.</br></td>
</tr>
</table>
</td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">transform_item</td>
<td style="border-style:solid; border-width:3; padding:7px">JSON Object</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Transforms item into another item.</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">transform</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">Name of the item it should transform into</br></td>
</tr>
</table>
</td>
</tr>
</table>
<h2>Code Example</h2>
Event Response Example<br / ><textarea readonly="true" cols="61" rows="23">

    "minecraft:block": {
      "description": {
        "identifier": "test:on_interact_change_state_block",
        "properties": {
          "minecraft:direction": {
          }
        }
      },
      "components": {
        "minecraft:on_interact": {
          "event": "test_event"
        }
      },
      "events": {
        "test_event": {
          "set_block_property": {
            "minecraft:direction": "1"
          }
        }
      }
    }
</textarea> </br>
<a href="#Index">Back to top</a><br><br>

<h1><p id="Block Trigger Components">Block Trigger Components</p></h1>

<h2></h2>

<table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:3;">
<tr> <th style="border-style:solid; border-width:3;">Name</th> <th style="border-style:solid; border-width:3;">Type</th> <th style="border-style:solid; border-width:3;">Default Value</th> <th style="border-style:solid; border-width:3;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">minecraft:on_fall_on</td>
<td style="border-style:solid; border-width:3; padding:7px">JSON Object</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Describes event for this block.</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">condition</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">The condition of event to be executed on the block.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">event</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">The event executed on the block.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">min_fall_distance</td>
<td style="border-style:solid; border-width:2; padding:8px">Decimal</td>
<td style="border-style:solid; border-width:2; padding:8px">0.0</td>
<td style="border-style:solid; border-width:2; padding:8px">The minimum distance in blocks that an actor needs to fall to trigger this event.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">target</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px">self</td>
<td style="border-style:solid; border-width:2; padding:8px">The target of event executed on the block.</br></td>
</tr>
</table>
</td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">minecraft:on_interact</td>
<td style="border-style:solid; border-width:3; padding:7px">JSON Object</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Describes event for this block.</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">condition</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">The condition of event to be executed on the block.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">event</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">The event executed on the block.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">target</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px">self</td>
<td style="border-style:solid; border-width:2; padding:8px">The target of event executed on the block.</br></td>
</tr>
</table>
</td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">minecraft:on_placed</td>
<td style="border-style:solid; border-width:3; padding:7px">JSON Object</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Describes event for this block.</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">condition</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">The condition of event to be executed on the block.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">event</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">The event executed on the block.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">target</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px">self</td>
<td style="border-style:solid; border-width:2; padding:8px">The target of event executed on the block.</br></td>
</tr>
</table>
</td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">minecraft:on_player_destroyed</td>
<td style="border-style:solid; border-width:3; padding:7px">JSON Object</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Describes event for this block.</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">condition</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">The condition of event to be executed on the block.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">event</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">The event executed on the block.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">target</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px">self</td>
<td style="border-style:solid; border-width:2; padding:8px">The target of event executed on the block.</br></td>
</tr>
</table>
</td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">minecraft:on_player_placing</td>
<td style="border-style:solid; border-width:3; padding:7px">JSON Object</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Describes event for this block.</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">condition</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">The condition of event to be executed on the block.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">event</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">The event executed on the block.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">target</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px">self</td>
<td style="border-style:solid; border-width:2; padding:8px">The target of event executed on the block.</br></td>
</tr>
</table>
</td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">minecraft:on_step_off</td>
<td style="border-style:solid; border-width:3; padding:7px">JSON Object</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Describes event for this block.</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">condition</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">The condition of event to be executed on the block.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">event</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">The event executed on the block.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">target</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px">self</td>
<td style="border-style:solid; border-width:2; padding:8px">The target of event executed on the block.</br></td>
</tr>
</table>
</td>
</tr>
<tr>
<td style="border-style:solid; border-width:3; padding:7px">minecraft:on_step_on</td>
<td style="border-style:solid; border-width:3; padding:7px">JSON Object</td>
<td style="border-style:solid; border-width:3; padding:7px"></td>
<td style="border-style:solid; border-width:3; padding:7px">Describes event for this block.</br><table border="1" style="width:100%; border-style:solid; border-collapse:collapse; border-width:2;">
<tr> <th style="border-style:solid; border-width:2;">Name</th> <th style="border-style:solid; border-width:2;">Type</th> <th style="border-style:solid; border-width:2;">Default Value</th> <th style="border-style:solid; border-width:2;">Description</th> </tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">condition</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">The condition of event to be executed on the block.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">event</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px"></td>
<td style="border-style:solid; border-width:2; padding:8px">The event executed on the block.</br></td>
</tr>
<tr>
<td style="border-style:solid; border-width:2; padding:8px">target</td>
<td style="border-style:solid; border-width:2; padding:8px">String</td>
<td style="border-style:solid; border-width:2; padding:8px">self</td>
<td style="border-style:solid; border-width:2; padding:8px">The target of event executed on the block.</br></td>
</tr>
</table>
</td>
</tr>
</table>
<a href="#Index">Back to top</a><br><br>

<br><br>
</v-html>
</div>
</template>

<style scoped>
textarea{
  color: white;
}
::-webkit-scrollbar {
  width: 10px;
}

::-webkit-scrollbar-thumb:hover {
  background: white;
}

::-webkit-scrollbar-track {
  background: grey;
}
</style>