Install the extension and then add the `jsonCompactor` compiler plugin to your build config.

```json
{
    "plugins": [
        "jsonCompactor"
    ]
}

```
