Install the extension and then add the `loadJSON` compiler plugin to your build config.

```json
{
	"plugins": {
		"*": ["loadJSON", "comMojangRewrite"]
	}
}
```
