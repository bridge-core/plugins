---
name: Text Formatting
---

# Text Formatting

***Bold Italic Text*** - `***Bold Italic Text***`
**Bold Text** - `**Bold Text**`
*Italic Text* - `*Italic Text*`
Ignore formatting - \``**Unformatted Text**`\`.
