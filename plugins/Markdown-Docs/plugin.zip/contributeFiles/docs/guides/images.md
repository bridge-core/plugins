---
name: Images
---

# Images

![bridge nightly logo](textures/bridge)
Images can be inserted using `![alt text](textures/path)`

You do not need to include the file extension.